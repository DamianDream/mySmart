import{A as e,D as t,E as n,F as r,N as i,O as a,P as o,R as s,T as c,c as l,d as u,f as d,k as f,l as p,u as m,w as h}from"./sidebar.js";var g=`ss_popup_queue`,_=`
  #ss-sidebar {
    position: relative !important;
    inset: auto !important;
    width: 100% !important;
    min-width: 0 !important;
    max-width: none !important;
    height: 100vh !important;
    transform: none !important;
    box-shadow: none !important;
    border: none !important;
    display: flex;
    flex-direction: column;
  }
  /* Sit above the #ss-sidebar::before frosted-glass layer (z-index:0). */
  .ssp-tabs, .ssp-content { position: relative; z-index: 1; }
  .ssp-tabs { display: flex; align-items: stretch; gap: 2px; padding: 6px 6px 0; background: var(--bg-solid); border-bottom: 1px solid var(--border); overflow-x: auto; flex-shrink: 0; }
  .ssp-tab { display: flex; align-items: center; gap: 6px; max-width: 200px; padding: 8px 10px; border-radius: 8px 8px 0 0; background: var(--bg2); color: var(--text4); font-family: var(--font-main); font-size: 13px; font-weight: 600; cursor: pointer; white-space: nowrap; border: 1px solid transparent; border-bottom: none; }
  .ssp-tab.active { background: var(--bg3); color: var(--text); }
  .ssp-tab-name { overflow: hidden; text-overflow: ellipsis; max-width: 130px; }
  .ssp-tab-close { display: inline-flex; align-items: center; justify-content: center; width: 16px; height: 16px; border-radius: 4px; opacity: 0.6; }
  .ssp-tab-close:hover { opacity: 1; background: rgba(255,255,255,0.1); }
  .ssp-tab-close svg { width: 12px; height: 12px; }
  .ssp-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
  .ssp-toolbar { display: flex; align-items: center; justify-content: space-between; padding: 8px 16px; border-bottom: 1px solid var(--border); background: var(--bg-solid); }
  .ssp-toolbar-title { font-family: var(--font-main); font-size: 14px; font-weight: 700; color: var(--text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .ssp-refresh { display: inline-flex; align-items: center; gap: 6px; padding: 6px 10px; border-radius: 8px; background: var(--bg3); color: var(--text2); font-family: var(--font-main); font-size: 12px; font-weight: 600; cursor: pointer; border: none; flex-shrink: 0; }
  .ssp-refresh:hover { background: var(--accent-bg); color: var(--accent); }
  .ssp-refresh svg { width: 14px; height: 14px; }
  .ssp-refresh.spinning svg { animation: ssp-spin 0.8s linear infinite; }
  @keyframes ssp-spin { to { transform: rotate(360deg); } }
  .ssp-empty { flex: 1; display: flex; align-items: center; justify-content: center; color: var(--text4); font-family: var(--font-main); font-size: 14px; padding: 24px; text-align: center; }
`,v=null,y=null,b=null,x=[],S=null;function C(e){return x.find(t=>t.contactId===e)}function w(){y.innerHTML=x.map(e=>`
    <div class="ssp-tab${e.contactId===S?` active`:``}" data-id="${t(e.contactId)}">
      <span class="ssp-tab-name">${t(e.name||e.contactId)}</span>
      <span class="ssp-tab-close" data-close="${t(e.contactId)}" title="Close tab">${c}</span>
    </div>
  `).join(``),y.querySelectorAll(`.ssp-tab`).forEach(e=>{e.onclick=t=>{t.target.closest(`[data-close]`)||E(e.dataset.id)}}),y.querySelectorAll(`[data-close]`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),D(e.dataset.close)}})}function T(){let n=C(S);if(!n){b.innerHTML=`<div class="ssp-empty">No contact open.<br>Select a contact in the side panel.</div>`;return}let i=n.data&&(n.data.fullName||n.data.name)||n.contactId;b.innerHTML=`
    <div class="ssp-toolbar">
      <div class="ssp-toolbar-title">${t(i)}</div>
      <button class="ssp-refresh" id="ssp-refresh-btn" title="Reload this contact's data">${h} Refresh</button>
    </div>
    <div class="ssp-card" id="ssp-card"></div>
  `,b.querySelector(`#ssp-refresh-btn`).onclick=()=>O(n.contactId,!0);let a=b.querySelector(`#ssp-card`);n.status===`loading`?a.innerHTML=`<div class="ss-loading" style="display:flex;padding:24px;"><div class="ss-spinner"></div><span class="ss-loading-text">Loading details...</span></div>`:n.status===`error`?a.innerHTML=`<div class="ss-error visible" style="margin:16px;">⚠ ${t(n.error||`Failed to load`)}</div>`:n.data&&l(a,n.data,{settings:r(),priorityKeys:o(n.projectSlug).split(`,`).map(e=>e.trim().toLowerCase()).filter(Boolean),projectSlug:n.projectSlug,editable:!0,onSave:async(t,r)=>{e.projectId=n.projectSlug,await d(n.contactId,t,r);let i=await u(n.contactId);return n.data=i,n.name=i.fullName||i.name||n.contactId,w(),i},onAttachTag:async(t,r,i)=>{e.projectId=n.projectSlug,await p(t,r,i,n.projectSlug);let a=await u(t);return n.data=a,a},onDetachTag:async(t,r)=>{e.projectId=n.projectSlug,await m(t,r,n.projectSlug);let i=await u(t);return n.data=i,i}})}function E(e){S=e,w(),T()}function D(e){let t=x.findIndex(t=>t.contactId===e);t!==-1&&(x.splice(t,1),S===e&&(S=x.length?x[Math.max(0,t-1)].contactId:null),w(),T())}async function O(t,n=!1){let r=C(t);if(!r||r.status===`ready`&&!n)return;r.status=`loading`,t===S&&T();let i=b.querySelector(`#ssp-refresh-btn`);n&&i&&i.classList.add(`spinning`);try{e.projectId=r.projectSlug;let n=await u(t);r.data=n,r.name=n.fullName||n.name||t,r.status=`ready`}catch(e){r.status=`error`,r.error=e.message}w(),t===S&&T()}function k(e,t){e=String(e);let n=C(e);n?E(e):(n={contactId:e,projectSlug:t,name:e,data:null,status:`idle`,error:null},x.push(n),E(e),O(e))}async function A(){let e=[];try{e=(await chrome.storage.session.get(g))[g]||[],await chrome.storage.session.set({[g]:[]})}catch{}e.forEach(e=>k(e.contactId,e.projectSlug))}async function j(){v=document.getElementById(`ss-popup-root`).attachShadow({mode:`open`});let t=document.createElement(`style`);t.textContent=s+_,v.appendChild(t);let r=document.createElement(`link`);r.rel=`stylesheet`,r.href=`https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap`,v.appendChild(r);let o=document.createElement(`div`);o.id=`ss-sidebar`,o.innerHTML=`<div class="ssp-tabs" id="ssp-tabs"></div><div class="ssp-content" id="ssp-content"></div>`,v.appendChild(o),a(v),y=v.getElementById(`ssp-tabs`),b=v.getElementById(`ssp-content`),await i(),f(),n(e.theme),w(),T(),chrome.runtime.onMessage.addListener(e=>{e?.type===`SS_POPUP_DRAIN`&&A()}),await A()}j();