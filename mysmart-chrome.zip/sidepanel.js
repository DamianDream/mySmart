import{A as e,C as t,E as n,I as r,L as i,M as a,N as o,O as s,R as c,S as l,_ as u,a as d,b as f,g as p,h as m,i as h,j as g,k as _,m as v,n as y,o as b,p as x,r as S,s as C,t as w,v as T,x as E,y as D}from"./sidebar.js";var O=null,k=``,A=`
  #ss-sidebar {
    position: relative !important;
    inset: auto !important;
    width: 100% !important;
    max-width: none !important;
    height: 100vh !important;
    transform: none !important;
    box-shadow: none !important;
    border: none !important;
    overflow: hidden !important;
  }
  #ss-resize-handle, #ss-extra-resize-handle { display: none !important; }

  /* The slide-out sub-panels were designed to fly out to the LEFT of a floating
     sidebar. In the native side panel that's off-screen, so render them as
     full-width drawers that slide in OVER the panel instead. */
  .ss-nav, .ss-extra-panel, .ss-info-panel {
    width: 100% !important;
    max-width: 100% !important;
    transform: translateX(-100%) !important;
  }
  .ss-nav.open, .ss-extra-panel.open, .ss-info-panel.open {
    transform: translateX(0) !important;
    z-index: 100 !important;
    pointer-events: auto !important;
  }
`;function j(){return new Promise(e=>{try{chrome.tabs.query({active:!0,currentWindow:!0},t=>{e(t&&t[0]&&t[0].url?t[0].url:``)})}catch{e(``)}})}function M(){if(!l()||e.projectMode===`MANUAL`)return;let t=f();t&&t!==e.projectId&&D(t)}async function N(){k=await j(),M(),C()}function P(){y(),S(),u(),m();let t=O.getElementById(`ss-mode-checkbox`);t&&t.addEventListener(`change`,t=>{l()&&(T(t.target.checked?`AUTO`:`MANUAL`),e.projectMode===`AUTO`&&M())});let n=(e,t)=>{let n=O.getElementById(e);n&&(n.onclick=t)};n(`ss-project-container`,e=>{e.stopPropagation(),p(),b(`ss-project-switcher-panel`)}),n(`ss-api-status`,()=>d(`settings`)),n(`ss-burger`,e=>{e.stopPropagation(),b(`ss-nav`)});let r={"ss-contact-search-hist":()=>{e.contactShowSearchHist=!1},"ss-contact-fav-panel":()=>{e.contactShowFavorites=!1},"ss-contact-settings-panel":()=>{e.contactSettingsOpen=!1},"ss-info-panel":()=>{e.contactInfoOpen=!1},"ss-var-search-hist":()=>{e.varShowSearchHist=!1},"ss-var-presets-panel":()=>{e.varPresetsOpen=!1}};O.addEventListener(`click`,e=>{let t=e.target.closest(`.ss-close-extra-panel`);if(!t)return;let n=t.closest(`.ss-info-panel, .ss-extra-panel`);n&&(e.stopPropagation(),n.classList.remove(`open`),r[n.id]?.(),O.querySelectorAll(`.ss-action-btn, .ss-var-btn`).forEach(e=>e.classList.remove(`active`)))}),O.addEventListener(`click`,t=>{let n=O.getElementById(`ss-nav`);n&&n.classList.contains(`open`)&&!n.contains(t.target)&&t.target.id!==`ss-burger`&&(n.classList.remove(`open`),e.navOpen=!1);let r=O.getElementById(`ss-info-panel`);r&&r.classList.contains(`open`)&&!r.contains(t.target)&&!t.target.closest(`.ss-var-card`)&&(r.classList.remove(`open`),e.contactInfoOpen=!1),[`ss-contact-search-hist`,`ss-contact-fav-panel`,`ss-contact-settings-panel`,`ss-project-switcher-panel`].forEach(n=>{let r=O.getElementById(n);r&&r.classList.contains(`open`)&&!r.contains(t.target)&&!t.target.closest(`.ss-action-btn`)&&!t.target.closest(`.ss-var-btn`)&&(r.classList.remove(`open`),n===`ss-contact-search-hist`&&(e.contactShowSearchHist=!1),n===`ss-contact-fav-panel`&&(e.contactShowFavorites=!1),n===`ss-contact-settings-panel`&&(e.contactSettingsOpen=!1))})})}async function F(){let t=w();t.classList.add(`open`),O.appendChild(t),n(e.theme),await N();let o=await i(a),s=f(),c=r(g,null),u=null;u=l()?e.projectMode===`AUTO`?s||o||c:o||c||s:o||c,e.projectName=E(),u?D(u):h(e.activeTab||`vars`),P(),chrome.tabs.onActivated.addListener(N),chrome.tabs.onUpdated.addListener((e,t)=>{(t.url||t.status===`complete`)&&N()}),chrome.windows?.onFocusChanged?.addListener(N),v(),x()}async function I(){O=document.getElementById(`ss-panel-root`).attachShadow({mode:`open`});let e=document.createElement(`style`);e.textContent=c+A,O.appendChild(e);let n=document.createElement(`link`);n.rel=`stylesheet`,n.href=`https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap`,O.appendChild(n),s(O),t(()=>k||location.href),await o(),_(),F()}I();