import{B as e,F as t,H as n,I as r,L as i,M as a,N as o,P as s,V as c,_ as l,a as u,b as d,d as f,f as p,g as m,h,i as g,k as _,m as v,n as y,o as b,p as x,r as S,s as C,t as w,v as T,x as E,y as D}from"./sidebar.js";var O=null,k=``,A=`
  #ss-sidebar {
    position: relative !important;
    inset: auto !important;
    width: 100% !important;
    max-width: none !important;
    height: 100vh !important;
    transform: none !important;
    box-shadow: none !important;
    border: none !important;
    overflow: hidden !important;
  }
  #ss-resize-handle, #ss-extra-resize-handle { display: none !important; }

  /* The slide-out sub-panels were designed to fly out to the LEFT of a floating
     sidebar. In the native side panel that's off-screen, so render them as
     full-width drawers that slide in OVER the panel instead. */
  .ss-nav, .ss-extra-panel, .ss-info-panel {
    width: 100% !important;
    max-width: 100% !important;
    transform: translateX(-100%) !important;
  }
  .ss-nav.open, .ss-extra-panel.open, .ss-info-panel.open {
    transform: translateX(0) !important;
    z-index: 100 !important;
    pointer-events: auto !important;
  }
`;function j(){return new Promise(e=>{try{chrome.tabs.query({active:!0,currentWindow:!0},t=>{e(t&&t[0]&&t[0].url?t[0].url:``)})}catch{e(``)}})}function M(){if(!d()||s.projectMode===`MANUAL`)return;let e=T();e&&e!==s.projectId&&l(e)}async function N(){k=await j(),M(),C()}function P(){y(),S(),h(),x();let e=O.getElementById(`ss-mode-checkbox`);e&&e.addEventListener(`change`,e=>{d()&&(m(e.target.checked?`AUTO`:`MANUAL`),s.projectMode===`AUTO`&&M())});let t=(e,t)=>{let n=O.getElementById(e);n&&(n.onclick=t)};t(`ss-project-container`,e=>{e.stopPropagation(),v(),b(`ss-project-switcher-panel`)}),t(`ss-api-status`,()=>u(`settings`)),t(`ss-burger`,e=>{e.stopPropagation(),b(`ss-nav`)});let n={"ss-contact-search-hist":()=>{s.contactShowSearchHist=!1},"ss-contact-fav-panel":()=>{s.contactShowFavorites=!1},"ss-contact-settings-panel":()=>{s.contactSettingsOpen=!1},"ss-info-panel":()=>{s.contactInfoOpen=!1},"ss-var-search-hist":()=>{s.varShowSearchHist=!1},"ss-var-presets-panel":()=>{s.varPresetsOpen=!1}};O.addEventListener(`click`,e=>{let t=e.target.closest(`.ss-close-extra-panel`);if(!t)return;let r=t.closest(`.ss-info-panel, .ss-extra-panel`);r&&(e.stopPropagation(),r.classList.remove(`open`),n[r.id]?.(),O.querySelectorAll(`.ss-action-btn, .ss-var-btn`).forEach(e=>e.classList.remove(`active`)))}),O.addEventListener(`click`,e=>{let t=O.getElementById(`ss-nav`);t&&t.classList.contains(`open`)&&!t.contains(e.target)&&e.target.id!==`ss-burger`&&(t.classList.remove(`open`),s.navOpen=!1);let n=O.getElementById(`ss-info-panel`);n&&n.classList.contains(`open`)&&!n.contains(e.target)&&!e.target.closest(`.ss-var-card`)&&(n.classList.remove(`open`),s.contactInfoOpen=!1),[`ss-contact-search-hist`,`ss-contact-fav-panel`,`ss-contact-settings-panel`,`ss-project-switcher-panel`].forEach(t=>{let n=O.getElementById(t);n&&n.classList.contains(`open`)&&!n.contains(e.target)&&!e.target.closest(`.ss-action-btn`)&&!e.target.closest(`.ss-var-btn`)&&(n.classList.remove(`open`),t===`ss-contact-search-hist`&&(s.contactShowSearchHist=!1),t===`ss-contact-fav-panel`&&(s.contactShowFavorites=!1),t===`ss-contact-settings-panel`&&(s.contactSettingsOpen=!1))})})}async function F(){let n=w();n.classList.add(`open`),O.appendChild(n),_(s.theme),await N();let i=await c(r),a=T(),o=e(t,null),u=null;u=d()?s.projectMode===`AUTO`?a||i||o:i||o||a:i||o,s.projectName=D(),u?l(u):g(s.activeTab||`vars`),P(),chrome.tabs.onActivated.addListener(N),chrome.tabs.onUpdated.addListener((e,t)=>{(t.url||t.status===`complete`)&&N()}),chrome.windows?.onFocusChanged?.addListener(N),p(),f()}async function I(){O=document.getElementById(`ss-panel-root`).attachShadow({mode:`open`});let e=document.createElement(`style`);e.textContent=n+A,O.appendChild(e);let t=document.createElement(`link`);t.rel=`stylesheet`,t.href=`https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap`,O.appendChild(t),a(O),E(()=>k||location.href),await i(),o(),F()}I();