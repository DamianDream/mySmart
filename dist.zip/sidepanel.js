import{A as e,D as t,E as n,F as r,I as i,O as a,P as o,_ as s,a as c,b as l,d as u,f as d,g as f,h as p,i as m,j as h,k as g,m as _,n as v,o as y,p as b,r as x,s as S,t as C,v as w,w as T,x as E,y as D}from"./sidebar.js";var O=null,k=``,A=`
  #ss-sidebar {
    position: relative !important;
    inset: auto !important;
    width: 100% !important;
    max-width: none !important;
    height: 100vh !important;
    transform: none !important;
    box-shadow: none !important;
    border: none !important;
    overflow: hidden !important;
  }
  #ss-resize-handle, #ss-extra-resize-handle { display: none !important; }

  /* The slide-out sub-panels were designed to fly out to the LEFT of a floating
     sidebar. In the native side panel that's off-screen, so render them as
     full-width drawers that slide in OVER the panel instead. */
  .ss-nav, .ss-extra-panel, .ss-info-panel {
    width: 100% !important;
    max-width: 100% !important;
    transform: translateX(-100%) !important;
  }
  .ss-nav.open, .ss-extra-panel.open, .ss-info-panel.open {
    transform: translateX(0) !important;
    z-index: 100 !important;
    pointer-events: auto !important;
  }
`;function j(){return new Promise(e=>{try{chrome.tabs.query({active:!0,currentWindow:!0},t=>{e(t&&t[0]&&t[0].url?t[0].url:``)})}catch{e(``)}})}function M(){if(!l()||a.projectMode===`MANUAL`)return;let e=w();e&&e!==a.projectId&&s(e)}async function N(){k=await j(),M(),S()}function P(){v(),x(),p(),b();let e=O.getElementById(`ss-mode-checkbox`);e&&e.addEventListener(`change`,e=>{l()&&(f(e.target.checked?`AUTO`:`MANUAL`),a.projectMode===`AUTO`&&M())});let t=(e,t)=>{let n=O.getElementById(e);n&&(n.onclick=t)};t(`ss-project-container`,e=>{e.stopPropagation(),_(),y(`ss-project-switcher-panel`)}),t(`ss-api-status`,()=>c(`settings`)),t(`ss-burger`,e=>{e.stopPropagation(),y(`ss-nav`)});let n={"ss-contact-search-hist":()=>{a.contactShowSearchHist=!1},"ss-contact-fav-panel":()=>{a.contactShowFavorites=!1},"ss-contact-settings-panel":()=>{a.contactSettingsOpen=!1},"ss-info-panel":()=>{a.contactInfoOpen=!1},"ss-var-search-hist":()=>{a.varShowSearchHist=!1},"ss-var-presets-panel":()=>{a.varPresetsOpen=!1}};O.addEventListener(`click`,e=>{let t=e.target.closest(`.ss-close-extra-panel`);if(!t)return;let r=t.closest(`.ss-info-panel, .ss-extra-panel`);r&&(e.stopPropagation(),r.classList.remove(`open`),n[r.id]?.(),O.querySelectorAll(`.ss-action-btn, .ss-var-btn`).forEach(e=>e.classList.remove(`active`)))}),O.addEventListener(`click`,e=>{let t=O.getElementById(`ss-nav`);t&&t.classList.contains(`open`)&&!t.contains(e.target)&&e.target.id!==`ss-burger`&&(t.classList.remove(`open`),a.navOpen=!1);let n=O.getElementById(`ss-info-panel`);n&&n.classList.contains(`open`)&&!n.contains(e.target)&&!e.target.closest(`.ss-var-card`)&&(n.classList.remove(`open`),a.contactInfoOpen=!1),[`ss-contact-search-hist`,`ss-contact-fav-panel`,`ss-contact-settings-panel`,`ss-project-switcher-panel`].forEach(t=>{let n=O.getElementById(t);n&&n.classList.contains(`open`)&&!n.contains(e.target)&&!e.target.closest(`.ss-action-btn`)&&!e.target.closest(`.ss-var-btn`)&&(n.classList.remove(`open`),t===`ss-contact-search-hist`&&(a.contactShowSearchHist=!1),t===`ss-contact-fav-panel`&&(a.contactShowFavorites=!1),t===`ss-contact-settings-panel`&&(a.contactSettingsOpen=!1))})})}async function F(){let t=C();t.classList.add(`open`),O.appendChild(t),T(a.theme),await N();let n=await r(e),i=w(),c=o(g,null),f=null;f=l()?a.projectMode===`AUTO`?i||n||c:n||c||i:n||c,a.projectName=D(),f?s(f):m(a.activeTab||`vars`),P(),chrome.tabs.onActivated.addListener(N),chrome.tabs.onUpdated.addListener((e,t)=>{(t.url||t.status===`complete`)&&N()}),chrome.windows?.onFocusChanged?.addListener(N),d(),u()}async function I(){O=document.getElementById(`ss-panel-root`).attachShadow({mode:`open`});let e=document.createElement(`style`);e.textContent=i+A,O.appendChild(e);let r=document.createElement(`link`);r.rel=`stylesheet`,r.href=`https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap`,O.appendChild(r),n(O),E(()=>k||location.href),await h(),t(),F()}I();