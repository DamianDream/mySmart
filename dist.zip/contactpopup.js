import{C as e,D as t,E as n,I as r,M as i,N as a,O as o,S as s,T as c,c as l,j as u,l as d,u as f,w as p}from"./sidebar.js";var m=`ss_popup_queue`,h=`
  #ss-sidebar {
    position: relative !important;
    inset: auto !important;
    width: 100% !important;
    min-width: 0 !important;
    max-width: none !important;
    height: 100vh !important;
    transform: none !important;
    box-shadow: none !important;
    border: none !important;
    display: flex;
    flex-direction: column;
  }
  /* Sit above the #ss-sidebar::before frosted-glass layer (z-index:0). */
  .ssp-tabs, .ssp-content { position: relative; z-index: 1; }
  .ssp-tabs { display: flex; align-items: stretch; gap: 2px; padding: 6px 6px 0; background: var(--bg-solid); border-bottom: 1px solid var(--border); overflow-x: auto; flex-shrink: 0; }
  .ssp-tab { display: flex; align-items: center; gap: 6px; max-width: 200px; padding: 8px 10px; border-radius: 8px 8px 0 0; background: var(--bg2); color: var(--text4); font-family: var(--font-main); font-size: 13px; font-weight: 600; cursor: pointer; white-space: nowrap; border: 1px solid transparent; border-bottom: none; }
  .ssp-tab.active { background: var(--bg3); color: var(--text); }
  .ssp-tab-name { overflow: hidden; text-overflow: ellipsis; max-width: 130px; }
  .ssp-tab-close { display: inline-flex; align-items: center; justify-content: center; width: 16px; height: 16px; border-radius: 4px; opacity: 0.6; }
  .ssp-tab-close:hover { opacity: 1; background: rgba(255,255,255,0.1); }
  .ssp-tab-close svg { width: 12px; height: 12px; }
  .ssp-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
  .ssp-toolbar { display: flex; align-items: center; justify-content: space-between; padding: 8px 16px; border-bottom: 1px solid var(--border); background: var(--bg-solid); }
  .ssp-toolbar-title { font-family: var(--font-main); font-size: 14px; font-weight: 700; color: var(--text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .ssp-refresh { display: inline-flex; align-items: center; gap: 6px; padding: 6px 10px; border-radius: 8px; background: var(--bg3); color: var(--text2); font-family: var(--font-main); font-size: 12px; font-weight: 600; cursor: pointer; border: none; flex-shrink: 0; }
  .ssp-refresh:hover { background: var(--accent-bg); color: var(--accent); }
  .ssp-refresh svg { width: 14px; height: 14px; }
  .ssp-refresh.spinning svg { animation: ssp-spin 0.8s linear infinite; }
  @keyframes ssp-spin { to { transform: rotate(360deg); } }
  .ssp-empty { flex: 1; display: flex; align-items: center; justify-content: center; color: var(--text4); font-family: var(--font-main); font-size: 14px; padding: 24px; text-align: center; }
`,g=null,_=null,v=null,y=[],b=null;function x(e){return y.find(t=>t.contactId===e)}function S(){_.innerHTML=y.map(t=>`
    <div class="ssp-tab${t.contactId===b?` active`:``}" data-id="${c(t.contactId)}">
      <span class="ssp-tab-name">${c(t.name||t.contactId)}</span>
      <span class="ssp-tab-close" data-close="${c(t.contactId)}" title="Close tab">${e}</span>
    </div>
  `).join(``),_.querySelectorAll(`.ssp-tab`).forEach(e=>{e.onclick=t=>{t.target.closest(`[data-close]`)||w(e.dataset.id)}}),_.querySelectorAll(`[data-close]`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),T(e.dataset.close)}})}function C(){let e=x(b);if(!e){v.innerHTML=`<div class="ssp-empty">No contact open.<br>Select a contact in the side panel.</div>`;return}let t=e.data&&(e.data.fullName||e.data.name)||e.contactId;v.innerHTML=`
    <div class="ssp-toolbar">
      <div class="ssp-toolbar-title">${c(t)}</div>
      <button class="ssp-refresh" id="ssp-refresh-btn" title="Reload this contact's data">${s} Refresh</button>
    </div>
    <div class="ssp-card" id="ssp-card"></div>
  `,v.querySelector(`#ssp-refresh-btn`).onclick=()=>E(e.contactId,!0);let n=v.querySelector(`#ssp-card`);e.status===`loading`?n.innerHTML=`<div class="ss-loading" style="display:flex;padding:24px;"><div class="ss-spinner"></div><span class="ss-loading-text">Loading details...</span></div>`:e.status===`error`?n.innerHTML=`<div class="ss-error visible" style="margin:16px;">⚠ ${c(e.error||`Failed to load`)}</div>`:e.data&&l(n,e.data,{settings:a(),priorityKeys:i(e.projectSlug).split(`,`).map(e=>e.trim().toLowerCase()).filter(Boolean),projectSlug:e.projectSlug,editable:!0,onSave:async(t,n)=>{o.projectId=e.projectSlug,await f(e.contactId,t,n);let r=await d(e.contactId);return e.data=r,e.name=r.fullName||r.name||e.contactId,S(),r}})}function w(e){b=e,S(),C()}function T(e){let t=y.findIndex(t=>t.contactId===e);t!==-1&&(y.splice(t,1),b===e&&(b=y.length?y[Math.max(0,t-1)].contactId:null),S(),C())}async function E(e,t=!1){let n=x(e);if(!n||n.status===`ready`&&!t)return;n.status=`loading`,e===b&&C();let r=v.querySelector(`#ssp-refresh-btn`);t&&r&&r.classList.add(`spinning`);try{o.projectId=n.projectSlug;let t=await d(e);n.data=t,n.name=t.fullName||t.name||e,n.status=`ready`}catch(e){n.status=`error`,n.error=e.message}S(),e===b&&C()}function D(e,t){e=String(e);let n=x(e);n?w(e):(n={contactId:e,projectSlug:t,name:e,data:null,status:`idle`,error:null},y.push(n),w(e),E(e))}async function O(){let e=[];try{e=(await chrome.storage.session.get(m))[m]||[],await chrome.storage.session.set({[m]:[]})}catch{}e.forEach(e=>D(e.contactId,e.projectSlug))}async function k(){g=document.getElementById(`ss-popup-root`).attachShadow({mode:`open`});let e=document.createElement(`style`);e.textContent=r+h,g.appendChild(e);let i=document.createElement(`link`);i.rel=`stylesheet`,i.href=`https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap`,g.appendChild(i);let a=document.createElement(`div`);a.id=`ss-sidebar`,a.innerHTML=`<div class="ssp-tabs" id="ssp-tabs"></div><div class="ssp-content" id="ssp-content"></div>`,g.appendChild(a),n(g),_=g.getElementById(`ssp-tabs`),v=g.getElementById(`ssp-content`),await u(),t(),p(o.theme),S(),C(),chrome.runtime.onMessage.addListener(e=>{e?.type===`SS_POPUP_DRAIN`&&O()}),await O()}k();