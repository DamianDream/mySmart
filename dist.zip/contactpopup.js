import{A as e,C as t,D as n,E as r,H as i,L as a,M as o,N as s,O as c,P as l,R as u,S as d,T as f,c as p,j as m,k as h,l as g,u as _,w as v,z as y}from"./sidebar.js";var b=[`id`,`name`,`firstName`,`lastName`,`fullName`,`email`,`phone`,`photo`,`createdAt`,`notes`,`tags`,`values`,`thumb`,`updatedAt`,`system_city`,`system_country`,`system_continent`,`system_timezone`,`system_os`,`system_browser`,`is_active`,`userId`,`projectId`];function x(e){let t=(e.values||[]).map(e=>({name:e.name,value:e.value}));return Object.keys(e).forEach(n=>{!b.includes(n)&&e[n]!==null&&typeof e[n]!=`object`&&(t.find(e=>e.name===n)||t.push({name:n,value:e[n]}))}),t}function S(e,r,i){let a=i&&e.name===r;return`
    <div class="ss-info-var${a?` editing`:``}" title="${m(e.name)}: ${m(String(e.value))}">
      <div class="ss-info-var-name">
        <span>${m(e.name)}</span>
        <button class="ss-info-copy-btn" data-copy="${m(e.name)}" title="Copy key">${d}</button>
      </div>
      <div class="ss-info-var-val">
        ${a?`
          <input class="ss-input ss-cvar-input" value="${m(String(e.value))}" style="flex:1;height:22px;font-size:13px;padding:2px 6px;margin-right:4px;" />
          <button class="ss-var-btn ss-cvar-save" data-key="${m(e.name)}" title="Save">${t}</button>
          <button class="ss-var-btn ss-cvar-cancel" title="Cancel">${n}</button>
        `:`
          <span>${m(String(e.value))}</span>
          ${i?`<button class="ss-info-copy-btn ss-cvar-edit" data-key="${m(e.name)}" title="Edit value">${v}</button>`:``}
          <button class="ss-info-copy-btn" data-copy="${m(String(e.value))}" title="Copy value">${d}</button>
        `}
      </div>
    </div>
  `}function C(e,t,{settings:n,priorityKeys:r,projectSlug:i,filter:a,editingKey:o,editable:s}){let l=a.split(`,`).map(e=>e.trim().toLowerCase()).filter(Boolean),u=(e.tags||[]).filter(e=>!l.length||l.some(t=>e.name.toLowerCase().includes(t))),p=t.filter(e=>!l.length||l.some(t=>e.name.toLowerCase().includes(t)||String(e.value).toLowerCase().includes(t))),h=p.filter(e=>r.includes(e.name.toLowerCase())),g=``;return n.showProfile&&(g+=`
      <div class="ss-info-section" style="display:flex;align-items:center;gap:12px;background:var(--bg2);padding:12px;border-radius:12px;margin-bottom:16px;">
        ${e.photo?`<img src="${e.photo}" style="width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid var(--border);">`:`<div style="width:48px;height:48px;border-radius:50%;background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:20px;">👤</div>`}
        <div style="flex:1;overflow:hidden;">
          <div style="font-weight:800;font-size:16px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;">
            <span style="overflow:hidden;text-overflow:ellipsis;">${m(e.fullName||e.name||`Unnamed`)}</span>
            ${i?`<a href="https://messenger.smartsender.com/chats?project=${i}&selectedContactId=${e.id}" target="_blank" title="Open chat" style="color:var(--text4);text-decoration:none;display:inline-flex;margin-left:8px;flex-shrink:0;">${f}</a>`:``}
            <button class="ss-card-fire-btn" title="Fire Event" style="color:var(--accent);display:inline-flex;align-items:center;justify-content:center;padding:0;width:24px;height:24px;margin-left:6px;border-radius:6px;background:none;border:none;cursor:pointer;flex-shrink:0;">
              ${c}
            </button>
          </div>
          <div style="font-size:13px;color:var(--text4);">ID: <span style="color:var(--accent);font-weight:600;">${e.id}</span></div>
        </div>
      </div>
    `),n.showDetails&&(g+=`
      <div class="ss-info-section">
        <div class="ss-info-label">Basic Data</div>
        ${e.email?`<div class="ss-info-detail-row" title="Email: ${m(e.email)}"><span class="ss-info-detail-label">Email</span><div class="ss-info-detail-value"><span>${m(e.email)}</span><button class="ss-info-copy-btn" data-copy="${m(e.email)}" title="Copy email">${d}</button></div></div>`:``}
        ${e.phone?`<div class="ss-info-detail-row" title="Phone: ${m(e.phone)}"><span class="ss-info-detail-label">Phone</span><div class="ss-info-detail-value"><span>${m(e.phone)}</span><button class="ss-info-copy-btn" data-copy="${m(e.phone)}" title="Copy phone">${d}</button></div></div>`:``}
        <div class="ss-info-detail-row" title="Created: ${e.createdAt?new Date(e.createdAt).toLocaleString():``}"><span class="ss-info-detail-label">Created</span><div class="ss-info-detail-value"><span>${e.createdAt?new Date(e.createdAt).toLocaleDateString():`—`}</span></div></div>
      </div>
    `),h.length>0&&(g+=`
      <div class="ss-priority-section">
        <div class="ss-priority-label">Priority Variables</div>
        ${h.map(e=>S(e,o,s)).join(``)}
      </div>
    `),n.showTags&&(g+=`
      <div class="ss-info-accordion" id="ss-tags-accordion">
        <div class="ss-info-accordion-header"><span>Tags (${u.length})</span><span class="ss-info-accordion-icon">▾</span></div>
        <div class="ss-info-accordion-content">
          <div class="ss-info-tags">${u.map(e=>`<span class="ss-info-tag">${m(e.name)}</span>`).join(``)||`<div class="ss-hint">No tags matched</div>`}</div>
        </div>
      </div>
    `),n.showVars&&(g+=`
      <div class="ss-info-accordion" id="ss-vars-accordion">
        <div class="ss-info-accordion-header"><span>Variables (${p.length})</span><span class="ss-info-accordion-icon">▾</span></div>
        <div class="ss-info-accordion-content">
          <div class="ss-info-vars">${p.map(e=>S(e,o,s)).join(``)||`<div class="ss-hint">No variables matched</div>`}</div>
        </div>
      </div>
    `),g}function w(n,r,i){let a=r,o=null,s=``,c=new Set,l=!!(i.editable&&i.onSave);n.innerHTML=`
    ${i.settings.showVars||i.settings.showTags?`<div class="ss-info-search-sticky" style="padding:10px 16px;background:var(--bg-solid);border-bottom:1px solid var(--border);">
      <input class="ss-input ss-card-filter" type="text" placeholder="Filter variables..." style="font-size:13px;padding:6px 10px;height:28px;" />
    </div>`:``}
    <div class="ss-info-body ss-card-body"></div>
  `;let u=n.querySelector(`.ss-card-body`),d=()=>{let e=x(a);u.innerHTML=C(a,e,{...i,filter:s,editingKey:o,editable:l}),c.forEach(e=>u.querySelector(`#`+e)?.classList.add(`expanded`)),f()};function f(){u.querySelectorAll(`.ss-info-accordion-header`).forEach(e=>{e.onclick=()=>{let t=e.closest(`.ss-info-accordion`);c.has(t.id)?(c.delete(t.id),t.classList.remove(`expanded`)):(c.add(t.id),t.classList.add(`expanded`))}}),u.querySelectorAll(`[data-copy]`).forEach(n=>{n.onclick=r=>{r.stopPropagation(),e(n.dataset.copy,`Copy`,`Copied: ${n.dataset.copy}`);let i=n.innerHTML;n.innerHTML=t,setTimeout(()=>{n.innerHTML=i},1500)}}),u.querySelectorAll(`.ss-info-detail-row, .ss-info-var`).forEach(e=>{e.onclick=t=>{t.target.closest(`button`)||t.target.closest(`input`)||e.classList.toggle(`expanded`)}}),u.querySelectorAll(`.ss-card-fire-btn`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),t.preventDefault(),_({contactId:a.id,contactName:a.fullName||a.name||``,customRoot:e.closest(`#ss-sidebar`)||n.closest?.(`#ss-sidebar`)||n.getRootNode()})}}),l&&(u.querySelectorAll(`.ss-cvar-edit`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),o=e.dataset.key,c.add(`ss-vars-accordion`),d(),setTimeout(()=>u.querySelector(`.ss-cvar-input`)?.focus(),30)}}),u.querySelectorAll(`.ss-cvar-cancel`).forEach(e=>{e.onclick=e=>{e.stopPropagation(),o=null,d()}}),u.querySelectorAll(`.ss-cvar-save`).forEach(e=>{e.onclick=async n=>{n.stopPropagation();let r=e.dataset.key,s=e.closest(`.ss-info-var`).querySelector(`.ss-cvar-input`).value;e.disabled=!0,e.innerHTML=`<span class="ss-spinner" style="width:10px;height:10px;border-width:1px;"></span>`;try{let e=await i.onSave(r,s);e&&(a=e),o=null,d()}catch(n){e.disabled=!1,e.innerHTML=t;let r=e.closest(`.ss-info-var-val`);r&&r.insertAdjacentHTML(`beforeend`,`<span style="color:var(--error);font-size:11px;margin-left:6px;">${m(n.message)}</span>`)}}}),u.querySelectorAll(`.ss-cvar-input`).forEach(e=>{e.onkeydown=t=>{t.key===`Enter`&&e.closest(`.ss-info-var`).querySelector(`.ss-cvar-save`)?.click(),t.key===`Escape`&&e.closest(`.ss-info-var`).querySelector(`.ss-cvar-cancel`)?.click()}}))}d();let p=n.querySelector(`.ss-card-filter`);p&&(p.oninput=e=>{s=e.target.value,s.trim()&&(c.add(`ss-tags-accordion`),c.add(`ss-vars-accordion`)),d()})}var T=`ss_popup_queue`,E=`
  #ss-sidebar {
    position: relative !important;
    inset: auto !important;
    width: 100% !important;
    min-width: 0 !important;
    max-width: none !important;
    height: 100vh !important;
    transform: none !important;
    box-shadow: none !important;
    border: none !important;
    display: flex;
    flex-direction: column;
  }
  /* Sit above the #ss-sidebar::before frosted-glass layer (z-index:0). */
  .ssp-tabs, .ssp-content { position: relative; z-index: 1; }
  .ssp-tabs { display: flex; align-items: stretch; gap: 2px; padding: 6px 6px 0; background: var(--bg-solid); border-bottom: 1px solid var(--border); overflow-x: auto; flex-shrink: 0; }
  .ssp-tab { display: flex; align-items: center; gap: 6px; max-width: 200px; padding: 8px 10px; border-radius: 8px 8px 0 0; background: var(--bg2); color: var(--text4); font-family: var(--font-main); font-size: 13px; font-weight: 600; cursor: pointer; white-space: nowrap; border: 1px solid transparent; border-bottom: none; }
  .ssp-tab.active { background: var(--bg3); color: var(--text); }
  .ssp-tab-name { overflow: hidden; text-overflow: ellipsis; max-width: 130px; }
  .ssp-tab-close { display: inline-flex; align-items: center; justify-content: center; width: 16px; height: 16px; border-radius: 4px; opacity: 0.6; }
  .ssp-tab-close:hover { opacity: 1; background: rgba(255,255,255,0.1); }
  .ssp-tab-close svg { width: 12px; height: 12px; }
  .ssp-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
  .ssp-toolbar { display: flex; align-items: center; justify-content: space-between; padding: 8px 16px; border-bottom: 1px solid var(--border); background: var(--bg-solid); }
  .ssp-toolbar-title { font-family: var(--font-main); font-size: 14px; font-weight: 700; color: var(--text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .ssp-refresh { display: inline-flex; align-items: center; gap: 6px; padding: 6px 10px; border-radius: 8px; background: var(--bg3); color: var(--text2); font-family: var(--font-main); font-size: 12px; font-weight: 600; cursor: pointer; border: none; flex-shrink: 0; }
  .ssp-refresh:hover { background: var(--accent-bg); color: var(--accent); }
  .ssp-refresh svg { width: 14px; height: 14px; }
  .ssp-refresh.spinning svg { animation: ssp-spin 0.8s linear infinite; }
  @keyframes ssp-spin { to { transform: rotate(360deg); } }
  .ssp-empty { flex: 1; display: flex; align-items: center; justify-content: center; color: var(--text4); font-family: var(--font-main); font-size: 14px; padding: 24px; text-align: center; }
`,D=null,O=null,k=null,A=[],j=null;function M(e){return A.find(t=>t.contactId===e)}function N(){O.innerHTML=A.map(e=>`
    <div class="ssp-tab${e.contactId===j?` active`:``}" data-id="${m(e.contactId)}">
      <span class="ssp-tab-name">${m(e.name||e.contactId)}</span>
      <span class="ssp-tab-close" data-close="${m(e.contactId)}" title="Close tab">${n}</span>
    </div>
  `).join(``),O.querySelectorAll(`.ssp-tab`).forEach(e=>{e.onclick=t=>{t.target.closest(`[data-close]`)||F(e.dataset.id)}}),O.querySelectorAll(`[data-close]`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),I(e.dataset.close)}})}function P(){let e=M(j);if(!e){k.innerHTML=`<div class="ssp-empty">No contact open.<br>Select a contact in the side panel.</div>`;return}let t=e.data&&(e.data.fullName||e.data.name)||e.contactId;k.innerHTML=`
    <div class="ssp-toolbar">
      <div class="ssp-toolbar-title">${m(t)}</div>
      <button class="ssp-refresh" id="ssp-refresh-btn" title="Reload this contact's data">${r} Refresh</button>
    </div>
    <div class="ssp-card" id="ssp-card"></div>
  `,k.querySelector(`#ssp-refresh-btn`).onclick=()=>L(e.contactId,!0);let n=k.querySelector(`#ssp-card`);e.status===`loading`?n.innerHTML=`<div class="ss-loading" style="display:flex;padding:24px;"><div class="ss-spinner"></div><span class="ss-loading-text">Loading details...</span></div>`:e.status===`error`?n.innerHTML=`<div class="ss-error visible" style="margin:16px;">⚠ ${m(e.error||`Failed to load`)}</div>`:e.data&&w(n,e.data,{settings:y(),priorityKeys:u(e.projectSlug).split(`,`).map(e=>e.trim().toLowerCase()).filter(Boolean),projectSlug:e.projectSlug,editable:!0,onSave:async(t,n)=>{l.projectId=e.projectSlug,await g(e.contactId,t,n);let r=await p(e.contactId);return e.data=r,e.name=r.fullName||r.name||e.contactId,N(),r}})}function F(e){j=e,N(),P()}function I(e){let t=A.findIndex(t=>t.contactId===e);t!==-1&&(A.splice(t,1),j===e&&(j=A.length?A[Math.max(0,t-1)].contactId:null),N(),P())}async function L(e,t=!1){let n=M(e);if(!n||n.status===`ready`&&!t)return;n.status=`loading`,e===j&&P();let r=k.querySelector(`#ssp-refresh-btn`);t&&r&&r.classList.add(`spinning`);try{l.projectId=n.projectSlug;let t=await p(e);n.data=t,n.name=t.fullName||t.name||e,n.status=`ready`}catch(e){n.status=`error`,n.error=e.message}N(),e===j&&P()}function R(e,t){e=String(e);let n=M(e);n?F(e):(n={contactId:e,projectSlug:t,name:e,data:null,status:`idle`,error:null},A.push(n),F(e),L(e))}async function z(){let e=[];try{e=(await chrome.storage.session.get(T))[T]||[],await chrome.storage.session.set({[T]:[]})}catch{}e.forEach(e=>R(e.contactId,e.projectSlug))}async function B(){D=document.getElementById(`ss-popup-root`).attachShadow({mode:`open`});let e=document.createElement(`style`);e.textContent=i+E,D.appendChild(e);let t=document.createElement(`link`);t.rel=`stylesheet`,t.href=`https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap`,D.appendChild(t);let n=document.createElement(`div`);n.id=`ss-sidebar`,n.innerHTML=`<div class="ssp-tabs" id="ssp-tabs"></div><div class="ssp-content" id="ssp-content"></div>`,D.appendChild(n),o(D),O=D.getElementById(`ssp-tabs`),k=D.getElementById(`ssp-content`),await a(),s(),h(l.theme),N(),P(),chrome.runtime.onMessage.addListener(e=>{e?.type===`SS_POPUP_DRAIN`&&z()}),await z()}B();