var e=`@import "https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap";:host,#ss-sidebar{--bg-solid:#282828;--bg:#282828d9;--bg2:#303030b3;--bg3:#ffffff14;--bg4:#282828e6;--border:#ffffff14;--border2:#ffffff26;--text:#fff;--text2:#f2f2f7;--text3:#ebebf5;--text4:#ebebf599;--text5:#ebebf54d;--accent-rgb:10, 132, 255;--accent:#0a84ff;--accent2:#5e5ce6;--accent-bg:#0a84ff26;--accent-text:#fff;--success-rgb:48, 209, 88;--success:#30d158;--error-rgb:255, 69, 58;--error:#ff453a;--mark-bg:#0a84ff4d;--mark-text:#fff;--shadow:#0003;--blur-depth:40px;--font-main:"Outfit", sans-serif;--font-size-base:14px;--font-size-sm:13px;--font-size-xs:12px;--font-size-xxs:11px;--font-scale:1;--ss-panel-px:20px;--ss-panel-py:14px}#ss-sidebar *,#ss-sidebar :before,#ss-sidebar :after{box-sizing:border-box}.ss-no-transition{transition:none!important}#ss-sidebar{z-index:999999;width:420px;min-width:320px;max-width:800px;height:100vh;font-family:var(--font-main);background:0 0;flex-direction:column;transition:right .3s cubic-bezier(.4,0,.2,1);display:flex;position:fixed;top:0;right:-820px}#ss-sidebar:before{content:"";background:var(--bg);-webkit-backdrop-filter:blur(var(--blur-depth)) saturate(160%);box-shadow:none;border-left:1px solid var(--border);z-index:0;pointer-events:none;position:absolute;inset:0}.ss-header,.ss-body,.ss-footer,#ss-resize-handle{z-index:1;position:relative}#ss-sidebar.open{right:0}#ss-toast-container{z-index:9999999;pointer-events:none;flex-direction:column;gap:12px;display:flex;position:fixed;bottom:24px;right:24px}.ss-toast{pointer-events:auto;cursor:pointer;max-width:320px;font-family:var(--font-main);font-size:var(--font-size-sm);background:var(--bg-solid);border:1px solid rgba(var(--error-rgb), .4);color:var(--error);box-shadow:0 4px 16px var(--shadow);opacity:0;border-radius:11px;padding:10px 14px;font-weight:500;line-height:1.4;transition:all .3s cubic-bezier(.175,.885,.32,1.275);transform:translate(100%)}.ss-toast.visible{opacity:1;transform:translate(0)}.ss-toast.success{border:1px solid rgba(var(--success-rgb), .5);color:var(--success)}.ss-toast.info{border:1px solid rgba(var(--accent-rgb), .5);color:var(--accent)}.ss-modal-overlay{animation:.15s ease-out ss-fade-in;-webkit-backdrop-filter:blur(8px)!important;z-index:99999999!important;box-sizing:border-box!important;background:#000000c7!important;justify-content:center!important;align-items:center!important;width:100%!important;height:100%!important;padding:16px!important;display:flex!important;position:absolute!important;inset:0!important}@keyframes ss-fade-in{0%{opacity:0}to{opacity:1}}.ss-modal-box{width:100%;max-width:360px;animation:.15s ease-out ss-scale-in;background:#242426!important;background:var(--bg-solid,#242426)!important;border:1px solid var(--border2,#fff3)!important;z-index:100000000!important;color:var(--text,#fff)!important;border-radius:14px!important;flex-direction:column!important;display:flex!important;position:relative!important;overflow:hidden!important;box-shadow:0 16px 48px #000c!important}@keyframes ss-scale-in{0%{opacity:0;transform:scale(.94)}to{opacity:1;transform:scale(1)}}.ss-modal-header{border-bottom:1px solid var(--border,#ffffff1a);background:var(--bg-solid,#242426);justify-content:space-between;align-items:center;padding:14px 16px;display:flex}.ss-modal-title{color:var(--text,#fff);align-items:center;gap:8px;font-size:15px;font-weight:700;display:flex}.ss-modal-body{background:var(--bg-solid,#242426);flex-direction:column;gap:12px;padding:16px;display:flex}.ss-modal-footer{border-top:1px solid var(--border,#ffffff1a);background:var(--bg-solid,#242426);justify-content:flex-end;gap:8px;padding:12px 16px;display:flex}.ss-panel-search-wrapper{padding:12px var(--ss-panel-px);background:var(--bg-solid);border-bottom:1px solid var(--border);z-index:5;position:sticky;top:0}.ss-panel-search-input{border:1px solid var(--border2);background:var(--bg3);width:100%;color:var(--text);border-radius:9999px;outline:none;padding:8px 16px;font-size:13px;transition:all .2s ease-in-out}.ss-panel-search-input:focus{border-color:var(--accent);box-shadow:0 0 0 2px rgba(var(--accent-rgb), .4)}#ss-resize-handle{cursor:ew-resize;z-index:10;background:0 0;width:4px;height:100%;transition:background .15s;position:absolute;top:0;left:0}#ss-resize-handle:hover,#ss-resize-handle.dragging{background:rgba(var(--accent-rgb), .3)}#ss-extra-resize-handle{left:calc(var(--ss-extra-width,280px) * -1);cursor:ew-resize;z-index:10;background:0 0;width:4px;height:100%;transition:background .15s;display:none;position:absolute;top:0}#ss-sidebar:has(.ss-extra-panel.open) #ss-extra-resize-handle{display:block}#ss-extra-resize-handle:hover,#ss-extra-resize-handle.dragging{background:rgba(var(--accent-rgb), .3)}.ss-header{background:var(--bg-solid);border-bottom:1px solid var(--border);flex-shrink:0;padding:16px 16px 0}.ss-header-top{justify-content:space-between;align-items:flex-start;margin-bottom:10px;display:flex}.ss-title{color:var(--text);letter-spacing:-.03em;font-size:24px;font-weight:800;line-height:1}.ss-title span{color:var(--accent)}.ss-subtitle{font-size:var(--font-size-xxs);color:var(--text5);letter-spacing:.1em;text-transform:uppercase;font-family:var(--font-main);margin-top:3px}.ss-icon-btn,.ss-close{background:var(--bg3);color:var(--text4);cursor:pointer;border:none;border-radius:10px;justify-content:center;align-items:center;width:28px;height:28px;font-size:14px;transition:all .25s cubic-bezier(.2,.8,.2,1);display:flex}.ss-icon-btn:hover,.ss-close:hover{background:var(--border2);color:var(--text)}.ss-project-badge{background:var(--bg);border:1px solid var(--border);font-family:var(--font-main);font-size:var(--font-size-xxs);color:var(--text4);-webkit-user-select:none;user-select:none;border-radius:10px;align-items:center;gap:6px;padding:4px 9px;transition:all .2s;display:inline-flex}.ss-action-btn{background:var(--bg3);border:1px solid var(--border);color:var(--text3);cursor:pointer;border-radius:8px;padding:6px 12px;font-size:12px;font-weight:500;transition:all .2s}.ss-action-btn.active{background:var(--accent-bg);color:var(--accent);border-color:var(--accent)}.ss-text-link{color:var(--text4);text-transform:uppercase;letter-spacing:.05em;cursor:pointer;background:0 0;border:none;outline:none;padding:0;font-family:inherit;font-size:11px;font-weight:600;transition:color .2s}.ss-text-link:hover{color:var(--text2)}.ss-text-link.active{color:var(--accent)}.ss-project-badge:hover{background:var(--bg2);border-color:var(--accent);color:var(--text)}.ss-project-badge.active{border-color:var(--success);color:var(--success)}.ss-project-badge .dot{background:var(--success);width:6px;height:6px;box-shadow:0 0 5px var(--success);border-radius:50%}#ss-project-switcher-panel{width:280px;right:0;transform:translate(100%)}#ss-project-switcher-panel.open{pointer-events:auto;transform:translate(-100%)}.ss-hist-term.active{background:var(--bg2);border-left:2px solid var(--accent)}.ss-nav{background:var(--bg-solid);border-left:1px solid var(--border);border-right:1px solid var(--border);z-index:-1;pointer-events:none;flex-direction:column;width:180px;height:100%;padding:16px 0;transition:transform .3s cubic-bezier(.4,0,.2,1);display:flex;position:absolute;top:0;left:0}.ss-nav.open,.ss-info-panel.open{pointer-events:auto;transform:translate(-100%)}@media (width<=1000px){.ss-info-panel.open{left:-85vw}}.ss-info-panel{background:var(--bg-solid);border-left:1px solid var(--border);border-right:1px solid var(--border);z-index:-1;pointer-events:none;flex-direction:column;width:75ch;max-width:85vw;height:100%;padding:0;transition:transform .3s cubic-bezier(.4,0,.2,1);display:flex;position:absolute;top:0;left:0}.ss-info-header{border-bottom:1px solid var(--border);background:var(--bg2);justify-content:space-between;align-items:center;padding:16px;display:flex}.ss-info-title{color:var(--text);letter-spacing:-.01em;font-size:16px;font-weight:800}.ss-info-body{scrollbar-width:thin;scrollbar-color:var(--border) transparent;flex:1;padding:16px;overflow-y:auto}.ss-info-body::-webkit-scrollbar{width:4px}.ss-info-body::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}.ss-info-section{margin-bottom:20px}.ss-info-label{color:var(--text4);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px;font-size:13px;font-weight:700}.ss-info-detail-row{cursor:pointer;justify-content:space-between;align-items:center;gap:12px;min-width:0;margin-bottom:6px;display:flex}.ss-info-detail-label{color:var(--text3);flex-shrink:0;font-size:14px}.ss-info-detail-value{color:var(--text);text-align:right;text-overflow:ellipsis;white-space:nowrap;justify-content:flex-end;align-items:center;gap:4px;font-size:14px;font-weight:600;display:flex;overflow:hidden}.ss-info-vars-list{flex-direction:column;gap:4px;display:flex}.ss-info-var{background:var(--bg3);cursor:pointer;border:1px solid #0000;border-radius:6px;justify-content:space-between;align-items:center;gap:12px;min-width:0;margin-bottom:2px;padding:6px 8px;transition:all .2s;display:flex}.ss-info-var:hover{border-color:var(--border);background:var(--bg2)}.ss-info-var-name{font-size:var(--font-size-sm);color:var(--text4);font-family:var(--font-main);text-overflow:ellipsis;white-space:nowrap;flex-shrink:0;align-items:center;gap:4px;max-width:40%;display:flex;overflow:hidden}.ss-info-var-val{color:var(--text);text-align:right;text-overflow:ellipsis;white-space:nowrap;flex:1;justify-content:flex-end;align-items:center;gap:4px;font-size:14px;font-weight:600;display:flex;overflow:hidden}.ss-info-copy-btn{width:18px;height:18px;color:var(--text4);cursor:pointer;background:0 0;border:none;border-radius:4px;flex-shrink:0;padding:3px;transition:all .2s;display:none}.ss-info-copy-btn:hover{color:var(--accent);background:var(--bg3)}.ss-info-copy-btn svg{pointer-events:none;width:10px;height:10px}.ss-info-detail-row.expanded,.ss-info-var.expanded{flex-wrap:wrap}.ss-info-detail-row.expanded .ss-info-detail-value,.ss-info-var.expanded .ss-info-var-name,.ss-info-var.expanded .ss-info-var-val{white-space:normal;word-break:break-all;text-align:left;align-items:center;gap:6px;max-width:100%;display:flex;overflow:visible}.ss-info-detail-row.expanded .ss-info-copy-btn,.ss-info-var.expanded .ss-info-copy-btn{display:inline-flex}.ss-info-tags{flex-wrap:wrap;gap:6px;display:flex}.ss-info-tag{font-size:var(--font-size-xs);background:var(--bg3);border:1px solid var(--border);color:var(--text3);font-family:var(--font-main);border-radius:6px;padding:3px 8px}.ss-info-vars{flex-direction:column;gap:4px;display:flex}.ss-settings-panel{background:var(--bg-solid);border:1px solid var(--border);z-index:1000;border-radius:12px;flex-direction:column;gap:4px;width:180px;padding:8px;display:flex;position:absolute;top:36px;right:0;box-shadow:0 8px 24px #0003}.ss-settings-item{cursor:pointer;font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text3);border-radius:8px;justify-content:space-between;align-items:center;padding:8px 12px;display:flex}.ss-settings-item:hover{background:var(--bg2);color:var(--text)}.ss-settings-check{border:1px solid var(--border);border-radius:4px;justify-content:center;align-items:center;width:16px;height:16px;display:flex}.ss-settings-check.active{background:var(--success);border-color:var(--success);color:#fff}.ss-nav-item{color:var(--text3);font-family:var(--font-main);cursor:pointer;text-align:left;background:0 0;border:none;align-items:center;gap:10px;padding:11px 16px;font-size:15px;font-weight:600;transition:all .25s cubic-bezier(.2,.8,.2,1);display:flex}.ss-nav-item:hover,.ss-nav-item.active{background:var(--bg3);color:var(--text)}.ss-nav-icon{flex-shrink:0;justify-content:center;align-items:center;width:22px;height:22px;font-size:16px;display:flex}.ss-nav-icon svg{width:20px;height:20px}.ss-nav-item.disabled{opacity:.4;cursor:default;pointer-events:none}.ss-nav-soon{font-family:var(--font-main);font-size:var(--font-size-xxs);background:var(--bg3);color:var(--text5);text-transform:uppercase;letter-spacing:.05em;border-radius:4px;margin-left:auto;padding:1px 5px;font-weight:700}.ss-body{scrollbar-width:thin;scrollbar-color:var(--border) transparent;background:var(--bg-solid);flex:1;padding:14px;overflow-y:auto}.ss-body::-webkit-scrollbar{width:4px}.ss-body::-webkit-scrollbar-thumb{background:var(--border);border-radius:8px}.ss-section-label{font-size:var(--font-size-xs);letter-spacing:.12em;text-transform:uppercase;color:var(--text4);font-weight:700;font-family:var(--font-main);margin-bottom:8px}.ss-field-label{color:var(--text4);font-family:var(--font-main);font-size:var(--font-size-sm);margin-bottom:4px;display:block}.ss-hint{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text5);margin-top:4px}.ss-divider{background:var(--border);height:1px;margin:12px 0}.ss-empty{font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text5);text-align:center;border:1px dashed var(--border);border-radius:12px;padding:12px}.ss-input{background:var(--bg2);border:1px solid var(--border);color:var(--text);font-family:var(--font-main);font-size:var(--font-size-base);box-sizing:border-box;border-radius:8px;outline:none;width:100%;padding:8px 12px;transition:all .2s ease-in-out}.ss-input::placeholder{color:var(--text5)}.ss-input:focus{border-color:var(--accent);box-shadow:0 0 0 2px rgba(var(--accent-rgb), .4)}.ss-search-row{gap:8px;margin-bottom:6px;display:flex}.ss-search-row .ss-input{flex:1}.ss-btn-search{background:var(--accent);color:var(--accent-text);font-family:var(--font-main);font-size:var(--font-size-base);cursor:pointer;border:none;border-radius:8px;align-items:center;gap:6px;padding:8px 14px;font-weight:600;transition:all .2s ease-in-out;display:flex}.ss-btn-search:hover{background:var(--accent2)}.ss-btn-search:active{background:var(--accent)}.ss-btn-search:disabled{opacity:.4;cursor:not-allowed}.ss-btn-primary{background:var(--accent);width:100%;color:var(--accent-text);font-family:var(--font-main);cursor:pointer;border:none;border-radius:11px;margin-bottom:10px;padding:10px;font-size:15px;font-weight:700;transition:all .25s cubic-bezier(.2,.8,.2,1)}.ss-btn-primary:hover:not(:disabled){background:var(--accent2)}.ss-btn-primary:disabled{opacity:.3;cursor:not-allowed}.ss-preset-card{box-shadow:0 2px 10px var(--shadow);background:var(--bg2);border:1px solid var(--border);border-radius:12px;justify-content:space-between;align-items:center;margin-bottom:6px;padding:9px 11px;transition:all .25s cubic-bezier(.2,.8,.2,1);display:flex}.ss-preset-card:hover{border-color:var(--accent)}.ss-preset-card.active{border-color:var(--success);border-left:3px solid var(--success);box-shadow:0 0 0 1px var(--success)}.ss-preset-info{flex:1;min-width:0}.ss-preset-name{font-family:var(--font-main);font-size:var(--font-size-base);color:var(--text2);white-space:nowrap;text-overflow:ellipsis;font-weight:600;overflow:hidden}.ss-preset-meta{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text5);margin-top:2px}.ss-preset-delete{color:var(--text5);cursor:pointer;background:0 0;border:none;border-radius:8px;margin-left:8px;padding:0 4px;font-size:18px;transition:all .25s cubic-bezier(.2,.8,.2,1)}.ss-preset-delete:hover{color:var(--error);background:rgba(var(--error-rgb), .1)}.ss-tags-list{flex-direction:column;gap:6px;display:flex}.ss-tag-card{background:var(--bg2);border:1px solid var(--border);border-left:3px solid var(--text3);border-radius:11px;justify-content:space-between;align-items:center;padding:8px 11px;display:flex}.ss-tag-card-info{flex:1;min-width:0}.ss-tag-card-name{font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text2);white-space:nowrap;text-overflow:ellipsis;font-weight:600;overflow:hidden}.ss-tag-card-meta{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text5);margin-top:2px}.ss-tag-remove{color:var(--text5);cursor:pointer;background:0 0;border:none;padding:0 4px;font-size:18px;transition:color .15s}.ss-tag-remove:hover{color:var(--error)}.ss-dropdown{background:var(--bg2);-webkit-backdrop-filter:blur(12px)saturate(160%);box-shadow:0 8px 24px var(--shadow);border:1px solid var(--border);border-radius:12px;margin-top:4px;display:none;overflow:hidden}.ss-dropdown.visible{display:block}.ss-dropdown-hint{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text5);padding:6px 11px 3px}.ss-dropdown-item{cursor:pointer;border-bottom:1px solid var(--border);align-items:center;padding:8px 11px;transition:background .1s;display:flex}.ss-dropdown-item:last-child{border-bottom:none}.ss-dropdown-item:hover{background:var(--bg3)}.ss-dropdown-item-name{font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text2);white-space:normal;word-break:break-word}.ss-dropdown-item-id{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text5);margin-top:2px}.ss-dropdown-add{color:var(--text3);margin-left:8px;font-size:18px}.ss-dropdown-empty{font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text5);text-align:center;padding:11px}.ss-result{display:none}.ss-result.visible{display:block}.ss-result-card{background:var(--bg2);border:1px solid var(--border);text-align:center;border-radius:14px;padding:16px}.ss-result-label{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text4);text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px}.ss-result-count{color:var(--text);letter-spacing:-.03em;font-size:24px;font-weight:800;line-height:1;font-family:var(--font-main)}.ss-result-tags-used{flex-wrap:wrap;justify-content:center;gap:4px;margin-top:10px;display:flex}.ss-result-tag-chip{font-family:var(--font-main);font-size:var(--font-size-xs);background:var(--bg3);border:1px solid var(--border);color:var(--text3);border-radius:8px;padding:2px 7px}.ss-error{background:rgba(var(--error-rgb), .06);border:1px solid rgba(var(--error-rgb), .25);font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--error);border-radius:11px;margin-top:8px;padding:9px 11px;display:none}.ss-error.visible{display:block}.ss-loading{background:var(--bg2);border-radius:11px;align-items:center;gap:10px;margin-top:8px;padding:10px;display:none}.ss-loading.visible{display:flex}.ss-spinner{border:2px solid var(--border);border-top-color:var(--accent);border-radius:50%;width:13px;height:13px;animation:.7s linear infinite spin}.ss-loading-text{font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text4)}@keyframes spin{to{transform:rotate(360deg)}}.ss-spinning svg{animation:.8s linear infinite spin}.ss-var-card{background:var(--bg2);border:1px solid var(--border);cursor:pointer;border-radius:16px;transition:all .2s cubic-bezier(.2,.8,.2,1);overflow:hidden}.ss-var-card:hover{background:var(--bg3);border-color:var(--border2);box-shadow:0 2px 8px var(--shadow)}.ss-var-card.editing{background:var(--bg3);border-color:var(--accent);box-shadow:0 0 0 1px var(--accent)}.ss-var-card-main{justify-content:space-between;align-items:flex-start;gap:12px;padding:14px 16px;display:flex}.ss-var-info{flex:1;min-width:0}.ss-var-name{font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text2);white-space:nowrap;text-overflow:ellipsis;margin-bottom:2px;font-weight:600;overflow:hidden}.ss-var-value-preview{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--accent);white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.ss-var-card.editing .ss-var-value-preview{white-space:normal;text-overflow:unset;color:var(--accent);word-break:break-all;overflow:visible}.ss-var-actions{flex-shrink:0;align-items:center;gap:3px;padding-top:1px;display:flex}.ss-var-btn{cursor:pointer;background:var(--bg3);width:26px;height:26px;color:var(--text4);border:none;border-radius:8px;justify-content:center;align-items:center;transition:all .2s ease-in-out;display:flex}.ss-var-btn:hover{background:var(--border2);color:var(--text)}.ss-var-btn.active{background:var(--bg3);color:var(--text2)}.ss-var-btn-done{background:rgba(var(--accent-rgb), .12);color:var(--accent)}.ss-var-btn-done:hover{background:var(--accent);color:var(--accent-text)}.ss-var-btn-reset:hover{color:var(--error)}.ss-var-btn-copy:hover{color:var(--success)}.ss-var-status{border-radius:50%;flex-shrink:0;justify-content:center;align-items:center;width:22px;height:22px;font-size:14px;display:flex}.ss-var-status.empty{width:22px}.ss-var-status.success{color:var(--success);background:rgba(var(--success-rgb), .12);animation:.3s popIn}.ss-var-status.error{color:var(--error);background:rgba(var(--error-rgb), .1)}.ss-var-status.verifying{color:var(--accent);animation:.7s linear infinite spin}@keyframes popIn{0%{transform:scale(0)}70%{transform:scale(1.2)}to{transform:scale(1)}}.ss-var-edit-panel{border-top:1px solid var(--border);background:var(--bg4);padding:10px}.ss-var-textarea{box-sizing:border-box;background:var(--bg2);border:1px solid var(--accent);width:100%;min-height:80px;color:var(--text);font-family:var(--font-main);font-size:var(--font-size-sm);resize:vertical;border-radius:10px;outline:none;padding:8px;line-height:1.5;transition:border-color .15s}.ss-var-textarea:focus{border-color:var(--accent2);box-shadow:0 0 0 2px rgba(var(--accent-rgb), .1)}.ss-var-history-panel{border-top:1px solid var(--border);background:var(--bg4);padding:10px}.ss-var-panel-label{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text5);text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}.ss-history-item{background:var(--bg2);border:1px solid var(--border);cursor:pointer;border-radius:9px;margin-bottom:4px;padding:6px 8px;transition:border-color .1s}.ss-history-item:hover{border-color:var(--border2)}.ss-history-value{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text3);word-break:break-all;line-height:1.4}.ss-history-ts{font-family:var(--font-main);font-size:var(--font-size-xxs);color:var(--text5);margin-top:3px}.ss-var-btn-hist-search,.ss-var-btn-preset-open{background:var(--bg3);color:var(--text4);cursor:pointer;border:none;border-radius:9px;flex-shrink:0;justify-content:center;align-items:center;width:28px;height:36px;transition:all .25s cubic-bezier(.2,.8,.2,1);display:flex}.ss-var-btn-hist-search:hover,.ss-var-btn-preset-open:hover{background:var(--border2);color:var(--text)}.ss-search-hist-panel{-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);background:var(--bg2);border:1px solid var(--border);scrollbar-width:thin;scrollbar-color:var(--border) transparent;border-radius:12px;max-height:220px;margin-bottom:6px;overflow:hidden auto}.ss-hist-term{padding:var(--ss-panel-py) var(--ss-panel-px);font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text2);cursor:pointer;border-bottom:1px solid var(--border);transition:background .1s}.ss-hist-term:last-child{border-bottom:none}.ss-hist-term:hover{background:var(--bg3)}.ss-var-presets-panel{-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);background:var(--bg2);border:1px solid var(--border);scrollbar-width:thin;scrollbar-color:var(--border) transparent;border-radius:12px;max-height:300px;margin-bottom:6px;overflow:hidden auto}.ss-vpreset-item{padding:var(--ss-panel-py) var(--ss-panel-px);border-bottom:1px solid var(--border);align-items:center;gap:8px;transition:background .1s;display:flex}.ss-vpreset-item:last-child{border-bottom:none}.ss-vpreset-item:hover{background:var(--bg3)}.ss-vpreset-name{font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text2);white-space:nowrap;text-overflow:ellipsis;flex:1;font-weight:600;overflow:hidden}.ss-vpreset-count{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text5);margin-right:4px}.ss-vpreset-name-input{flex:1;padding:3px 7px!important;font-size:13px!important}.ss-vpreset-load:hover{color:var(--accent)}.ss-vpreset-delete:hover{color:var(--error)}.ss-card-preset-panel{border-top:1px solid var(--border);background:var(--bg4);animation:.15s slideDown}.ss-preset-list-inner{scrollbar-width:thin;scrollbar-color:var(--border) transparent;max-height:160px;overflow-y:auto}.ss-preset-toggle-row{border-bottom:1px solid var(--border);align-items:center;gap:6px;padding:6px 10px;transition:background .1s;display:flex}.ss-preset-toggle-row:last-child{border-bottom:none}.ss-preset-toggle-row:hover{background:var(--bg3)}.ss-preset-toggle-name{font-family:var(--font-main);font-size:var(--font-size-sm);color:var(--text2);white-space:nowrap;text-overflow:ellipsis;flex:1;overflow:hidden}.ss-preset-toggle-count{font-family:var(--font-main);font-size:var(--font-size-xs);color:var(--text5)}.ss-preset-toggle-btn{flex-shrink:0}.ss-preset-toggle-btn.active{color:var(--success);background:rgba(var(--success-rgb), .1)}.ss-var-btn-addpreset:hover{color:var(--accent)}.ss-var-btn-addpreset.active{color:var(--accent);background:var(--accent-bg)}.ss-var-btn-reset-search:hover{color:var(--error)}.ss-font-btn{color:var(--text4);font-family:var(--font-main);cursor:pointer;border:1px solid var(--border);border-radius:10px;justify-content:center;align-items:center;font-weight:700;transition:all .25s cubic-bezier(.2,.8,.2,1);display:flex}.ss-font-btn:hover{border-color:var(--border2);color:var(--text)}.ss-font-btn.active{border-color:var(--accent);color:var(--accent);background:var(--accent-bg)}#ss-sidebar .ss-var-btn-hist-search,#ss-sidebar .ss-var-btn-preset-open,#ss-sidebar .ss-var-btn-reset-search{border-radius:11px;width:36px;height:36px}#ss-sidebar .ss-btn-search{align-items:center;height:36px;padding-top:0;padding-bottom:0;display:flex}.ss-btn,.ss-btn-search,.ss-action-btn,.ss-var-btn,.ss-tab,.ss-select,.ss-input{box-sizing:border-box}.ss-action-btn{background:var(--bg3);color:var(--text4);font-size:var(--font-size-sm);cursor:pointer;text-transform:uppercase;letter-spacing:.05em;border:none;border-radius:8px;flex:1;justify-content:center;align-items:center;min-height:36px;padding:8px 16px;font-weight:600;transition:all .2s ease-in-out;display:flex}.ss-action-btn:hover{background:var(--border2);color:var(--text)}.ss-action-btn.active{background:var(--accent);color:var(--accent-text)}#ss-sidebar .ss-font-select{box-sizing:border-box;height:36px}.ss-footer{background:var(--bg-solid);border-top:1px solid var(--border);flex-shrink:0;padding:12px 16px}.ss-footer .ss-title{font-size:16px}.ss-footer .ss-subtitle{font-size:11px}.ss-theme-switch{width:40px;height:22px;display:inline-block;position:relative}.ss-theme-switch input{opacity:0;width:0;height:0}.ss-slider{cursor:pointer;background-color:var(--border2);border-radius:28px;transition:all .3s cubic-bezier(.2,.8,.2,1);position:absolute;inset:0;box-shadow:inset 0 1px 3px #0000001a}.ss-slider:hover{background-color:var(--text4)}.ss-slider:before{content:"";background-color:#fff;border-radius:50%;width:16px;height:16px;transition:all .3s cubic-bezier(.2,.8,.2,1);position:absolute;bottom:3px;left:3px;box-shadow:0 2px 4px #0003}input:checked+.ss-slider{background-color:var(--accent)}input:checked+.ss-slider:hover{background-color:var(--accent2)}input:checked+.ss-slider:before{transform:translate(18px)}.ss-extra-panel{height:100%;width:var(--ss-extra-width,280px);background:var(--bg-solid);border-left:1px solid var(--border);border-right:1px solid var(--border);z-index:-1;pointer-events:none;flex-direction:column;transition:transform .3s cubic-bezier(.4,0,.2,1);display:flex;position:absolute;top:0;left:0;overflow:hidden auto}.ss-extra-panel.open{pointer-events:auto;transform:translate(-100%)}.ss-extra-panel .ss-info-header{padding:16px var(--ss-panel-px);border-bottom:1px solid var(--border);background:var(--bg-solid);flex-shrink:0;justify-content:space-between;align-items:center;display:flex}.ss-extra-panel .ss-info-title{color:var(--text);letter-spacing:-.01em;font-size:16px;font-weight:800}.ss-extra-panel::-webkit-scrollbar{width:6px}.ss-extra-panel::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}.ss-mode-switch{width:32px;height:18px;display:inline-block;position:relative}.ss-mode-switch input{opacity:0;width:0;height:0}.ss-mode-slider{cursor:pointer;background-color:var(--error);border-radius:18px;transition:all .3s cubic-bezier(.2,.8,.2,1);position:absolute;inset:0;box-shadow:inset 0 1px 3px #0000001a}.ss-mode-slider:before{content:"";background-color:#fff;border-radius:50%;width:12px;height:12px;transition:all .3s cubic-bezier(.2,.8,.2,1);position:absolute;bottom:3px;left:3px;box-shadow:0 1px 3px #0003}input:checked+.ss-mode-slider{background-color:var(--accent)}input:checked+.ss-mode-slider:before{transform:translate(14px)}.ss-mode-switch.disabled{opacity:.5;pointer-events:none}.ss-info-accordion{border:1px solid var(--border);border-radius:10px;margin-bottom:10px;overflow:hidden}.ss-info-accordion-header{background:var(--bg2);cursor:pointer;color:var(--text2);-webkit-user-select:none;user-select:none;justify-content:space-between;align-items:center;padding:12px 14px;font-size:14px;font-weight:700;transition:background .2s;display:flex}.ss-info-accordion-header:hover{background:var(--bg3)}.ss-info-accordion-content{background:var(--bg-solid);padding:10px;display:none}.ss-info-accordion.expanded .ss-info-accordion-content{display:block}.ss-info-accordion-icon{color:var(--text5);transition:transform .2s}.ss-info-accordion.expanded .ss-info-accordion-icon{transform:rotate(180deg)}.ss-priority-section{background:rgba(var(--accent-rgb), .05);border:1px solid var(--accent);border-radius:10px;margin-bottom:16px;padding:12px}.ss-priority-label{color:var(--accent);text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px;font-size:11px;font-weight:800}#ss-settings-btn{color:var(--text4)}#ss-settings-btn:hover{color:var(--text2)}.ss-vpreset-config{color:var(--text4)}.ss-vpreset-config:hover{color:var(--text2);background:0 0}.ss-close{color:var(--text4);background:0 0;transition:color .2s}.ss-close:hover{color:var(--text2);background:0 0;transform:none}.ss-btn-search{color:var(--text4);transition:color .2s}.ss-btn-search:hover{color:var(--text2);background:0 0;transform:none}.ss-info-copy-btn:hover,.ss-copy-btn:hover,.ss-var-btn-copy:hover,.ss-var-btn-copy-name:hover,.ss-fav-tag-copy:hover,.ss-tag-copy-id-btn:hover{color:var(--accent);background:0 0}.ss-detected-vars{background:var(--bg2);border:1px solid var(--border);border-radius:8px;flex-wrap:wrap;gap:6px;margin-bottom:12px;padding:8px;display:flex}.ss-detected-vars-title{width:100%;color:var(--text4);text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;font-family:Roboto,sans-serif;font-size:11px}.ss-var-pill{font-size:var(--font-size-xs);background:var(--bg3);border:1px solid var(--border);color:var(--text3);font-family:var(--font-main);cursor:pointer;-webkit-user-select:none;user-select:none;border-radius:12px;padding:4px 10px;transition:all .2s}.ss-var-pill:hover{background:var(--bg-hover);color:var(--text);border-color:var(--border-hover)}.ss-var-pill.active{background:var(--accent);color:var(--accent-text);border-color:var(--accent)}.ss-var-pill-action{font-size:var(--font-size-xs);border:1px dashed var(--border);color:var(--accent);font-family:var(--font-main);cursor:pointer;background:0 0;border-radius:12px;padding:4px 10px;transition:all .2s}.ss-var-pill-action:hover{background:var(--accent);color:var(--accent-text);border-color:var(--accent)}.ss-info-tip{border:1px solid var(--text5);width:14px;height:14px;color:var(--text4);text-transform:none;letter-spacing:0;cursor:help;border-radius:50%;flex-shrink:0;justify-content:center;align-items:center;font-size:9px;font-style:normal;font-weight:700;transition:color .15s,border-color .15s;display:inline-flex;position:relative}.ss-info-tip:hover{color:var(--accent);border-color:var(--accent)}.ss-info-tip-box{background:var(--bg-solid);width:190px;color:var(--text3);border:1px solid var(--border2);text-align:left;text-transform:none;letter-spacing:normal;box-shadow:0 8px 24px var(--shadow);opacity:0;visibility:hidden;z-index:200;pointer-events:none;border-radius:8px;padding:9px 11px;font-family:Roboto,sans-serif;font-size:11px;font-weight:500;line-height:1.45;transition:opacity .15s,visibility .15s,transform .15s;position:absolute;top:calc(100% + 8px);transform:translateY(-4px)}.ss-info-tip:hover .ss-info-tip-box{opacity:1;visibility:visible;transform:translateY(0)}.ss-info-tip-box.is-left{left:-6px}.ss-info-tip-box.is-center{margin-left:-95px;left:50%}.ss-info-tip-box.is-right{right:-6px}#ss-sidebar svg{vertical-align:middle!important;visibility:visible!important;opacity:1!important;flex-shrink:0!important;min-width:0!important;max-width:none!important;min-height:0!important;max-height:none!important;display:inline-block!important}#ss-sidebar .ss-var-btn svg{width:auto!important;height:auto!important}`,t=`ss_contacts_favorites`,n=`ms_sidebar_width`,r=`ms_presets`,i=`ms_theme`,a=`ms_var_history`,o=e=>`ms_search_hist_${e}`,s=e=>`ss_tag_search_hist_${e}`,c=e=>`ss_contact_search_hist_${e}`,l=e=>`ms_var_presets_${e}`,u=`ss_contacts_display_settings`,d=e=>`ms_last_tab_${e}`,f=`ms_session_project_id`,p=`ms_latest_project_id`,m=`ss_global_settings`,h=`ss_tag_favorites`,g=e=>`ss_contact_priority_vars_${e}`,_=`ms_var_favorites`,ee=e=>`ss_event_history_${e}`,te=e=>`ss_funnel_snapshot_${e}`,ne=`ss_action_logs`,re=e=>y(te(e),null),ie=(e,t)=>b(te(e),t),v={};async function ae(){try{v=await chrome.storage.local.get(null)}catch(e){console.warn(`Storage access failed, using empty cache`,e),v={}}chrome.storage.onChanged.addListener((e,t)=>{if(t===`local`)for(let[t,{newValue:n}]of Object.entries(e))v[t]=n})}var y=(e,t)=>{try{let n=v[e];return n===void 0?t:typeof n==`string`&&(n.startsWith(`{`)||n.startsWith(`[`))?JSON.parse(n):n}catch{return t}},b=(e,t)=>{let n=typeof t==`object`?JSON.stringify(t):String(t);v[e]=n,chrome.storage.local.set({[e]:n})},oe=async e=>(await chrome.storage.session.get(e))[e]||null,se=()=>y(n,`500`),x=()=>y(r,[]),ce=e=>b(r,e),S=e=>x().find(t=>t.projectId===e)||null,le=()=>y(i,`dark`),ue=e=>b(i,e),de=e=>y(d(e),`vars`),fe=(e,t)=>{e&&b(d(e),t)},pe=(e,t)=>y(`ms_var_history`,{})[`${e}_${t}`]||[],me=(e,t,n)=>{try{let r=y(a,{}),i=`${e}_${t}`,o=r[i]||[];o.unshift({value:n,ts:new Date().toISOString()}),r[i]=o.slice(0,5),b(a,r)}catch{}},he=e=>y(o(e),[]),ge=(e,t)=>{try{let n=he(e).filter(e=>e!==t);n.unshift(t),b(o(e),n.slice(0,100))}catch{}},_e=e=>y(s(e),[]),ve=(e,t)=>{try{let n=_e(e).filter(e=>e!==t);n.unshift(t),b(s(e),n.slice(0,100))}catch{}},ye=e=>y(c(e),[]),be=(e,t)=>{try{let n=ye(e).filter(e=>e!==t);n.unshift(t),b(c(e),n.slice(0,100))}catch{}},xe=e=>{if(!e)return[];let t=y(ee(e),[]);return Array.isArray(t)?t:[]},Se=(e,t)=>{if(e)try{let n=xe(e).filter(e=>!(e.contactId==t.contactId&&e.name===t.name));n.unshift({...t,timestamp:Date.now()}),b(ee(e),n.slice(0,50))}catch{}},Ce=e=>{e&&b(ee(e),[])},C=e=>y(l(e),[]),w=(e,t)=>b(l(e),t),we=()=>y(u,{showProfile:!0,showDetails:!0,showTags:!0,showVars:!0,compactCards:!1}),Te=e=>b(u,e),Ee=()=>{let e=y(m,{useApiCache:!1,autoFetch:!1});return e.installId||(e.installId=crypto.randomUUID(),b(m,e)),e},T=e=>b(m,e),De=()=>y(t,[]),Oe=e=>b(t,e.slice(0,100)),ke=()=>y(h,[]),Ae=e=>b(h,e.slice(0,100)),E=e=>y(g(e),``),je=(e,t)=>b(g(e),t),Me=()=>y(_,[]),Ne=e=>b(_,e.slice(0,100)),Pe=()=>y(ne,[]),Fe=e=>b(ne,e),Ie=[r,m,i,u,n,t,h,_],Le=[`ms_var_presets_`,`ss_contact_priority_vars_`];function Re(e){return Ie.includes(e)||Le.some(t=>e.startsWith(t))}function ze(){let e={};for(let[t,n]of Object.entries(v))if(Re(t)){if(t===`ss_global_settings`){let r=n;try{r=typeof n==`string`?JSON.parse(n):n}catch{}if(r&&typeof r==`object`){let{installId:n,...i}=r;e[t]=JSON.stringify(i);continue}}e[t]=n}return e}function Be(e){let t=Ee(),n={};for(let[r,i]of Object.entries(e||{})){if(!Re(r))continue;let e=i;if(r===`ss_global_settings`){let n=i;try{n=typeof i==`string`?JSON.parse(i):i}catch{}n&&typeof n==`object`&&(e=JSON.stringify({...n,installId:t.installId}))}n[r]=e,v[r]=e}return n}var D={projectId:null,projectName:null,projectMode:`AUTO`,sidebarOpen:!1,sidebarWidth:`500px`,globalSettings:{},contactSettings:{},activeTab:`vars`,activePreset:null,editingProjectId:null,systemicNameLocked:!0,updatePending:!1,newVersion:null,latestVersion:null,fontSize:`regular`,view:`main`,navOpen:!1,tagResults:[],tagShowSearchHist:!1,tagShowFavorites:!1,tagFavorites:[],tagSearchPerformed:!1,varResults:[],varLoading:!1,isSearching:!1,varEditingId:null,varShowHistoryId:null,varShowSearchHist:!1,varShowFavorites:!1,varFavorites:[],varPresetsOpen:!1,varPresetEditing:null,varPresetPanelId:null,varPresetConfigPanelId:null,varViewingPresetId:null,contactResults:[],contactSearchTerm:``,selectedContactId:null,isSearchingContact:!1,contactSearchPerformed:!1,contactShowSearchHist:!1,contactSettingsOpen:!1,contactFavorites:[],contactInfoOpen:!1,contactInfoId:null,contactInfo:null,isFetchingContactInfo:!1,contactShowFavorites:!1,contactVarEditingKey:null,activeUrlContact:null,funnelResults:[],funnelSearchTerm:``,isSearchingFunnels:!1,theme:`dark`};function Ve(){D.projectMode=y(`ss_project_mode`,`AUTO`),D.sidebarOpen=se()!==`0`,D.sidebarWidth=se()===`0`?`500px`:se()||`500px`,D.globalSettings=Ee(),D.contactSettings=we(),D.contactFavorites=De(),D.varFavorites=Me(),D.tagFavorites=ke(),D.latestVersion=y(`ss_latest_version`,null),D.updatePending=y(`updatePending`,!1)===!0,D.newVersion=y(`newVersion`,null),D.theme=le()}var He=[],O=(e,t,n=null)=>{let r=Pe(),i=null;if(n)try{let e=JSON.stringify(n,null,2);i=e.length>5e3?e.substring(0,5e3)+`
...[truncated]`:e}catch{i=`Unserializable payload`}r.unshift({time:Date.now(),action:e,detail:t,project:D.projectId,payload:i,id:Date.now()+Math.random()}),r.length>1e3&&(r.length=1e3),Fe(r),He.forEach(e=>e())},k=null,Ue=e=>{k=e};function A(e,t){let n;return function(...r){clearTimeout(n),n=setTimeout(()=>e.apply(this,r),t)}}var j=e=>String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`),M=(e,t=`error`)=>{if(!k)return;let n=k.getElementById(`ss-toast-container`);n||(n=document.createElement(`div`),n.id=`ss-toast-container`,k.appendChild(n));let r=document.createElement(`div`);r.className=`ss-toast ${t}`,r.textContent=e,n.appendChild(r),r.offsetWidth,r.classList.add(`visible`);let i=()=>{r.classList.remove(`visible`),setTimeout(()=>r.remove(),300)};r.onclick=i,setTimeout(()=>{r.parentNode&&i()},3e3)},N=(e,t=`Copy Data`,n=``)=>(O(t,n||`Copied: ${e}`),navigator.clipboard.writeText(e).catch(()=>{let t=document.createElement(`textarea`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),t.remove()}));function We(){return k&&k.getElementById(`ss-sidebar`)||document.getElementById(`ss-extension-host`)}var Ge={dark:{"--bg-solid":`#282828`,"--bg":`rgba(40, 40, 40, 0.85)`,"--bg2":`rgba(48, 48, 48, 0.70)`,"--bg3":`rgba(255, 255, 255, 0.08)`,"--bg4":`rgba(40, 40, 40, 0.90)`,"--border":`rgba(255, 255, 255, 0.08)`,"--border2":`rgba(255, 255, 255, 0.15)`,"--text":`#ffffff`,"--text2":`#f2f2f7`,"--text3":`#ebebf5`,"--text4":`rgba(235, 235, 245, 0.6)`,"--text5":`rgba(235, 235, 245, 0.3)`,"--accent-rgb":`10, 132, 255`,"--accent":`#0a84ff`,"--accent2":`#5e5ce6`,"--accent-bg":`rgba(10, 132, 255, 0.15)`,"--accent-text":`#fff`,"--success-rgb":`48, 209, 88`,"--success":`#30d158`,"--error-rgb":`255, 69, 58`,"--error":`#ff453a`,"--mark-bg":`rgba(10, 132, 255, 0.3)`,"--mark-text":`#ffffff`,"--shadow":`rgba(0,0,0,0.2)`,"--blur-depth":`40px`,"--font-main":`'Outfit', sans-serif`},light:{"--bg-solid":`#f0f2f5`,"--bg":`rgba(255, 255, 255, 0.70)`,"--bg2":`rgba(255, 255, 255, 0.55)`,"--bg3":`rgba(0, 0, 0, 0.04)`,"--bg4":`rgba(245, 245, 250, 0.5)`,"--border":`rgba(0, 0, 0, 0.06)`,"--border2":`rgba(0, 0, 0, 0.14)`,"--text":`#0f172a`,"--text2":`#1e293b`,"--text3":`#475569`,"--text4":`#64748b`,"--text5":`#94a3b8`,"--accent-rgb":`37, 99, 235`,"--accent":`#2563eb`,"--accent2":`#3b82f6`,"--accent-bg":`rgba(37, 99, 235, 0.12)`,"--accent-text":`#fff`,"--success-rgb":`5, 150, 105`,"--success":`#059669`,"--error-rgb":`220, 38, 38`,"--error":`#dc2626`,"--mark-bg":`#bdd6ff`,"--mark-text":`#0040a0`,"--shadow":`rgba(0,0,0,0.06)`,"--blur-depth":`24px`,"--font-main":`'Outfit', sans-serif`}},Ke=[{name:`Blue`,value:`#0a84ff`},{name:`Indigo`,value:`#5e5ce6`},{name:`Purple`,value:`#bf5af2`},{name:`Pink`,value:`#ff375f`},{name:`Red`,value:`#ff453a`},{name:`Orange`,value:`#ff9f0a`},{name:`Green`,value:`#30d158`},{name:`Cyan`,value:`#64d2ff`}];function qe(e){let t=/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(e);return t?`${parseInt(t[1],16)}, ${parseInt(t[2],16)}, ${parseInt(t[3],16)}`:null}function Je(e,t){return e.split(`,`).map(e=>Math.max(0,Math.min(255,Math.round(parseInt(e,10)*t)))).join(`, `)}var Ye=new Set([`#ff9f0a`,`#30d158`,`#64d2ff`]);function Xe(e=D.theme){return Ge[e]?.[`--accent`]||`#0a84ff`}function Ze(e,t=D){let n=We(),r=qe(e);!n||!r||(n.style.setProperty(`--accent`,e),n.style.setProperty(`--accent-rgb`,r),n.style.setProperty(`--accent-bg`,`rgba(${r}, 0.15)`),n.style.setProperty(`--accent2`,`rgb(${Je(r,.8)})`),n.style.setProperty(`--mark-bg`,`rgba(${r}, ${t?.theme===`dark`?.3:.35})`),n.style.setProperty(`--accent-text`,Ye.has(e.toLowerCase())?`#000`:`#fff`))}function Qe(e,t=D){t.theme=e,ue(e);let n=Ge[e],r=We();r&&Object.entries(n).forEach(([e,t])=>r.style.setProperty(e,t));let i=t.globalSettings?.accentColor;i&&Ze(i,t)}var $e=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.60679 18C2.43395 19.4356 4.26831 19.9288 5.7039 19.1017C5.70488 19.1011 5.70582 19.1005 5.70681 19.1L6.15179 18.843C6.99179 19.5616 7.95732 20.119 8.99977 20.487V21C8.99977 22.6568 10.3429 24 11.9998 24C13.6566 24 14.9998 22.6568 14.9998 21V20.487C16.0424 20.1184 17.0079 19.5604 17.8478 18.841L18.2948 19.099C19.7307 19.9274 21.5664 19.4349 22.3948 17.999C23.2232 16.563 22.7307 14.7274 21.2948 13.899L20.8508 13.643C21.0506 12.5554 21.0506 11.4405 20.8508 10.353L21.2948 10.097C22.7307 9.26855 23.2232 7.43292 22.3948 5.99695C21.5664 4.56103 19.7307 4.06852 18.2948 4.89694L17.8498 5.15395C17.0089 4.43616 16.0427 3.87984 14.9998 3.513V3C14.9998 1.34316 13.6566 0 11.9998 0C10.3429 0 8.99977 1.34316 8.99977 3V3.513C7.95718 3.88158 6.9916 4.43958 6.15179 5.15902L5.70479 4.90003C4.26882 4.07156 2.4332 4.56408 1.60477 6C0.776353 7.43592 1.26882 9.27159 2.70479 10.1L3.14879 10.356C2.94892 11.4435 2.94892 12.5584 3.14879 13.646L2.70479 13.902C1.27281 14.7326 0.781931 16.5647 1.60679 18ZM11.9998 8.00002C14.2089 8.00002 15.9998 9.79088 15.9998 12C15.9998 14.2091 14.2089 16 11.9998 16C9.79065 16 7.99979 14.2091 7.99979 12C7.99979 9.79088 9.79065 8.00002 11.9998 8.00002Z" fill="currentColor"/></svg>`,P=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,et=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,F=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`,I=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_406_1903)"><path d="M11.9998 2.00033C14.6791 2.00914 17.2435 3.08934 19.1216 5.00023H15.9997C15.4474 5.00023 14.9997 5.44792 14.9997 6.00019C14.9997 6.55245 15.4474 7.00014 15.9997 7.00014H20.1425C21.1678 6.99958 21.9989 6.16851 21.9995 5.1432V1.00033C21.9995 0.448063 21.5518 0.000374387 20.9995 0.000374387C20.4472 0.000374387 19.9996 0.448063 19.9996 1.00033V3.07828C15.0828 -1.34972 7.50748 -0.953549 3.07948 3.96316C1.34661 5.88732 0.28375 8.32113 0.050179 10.9C-0.00119436 11.4538 0.40609 11.9443 0.959854 11.9957C0.989853 11.9985 1.01999 11.9999 1.05018 12C1.55702 12.0065 1.98549 11.6261 2.03916 11.122C2.50049 5.96292 6.82012 2.00712 11.9998 2.00033Z" fill="currentColor"/><path d="M22.9505 12.0002C22.4436 11.9937 22.0152 12.3741 21.9615 12.8782C21.4843 18.3724 16.6435 22.4396 11.1492 21.9623C8.77202 21.7559 6.54735 20.7049 4.87805 19H7.99997C8.55223 19 8.99992 18.5523 8.99992 18C8.99992 17.4478 8.55223 17.0001 7.99997 17.0001H3.85709C2.83206 16.9995 2.00072 17.83 2.00015 18.855C2.00015 18.8556 2.00015 18.8563 2.00015 18.857V22.9999C2.00015 23.5521 2.44784 23.9998 3.00011 23.9998C3.55237 23.9998 4.00006 23.5521 4.00006 22.9999V20.9219C8.91676 25.3499 16.4921 24.9538 20.9201 20.037C22.653 18.1129 23.7159 15.6791 23.9494 13.1001C24.0008 12.5464 23.5935 12.0558 23.0398 12.0045C23.0101 12.0018 22.9803 12.0003 22.9505 12.0002Z" fill="currentColor"/></g><defs><clipPath id="clip0_406_1903"><rect width="24" height="24" fill="white"/></clipPath></defs></svg>`,tt=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,L=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="vertical-align:middle;"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,nt=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_405_1640)"><path d="M23.5612 21.4454L18.9161 16.7983C22.3918 12.1535 21.4441 5.57052 16.7993 2.0948C12.1545 -1.38092 5.57153 -0.433205 2.09581 4.21157C-1.37991 8.85634 -0.432198 15.4393 4.21258 18.9151C7.94364 21.7071 13.0682 21.7071 16.7993 18.9151L21.4464 23.5622C22.0304 24.1462 22.9772 24.1462 23.5612 23.5622C24.1452 22.9782 24.1452 22.0314 23.5612 21.4474L23.5612 21.4454ZM10.5447 18.0181C6.41661 18.0181 3.0702 14.6717 3.0702 10.5437C3.0702 6.4156 6.41661 3.06919 10.5447 3.06919C14.6727 3.06919 18.0191 6.4156 18.0191 10.5437C18.0147 14.6698 14.6709 18.0137 10.5447 18.0181Z" fill="currentColor"/></g><defs><clipPath id="clip0_405_1640"><rect width="24" height="24" fill="white"/></clipPath></defs></svg>`,rt=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,it=`<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,at=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>`,ot=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M23 4.5C23 3.67158 22.3285 3 21.5 3H17.724C17.0921 1.20736 15.4007 0.00609375 13.5 0H10.5C8.59928 0.00609375 6.90789 1.20736 6.27602 3H2.5C1.67158 3 1 3.67158 1 4.5C1 5.32842 1.67158 6 2.5 6H3.00002V18.5C3.00002 21.5376 5.46245 24 8.5 24H15.5C18.5376 24 21 21.5376 21 18.5V6H21.5C22.3285 6 23 5.32842 23 4.5ZM18 18.5C18 19.8807 16.8807 21 15.5 21H8.5C7.1193 21 6.00002 19.8807 6.00002 18.5V6H18V18.5Z" fill="currentColor"/><path d="M9.5 18C10.3284 18 11 17.3284 11 16.5V10.5C11 9.67158 10.3284 9 9.5 9C8.67158 9 8 9.67158 8 10.5V16.5C8 17.3284 8.67158 18 9.5 18Z" fill="currentColor"/><path d="M14.5 18C15.3284 18 16 17.3284 16 16.5V10.5C16 9.67158 15.3284 9 14.5 9C13.6716 9 13 9.67158 13 10.5V16.5C13 17.3284 13.6716 18 14.5 18Z" fill="currentColor"/></svg>`,st=`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>`,ct=`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>`,R=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18.7068 6.70685L17.2928 5.29285L11.9998 10.5858L6.70685 5.29285L5.29285 6.70685L10.5858 11.9998L5.29285 17.2928L6.70685 18.7068L11.9998 13.4138L17.2928 18.7068L18.7068 17.2928L13.4138 11.9998L18.7068 6.70685Z" fill="currentColor"/></svg>`,lt=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,ut=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,dt=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>`,ft=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,pt=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>`,mt=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>`,ht=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>`,gt=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 3H2l8 9.46V19l4 2V12.46L22 3z"></path></svg>`,_t=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>`,vt=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>`,yt=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>`,bt=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`,z=`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>`,xt=()=>location.href,St=e=>{xt=e},Ct=()=>xt(),B=()=>new URL(xt()),wt=()=>{let e=B(),t=e.pathname.toLowerCase();if(t.includes(`/project/`)){let e=t.split(`/`),n=e.indexOf(`project`);if(n!==-1&&n+1<e.length)return e[n+1]}return e.searchParams.get(`project`)||null},Tt=()=>{let e=B(),t=e.pathname.toLowerCase();if(t.includes(`/contacts/`)){let e=t.split(`/`),n=e.indexOf(`contacts`);if(n!==-1&&n+1<e.length){let t=e[n+1];if(/^\d+$/.test(t))return t}}return e.searchParams.get(`selectedContactId`)||e.searchParams.get(`contactId`)||e.searchParams.get(`contact_id`)||null},V=()=>{let e=wt();if(e)return e;let t=B().pathname.match(/^\/([^/]+)/);return t&&t[1]&&t[1]!==`home`&&t[1]!==`dashboard`&&t[1]!==`projects`?t[1]:null},Et=()=>{try{return B().hostname.endsWith(`smartsender.com`)}catch{return!1}},Dt=e=>{D.projectMode=e,b(`ss_project_mode`,e),At()},Ot=e=>{D.projectId=e;let t=de(e);D.activeTab=t,En(t),U()},kt=(e,t=`center`)=>`<span class="ss-info-tip" tabindex="0">i<span class="ss-info-tip-box is-${t}">${e}</span></span>`;function H(){let e=k.getElementById(`ss-body`),t=D.editingProjectId?S(D.editingProjectId):null,n=t?t.projectId:D.projectId||``,r=t&&t.customName||``,i=t&&t.apiToken||``,a=(D.globalSettings.accentColor||Xe(D.theme)).toLowerCase(),o=!!D.globalSettings.accentColor;e.innerHTML=`
      <div style="margin-bottom:14px;">
        <div class="ss-section-label" style="margin-bottom:12px;">Appearance</div>
        <div style="display:flex;justify-content:space-between;align-items:flex-end;gap:12px;">
          <div style="display:flex;flex-direction:column;gap:6px;align-items:center;">
            <span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;color:var(--text5);font-family:Roboto,sans-serif;text-transform:uppercase;letter-spacing:0.05em;line-height:1;">${D.theme===`dark`?`Dark`:`Light`} Mode ${kt(`Switches the panel between a dark and light color theme.`,`left`)}</span>
            <label class="ss-theme-switch" title="Toggle Theme" style="flex-shrink:0;">
              <input type="checkbox" id="ss-theme-toggle-input"${D.theme===`dark`?` checked`:``}>
              <span class="ss-slider"></span>
            </label>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;align-items:center;">
            <span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;color:var(--text5);font-family:Roboto,sans-serif;text-transform:uppercase;letter-spacing:0.05em;line-height:1;">API Cache ${kt(`Caches SmartSender API responses locally so repeated lookups load instantly and use fewer API calls. Turn off if you always need fresh data.`,`center`)}</span>
            <label class="ss-theme-switch" title="Smart API Caching" style="flex-shrink:0;">
              <input type="checkbox" id="ss-cache-toggle-input"${D.globalSettings.useApiCache?` checked`:``}>
              <span class="ss-slider"></span>
            </label>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;align-items:center;">
            <span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;color:var(--text5);font-family:Roboto,sans-serif;text-transform:uppercase;letter-spacing:0.05em;line-height:1;">Auto Fetch ${kt(`Runs the search automatically as you type, so you do not need to press the Search button.`,`right`)}</span>
            <label class="ss-theme-switch" title="Search as you type" style="flex-shrink:0;">
              <input type="checkbox" id="ss-autofetch-toggle-input"${D.globalSettings.autoFetch?` checked`:``}>
              <span class="ss-slider"></span>
            </label>
          </div>
        </div>
        <div style="margin-top:16px;">
          <span style="font-size:11px;color:var(--text5);font-family:Roboto,sans-serif;text-transform:uppercase;letter-spacing:0.05em;">Accent Color</span>
          <div style="position:relative;margin-top:10px;">
            <select id="ss-accent-select" class="ss-input" style="appearance:none;cursor:pointer;width:100%;padding-left:34px;">
              <option value=""${o?``:` selected`}>Default (theme)</option>
              ${Ke.map(e=>`<option value="${e.value}"${o&&a===e.value.toLowerCase()?` selected`:``}>${e.name}</option>`).join(``)}
            </select>
            <span style="position:absolute;left:12px;top:50%;transform:translateY(-50%);width:14px;height:14px;border-radius:50%;background:${a};pointer-events:none;box-shadow:0 0 0 1px var(--border2);"></span>
            <svg style="position:absolute;right:8px;top:50%;transform:translateY(-50%);pointer-events:none;color:var(--text4);" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
          </div>
        </div>
      </div>
      <div class="ss-divider"></div>
      <div style="margin-top:14px;">
        <div class="ss-section-label">${D.editingProjectId?`Edit Project`:`Add Project`}</div>
        
        <label class="ss-field-label">Display Name (Optional)</label>
        <input class="ss-input" id="ss-preset-custom-name" type="text" placeholder="e.g. My Main Project" style="margin-bottom:12px;" value="${j(r)}" />

        <label class="ss-field-label">System Name (URL identifier)</label>
        <div style="position:relative;margin-bottom:12px;">
          <input class="ss-input" id="ss-preset-name" type="text" placeholder="newlook" 
                 style="padding-right:36px;${D.systemicNameLocked?`color:var(--text5);`:``}" 
                 value="${j(n)}" ${D.systemicNameLocked?`disabled`:``} />
          <button id="ss-lock-toggle" style="position:absolute;right:8px;top:50%;transform:translateY(-50%);background:none;border:none;color:${D.systemicNameLocked?`var(--text4)`:`var(--error)`};cursor:pointer;padding:4px;display:flex;align-items:center;justify-content:center;">
            ${D.systemicNameLocked?ut:dt}
          </button>
        </div>

        <label class="ss-field-label">API Token</label>
        <input class="ss-input" id="ss-preset-token" type="password" placeholder="••••••••••••••••" style="margin-bottom:12px;" value="${i?`********`:``}" />
        <div id="ss-preset-msg" style="display:none;font-size:13px;margin-bottom:8px;font-family:Roboto,sans-serif;"></div>
        <div style="display:flex;gap:8px;">
          <button class="ss-btn-primary" id="ss-preset-save" style="flex:1;">${D.editingProjectId?`Update`:`Save`} Project</button>
          ${D.editingProjectId?`<button class="ss-btn-search" id="ss-preset-cancel" style="background:var(--bg3);color:var(--text);border:1px solid var(--border);">Cancel</button>`:``}
        </div>
      </div>
      <div class="ss-divider"></div>
      <div style="margin-top:14px;">
        <div class="ss-section-label">Profile Backup</div>
        <div style="display:grid;grid-template-columns:3fr 1fr;gap:8px;">
          <button class="ss-btn-primary" id="ss-import-btn" style="min-width:0;height:38px;margin-bottom:0;box-sizing:border-box;justify-content:center;">Load Profile</button>
          <button class="ss-btn-search" id="ss-export-btn" style="min-width:0;height:38px;box-sizing:border-box;justify-content:center;background:var(--bg3);border:1px solid var(--border);color:var(--text);">Export</button>
        </div>
        <input type="file" id="ss-import-file" accept=".json" style="display:none;" />
      </div>
    `,k.getElementById(`ss-theme-toggle-input`).onchange=e=>{let t=e.target.checked?`dark`:`light`;Qe(t),O(`Change Theme`,`Theme changed to ${t}`),H()},k.getElementById(`ss-cache-toggle-input`).onchange=e=>{D.globalSettings.useApiCache=e.target.checked,T(D.globalSettings),O(`Settings`,`API Cache ${e.target.checked?`enabled`:`disabled`}`),e.target.checked?M(`API Cache enabled`,`info`):M(`API Cache disabled`,`info`)},k.getElementById(`ss-autofetch-toggle-input`).onchange=e=>{D.globalSettings.autoFetch=e.target.checked,T(D.globalSettings),O(`Settings`,`Auto Fetch ${e.target.checked?`enabled`:`disabled`}`),e.target.checked?M(`Auto Fetch enabled`,`info`):M(`Auto Fetch disabled`,`info`)};let s=k.getElementById(`ss-accent-select`);s&&(s.onchange=()=>{let e=s.value;e?(D.globalSettings.accentColor=e,T(D.globalSettings),Ze(e),O(`Settings`,`Accent color set to ${e}`)):(delete D.globalSettings.accentColor,T(D.globalSettings),Qe(D.theme),O(`Settings`,`Accent color reset to default`)),H()}),k.getElementById(`ss-lock-toggle`).onclick=()=>{D.systemicNameLocked=!D.systemicNameLocked,H()},D.editingProjectId&&(k.getElementById(`ss-preset-cancel`).onclick=()=>{D.editingProjectId=null,D.systemicNameLocked=!0,H()}),k.getElementById(`ss-export-btn`).onclick=()=>{let e=ze(),t=0;try{t=JSON.parse(e.ms_presets||`[]`).length}catch{t=0}let n={app:`mySender Tools`,kind:`profile-preset`,version:chrome.runtime.getManifest().version,exportedAt:new Date().toISOString(),data:e},r=new Blob([JSON.stringify(n,null,2)],{type:`application/json`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=`mysender_preset_${new Date().toISOString().split(`T`)[0]}.json`,a.click(),URL.revokeObjectURL(i),O(`Data Management`,`Preset exported (${t} project${t===1?``:`s`})`),M(`Preset exported`,`info`)},k.getElementById(`ss-import-btn`).onclick=()=>k.getElementById(`ss-import-file`).click(),k.getElementById(`ss-import-file`).onchange=e=>{let t=e.target.files[0];if(!t)return;let n=new FileReader;n.onload=e=>{try{let t=JSON.parse(e.target.result),n=Be(t&&t.data&&typeof t.data==`object`?t.data:t);if(!Object.keys(n).length){M(`No valid profile data in file`,`error`);return}chrome.storage.local.set(n,()=>{O(`Data Management`,`Profile loaded successfully`),M(`Profile loaded. Reloading…`,`info`),setTimeout(()=>location.reload(),1500)})}catch{M(`Invalid preset file`,`error`)}},n.readAsText(t),e.target.value=``},k.getElementById(`ss-preset-save`).onclick=()=>{let e=k.getElementById(`ss-preset-name`).value.trim(),t=k.getElementById(`ss-preset-custom-name`).value.trim(),n=k.getElementById(`ss-preset-token`).value.trim(),r=k.getElementById(`ss-preset-msg`);if(!e){r.textContent=`⚠ System name required`,r.style.cssText=`display:block;color:var(--error);font-size:13px;margin-bottom:8px;font-family:Roboto,sans-serif;`;return}let i=x();if(n===`********`){let t=i.find(t=>t.projectId===(D.editingProjectId||e));n=t?t.apiToken:``}let a={projectId:e,apiToken:n,name:e,customName:t};if(D.editingProjectId&&D.editingProjectId!==e){let e=i.findIndex(e=>e.projectId===D.editingProjectId);e>=0&&i.splice(e,1)}let o=i.findIndex(t=>t.projectId===e);o>=0?i[o]=a:i.push(a),ce(i),e===D.projectId&&(D.activePreset=a,D.projectName=t||e,wn()),r.textContent=`✅ Saved!`,r.style.cssText=`display:block;color:var(--success);font-size:13px;margin-bottom:8px;font-family:Roboto,sans-serif;`,D.editingProjectId=null,D.systemicNameLocked=!0,setTimeout(()=>{r.style.display=`none`,H()},1500),U()}}function U(){let e=k.getElementById(`ss-project-switcher-panel`);if(!e)return;let t=x();e.innerHTML=`
      <div class="ss-info-header">
        <div class="ss-info-title">Switch Project</div>
        <button class="ss-close" id="ss-project-switcher-close">${R}</button>
      </div>
      <div class="ss-panel-list-content" style="flex:1;overflow-y:auto;">
        ${t.length?t.map((e,t)=>`
        <div class="ss-hist-term ${D.projectId===e.projectId?`active`:``}" style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding: 10px 14px;border-bottom:1px solid var(--border);">
          <div style="min-width:0;flex:1;cursor:pointer;" class="ss-project-select-trigger" data-pid="${e.projectId}">
            <div style="font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text);">${j(e.customName||e.name)}</div>
            ${e.customName?`<div style="font-size:11px;color:var(--text5);">${j(e.projectId)}</div>`:``}
          </div>
          <div style="display:flex;gap:4px;">
            <button class="ss-project-edit-btn" data-pid="${e.projectId}" style="background:none;border:none;color:var(--text4);cursor:pointer;padding:4px;display:flex;align-items:center;justify-content:center;transition:color 0.2s;" title="Edit Project">${st}</button>
            <button class="ss-preset-delete" data-index="${t}" style="background:none;border:none;color:var(--text5);cursor:pointer;font-size:18px;padding:4px;display:flex;align-items:center;justify-content:center;transition:color 0.2s;">${R}</button>
          </div>
        </div>
      `).join(``):`<div class="ss-empty" style="border:none;padding:12px;">No projects saved. Click below to add one.</div>`}
      </div>
      <div style="padding: 16px; border-top: 1px solid var(--border); background: var(--bg);">
        <button class="ss-btn-primary" id="ss-project-add-btn" style="width: 100%; justify-content: center; gap: 8px;">
          <span style="font-size: 18px; line-height: 1;">+</span>
          <span>Add Project</span>
        </button>
      </div>
    `,k.getElementById(`ss-project-switcher-close`).onclick=()=>{$(`ss-project-switcher-panel`)},e.querySelectorAll(`.ss-project-select-trigger`).forEach(t=>{t.onclick=()=>{Dt(`MANUAL`),e.classList.remove(`open`),Ot(t.dataset.pid)}}),e.querySelectorAll(`.ss-project-edit-btn`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),D.editingProjectId=e.dataset.pid,D.systemicNameLocked=!0,Q(`settings`)}}),e.querySelectorAll(`.ss-preset-delete`).forEach(e=>{e.onclick=t=>{t.stopPropagation();let n=parseInt(e.dataset.index),r=x(),i=r[n].projectId;r.splice(n,1),ce(r),D.editingProjectId===i&&(D.editingProjectId=null),U(),D.view===`settings`&&H()}}),k.getElementById(`ss-project-add-btn`).onclick=()=>{D.editingProjectId=null,D.systemicNameLocked=!1,Q(`settings`)}}function At(){let e=k.getElementById(`ss-mode-text`),t=k.getElementById(`ss-mode-checkbox`),n=k.getElementById(`ss-mode-switch-label`);if(!e||!t||!n)return;let r=D.projectMode===`AUTO`;Et()?(n.classList.remove(`disabled`),t.disabled=!1,r?(e.textContent=`AUTO`,e.style.color=`var(--accent)`,t.checked=!0):(e.textContent=`MANUAL`,e.style.color=`var(--error)`,t.checked=!1)):(n.classList.add(`disabled`),t.disabled=!1,e.textContent=`MANUAL`,e.style.color=`var(--text5)`,t.checked=!1)}var jt=new Map,Mt=e=>{if(!D.globalSettings.useApiCache)return null;let t=jt.get(e);return t&&Date.now()-t.ts<300*1e3?t.data:null},Nt=(e,t)=>{jt.set(e,{data:t,ts:Date.now()})},W=()=>{let e=S(D.projectId)?.apiToken;return e?{Accept:`application/json`,Authorization:`Bearer ${e}`}:null};function G(e,t=`GET`,n={},r=null){let i=e.split(`?`)[0];return new Promise((a,o)=>{try{chrome.runtime.sendMessage({type:`API_REQUEST`,url:e,method:t,headers:n,body:r},n=>{if(chrome.runtime.lastError){let n=chrome.runtime.lastError.message;return O(`API Error`,`${t} ${i} - Extension Error`,{url:e,method:t,body:r,error:n}),n.includes(`context invalidated`)?o(Error(`Extension was updated 🔄 Please refresh this page to continue.`)):o(Error(n))}if(!n?.ok)return O(`API Error`,`${t} ${i} - HTTP ${n?.status}`,{url:e,method:t,body:r,status:n?.status,error:n?.error}),o(Error(n?.error||`HTTP ${n?.status}`));O(`API Request`,`${t} ${i} - Success`,{url:e,method:t,body:r,status:n.status,response:n.data}),a(n.data)})}catch(n){O(`API Error`,`${t} ${i} - Catch Error`,{url:e,method:t,body:r,error:n.message}),n.message.includes(`context invalidated`)?o(Error(`Extension was updated 🔄 Please refresh this page to continue.`)):o(n)}})}var Pt=[],Ft=()=>{if(!k)return;let e=k.getElementById(`ss-footer-version`);if(!e)return;let t=chrome.runtime.getManifest().version;D.updatePending?e.innerHTML=`<span style="color:var(--error);font-weight:700;">v${t} (Update Ready)</span>`:e.innerHTML=`v${t}`},It=()=>{try{chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&(!(`updatePending`in e)&&!(`newVersion`in e)||(`updatePending`in e&&(D.updatePending=e.updatePending.newValue===!0),`newVersion`in e&&(D.newVersion=e.newVersion.newValue||null),Ft(),Pt.forEach(e=>e())))})}catch(e){console.log(`Update watcher init failed:`,e)}},Lt=(e=!1)=>{let t=y(`ss_last_update_check`,0),n=Date.now();if(!(!e&&n-t<1440*60*1e3))try{chrome.runtime.sendMessage({type:`CHECK_FOR_UPDATES`},e=>{!chrome.runtime.lastError&&e&&e.version&&(D.latestVersion=e.version,b(`ss_latest_version`,e.version),b(`ss_last_update_check`,n),Ft(),Pt.forEach(e=>e()))})}catch(e){console.log(`Update check failed:`,e)}};async function Rt(e,t){let n=`tags_${e}_${t}`,r=Mt(n);if(r)return r;let i=S(e);if(!i?.apiToken)throw Error(`No API token. Open Settings ⚙`);let a=[],o=1,s=1;for(;o<=s;){let e=await G(`https://api.smartsender.com/v1/tags?${new URLSearchParams({page:o,limitation:20,term:t})}`,`GET`,{Accept:`application/json`,Authorization:`Bearer ${i.apiToken}`});a.push(...e.collection||[]),s=e.cursor?.pages??1,o++}let c=t.toLowerCase().trim(),l=a.filter(e=>e.name.toLowerCase().trim()===c),u={collection:l.length?l:a.filter(e=>e.name.toLowerCase().includes(c)),isExact:l.length>0};return Nt(n,u),u}async function zt(e){let t=`defs_${D.projectId}_${e}`,n=Mt(t);if(n)return n;let r=W();if(!r)throw Error(`No API token. Open Settings ⚙`);let i=(await G(`https://api.smartsender.com/v1/definitions?${new URLSearchParams({page:1,limitation:20,term:e})}`,`GET`,r)).collection||[];return Nt(t,i),i}async function Bt(e){let t=W();if(!t)throw Error(`No API token.`);let n=[];for(let r of e)try{let e=await G(`https://api.smartsender.com/v1/definitions/${r}`,`GET`,t);e&&n.push(e)}catch{}return n}async function Vt(e,t,n){let r=W();if(!r)throw Error(`No API token.`);return G(`https://api.smartsender.com/v1/definitions/${e}`,`PUT`,{...r,"Content-Type":`application/json`},JSON.stringify({name:t,value:n}))}async function Ht(e,t){let n=W();if(!n)return!1;try{let r=D.varResults.find(t=>t.id===e);return r?((await G(`https://api.smartsender.com/v1/definitions?${new URLSearchParams({page:1,limitation:20,term:r.name})}`,`GET`,n)).collection||[]).find(t=>t.id===e)?.value===t:!1}catch{return!1}}async function Ut(e=``){let t=W();if(!t)throw Error(`No API token. Open Settings ⚙`);let n=[],r=1,i=1;for(;r<=i;){let a=new URLSearchParams({page:r,limitation:20});e&&e.trim()&&a.set(`term`,e.trim());let o=await G(`https://api.smartsender.com/v1/funnels?${a}`,`GET`,t),s=o?.collection||(Array.isArray(o)?o:[]);if(n.push(...s),i=o?.cursor?.pages??(s.length===20?r+1:r),r++,r>20)break}return n.map(e=>{let t=e.flow||{};return{id:e.id,name:t.name||e.name||`Funnel #${e.id}`,runs:t.runsQuantity??e.runsQuantity??e.runs??0,active:t.active===void 0?e.active===void 0?!e.isDraft:e.active:t.active,isDraft:t.isDraft===void 0?e.isDraft||!1:t.isDraft,updatedAt:e.updatedAt||t.updatedAt||null}})}function Wt(){let e=k.getElementById(`ss-body`),t=``,n=new Set;location.href.startsWith(`https://messenger.smartsender.com/funnels/`)&&document.querySelectorAll(`.variable-template`).forEach(e=>{let t=e.closest(`span`);if(t){let e=t.querySelector(`.formatted-value`);if(!e&&t.parentElement&&(e=t.parentElement.querySelector(`.formatted-value`)),e){let t=e.textContent.trim();t&&t!==`null`&&t!==`undefined`&&n.add(t)}}}),n.size>0&&(t=`
        <div class="ss-detected-vars" id="ss-detected-vars-container">
          <div class="ss-detected-vars-title">Detected on page:</div>
          ${Array.from(n).map(e=>`<div class="ss-var-pill" data-val="${j(e)}">${j(e)}</div>`).join(``)}
          <div class="ss-var-pill-action" id="ss-var-pill-select-all">Select All</div>
        </div>
      `),e.innerHTML=`
      <div style="margin-bottom:12px;">
        <div style="display:flex;gap:12px;align-items:center;margin-bottom:8px;">
          <span class="ss-text-link" id="ss-var-hist-btn">HISTORY</span>
          <span class="ss-text-link" id="ss-var-preset-btn">PRESETS</span>
          <span class="ss-text-link" id="ss-var-fav-tab-btn" style="${D.varFavorites.length>0?``:`display:none;`}">FAVORITES</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:8px;">
          <input class="ss-input" id="ss-var-input" type="text" placeholder="name1, name2, name3" autocomplete="off" style="width:100%;box-sizing:border-box;" />
          <div style="display:flex;gap:8px;align-items:center;">
            <button class="ss-btn-search" id="ss-var-btn" title="Search" style="flex:1;justify-content:center;background:var(--accent);color:var(--accent-text);">Search</button>
            <button class="ss-btn-search" id="ss-var-reset-btn" title="Reset Search" style="width:auto;padding:8px 12px;justify-content:center;background:var(--bg3);color:var(--text2);">${I.replace(`width="24" height="24"`,`width="16" height="16"`)}</button>
          </div>
        </div>
        ${t}
      </div>
      <div id="ss-var-list" style="display:flex;flex-direction:column;gap:6px;"></div>
      <div class="ss-error" id="ss-var-error"></div>
      <div class="ss-loading" id="ss-var-loading" style="display:none;"><div class="ss-spinner"></div><span class="ss-loading-text">Searching...</span></div>
    `;let r=k.getElementById(`ss-var-input`),i=k.getElementById(`ss-var-btn`),a=k.getElementById(`ss-var-list`),o=k.getElementById(`ss-var-error`),s=k.getElementById(`ss-var-loading`),c=k.getElementById(`ss-var-search-hist`),l=k.getElementById(`ss-var-presets-panel`),u=k.getElementById(`ss-var-fav-panel`),d=()=>{let e=Array.from(k.querySelectorAll(`.ss-var-pill.active`)).map(e=>e.dataset.val);r.value=e.join(`, `),e.length>0?D.globalSettings.autoFetch&&_():r.dispatchEvent(new Event(`input`))};k.querySelectorAll(`.ss-var-pill`).forEach(e=>{e.onclick=()=>{e.classList.toggle(`active`),d()}});let f=k.getElementById(`ss-var-pill-select-all`);f&&(f.onclick=()=>{k.querySelectorAll(`.ss-var-pill`).forEach(e=>e.classList.add(`active`)),d()});let p=e=>{o.textContent=`⚠ ${e}`,o.classList.add(`visible`),setTimeout(()=>o.classList.remove(`visible`),5e3)};function m(){if(D.varShowSearchHist=!D.varShowSearchHist,!D.varShowSearchHist){c.classList.remove(`open`),k.getElementById(`ss-var-hist-btn`).classList.remove(`active`);return}D.varPresetsOpen=!1,l.classList.remove(`open`),k.getElementById(`ss-var-preset-btn`).classList.remove(`active`),D.varShowFavorites=!1,u.classList.remove(`open`),k.getElementById(`ss-var-fav-tab-btn`).classList.remove(`active`),k.getElementById(`ss-var-hist-btn`).classList.add(`active`);let e=he(D.projectId),t=(n=``)=>{let i=e.filter(e=>e.toLowerCase().includes(n.toLowerCase())),a=i.length?i.map((e,t)=>`<div class="ss-hist-term" data-term="${j(e)}">${j(e)}</div>`).join(``):`<div class="ss-hist-term" style="opacity:0.5;cursor:default;">${n?`No matches`:`No history`}</div>`;c.innerHTML=`
          <div class="ss-info-header">
            <div class="ss-info-title">Search History</div>
            <button class="ss-close ss-close-extra-panel">${R}</button>
          </div>
          <div class="ss-panel-search-wrapper">
            <input type="text" class="ss-panel-search-input" id="ss-var-hist-filter" placeholder="Quick search..." value="${j(n)}">
          </div>
          <div class="ss-panel-list-content">
            ${a}
          </div>
        `;let o=c.querySelector(`#ss-var-hist-filter`);o.focus(),o.oninput=e=>t(e.target.value),c.querySelectorAll(`.ss-hist-term[data-term]`).forEach(e=>{e.onclick=()=>{r.value=e.dataset.term,m(),_()}})};t(),$(`ss-var-search-hist`)}function h(){if(D.varPresetsOpen=!D.varPresetsOpen,!D.varPresetsOpen){l.classList.remove(`open`),k.getElementById(`ss-var-preset-btn`).classList.remove(`active`);return}D.varShowSearchHist=!1,c.classList.remove(`open`),k.getElementById(`ss-var-hist-btn`).classList.remove(`active`),D.varShowFavorites=!1,u.classList.remove(`open`),k.getElementById(`ss-var-fav-tab-btn`).classList.remove(`active`),k.getElementById(`ss-var-preset-btn`).classList.add(`active`),$(`ss-var-presets-panel`);let e=D.projectId;function t(){let n=C(e);if(l.innerHTML=`
          <div class="ss-info-header">
            <div class="ss-info-title">Presets</div>
            <div style="display:flex;gap:4px;align-items:center;">
              <button class="ss-close ss-close-extra-panel">${R}</button>
            </div>
          </div>
          ${n.length===0?`<div class="ss-empty" style="border:none;padding:10px;">No presets yet</div>`:n.map((e,t)=>`
              <div class="ss-vpreset-item" data-pi="${t}">
                ${D.varPresetEditing===t?`
                  <input class="ss-input ss-vpreset-name-input" data-pi="${t}" value="${j(e.name)}" style="flex:1;padding:4px 8px;font-size:13px;" />
                  <button class="ss-var-btn ss-vpreset-name-save" data-pi="${t}" title="Save name">${F}</button>
                `:`
                  <span class="ss-vpreset-name" title="Click to load" style="cursor:pointer;flex:1;" data-load-pi="${t}"><b>${j(e.name)}</b></span>
                  <span class="ss-vpreset-count">${e.ids.length} vars</span>
                `}
                <button class="ss-var-btn ss-vpreset-config" data-pi="${t}" title="Configure Preset" style="background:none;">${$e.replace(`width="24" height="24"`,`width="14" height="14"`)}</button>
                ${D.varPresetConfigPanelId===t?`<button class="ss-var-btn ss-vpreset-edit" data-pi="${t}" title="Rename">${st}</button>`:``}
                <button class="ss-var-btn ss-vpreset-delete" data-pi="${t}" title="Delete" style="background:none;">${ot.replace(`width="24" height="24"`,`width="18" height="18"`)}</button>
              </div>
              ${D.varPresetConfigPanelId===t?`
                <div style="padding:6px 10px;background:var(--bg4);border-bottom:1px solid var(--border);">
                  <div id="ss-preset-cfg-list-${t}" style="margin-bottom:8px;font-size:13px;color:var(--text3);max-height:120px;overflow-y:auto;">
                      Loading variables...
                  </div>

                </div>
              `:``}
              `).join(``)}
          <!-- Save / Create preset -->
          <div style="padding:8px 16px;border-top:1px solid var(--border);">
            <div style="display:flex;gap:6px;align-items:center;">
              <input class="ss-input" id="ss-new-preset-name" placeholder="Preset name..." style="flex:1;padding:6px 8px;font-size:13px;" />
              <button class="ss-var-btn ss-new-preset-save" title="Save">${ft}</button>
            </div>
          </div>
        `,l.querySelector(`.ss-new-preset-save`)?.addEventListener(`click`,()=>{let n=k.getElementById(`ss-new-preset-name`),r=n?.value.trim();if(!r){n?.focus();return}let i=C(e),a=D.varResults.length>0?D.varResults.map(e=>e.id):[],o=D.varResults.length>0?D.varResults.map(e=>({id:e.id,name:e.name})):[];i.push({name:r,ids:a,items:o,ts:new Date().toISOString()}),w(e,i),n.value=``,t()}),l.querySelectorAll(`.ss-vpreset-config`).forEach(e=>{e.addEventListener(`click`,n=>{n.stopPropagation();let r=parseInt(e.dataset.pi);D.varPresetConfigPanelId=D.varPresetConfigPanelId===r?null:r,D.varPresetEditing=null,t()})}),D.varPresetConfigPanelId!==null){let n=D.varPresetConfigPanelId,r=C(e)[n],i=k.getElementById(`ss-preset-cfg-list-${n}`);i&&r&&(!r.items||r.items.length!==r.ids.length?(r.items=r.ids.map(e=>({id:e,name:`...`})),Bt(r.ids).then(i=>{r.items=r.ids.map(e=>{let t=i.find(t=>t.id===e);return t?{id:t.id,name:t.name}:{id:e,name:`Unknown`}});let a=C(e);a[n]=r,w(e,a),D.varPresetConfigPanelId===n&&t()})):r.items.length===0?i.innerHTML=`<div class="ss-empty" style="border:none;padding:4px;">No variables</div>`:(i.innerHTML=r.items.map(e=>`
                   <div style="display:flex;align-items:center;justify-content:space-between;padding:3px 2px;border-bottom:1px solid rgba(0,0,0,0.05);">
                     <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;margin-right:6px;" title="${e.id}"><b>${e.id}</b> · ${j(e.name)}</span>
                     <button class="ss-var-btn" data-cfg-rm="${e.id}" title="Remove" style="background:none;">${R.replace(`width="24" height="24"`,`width="18" height="18"`)}</button>
                   </div>
                 `).join(``),i.querySelectorAll(`[data-cfg-rm]`).forEach(i=>{i.addEventListener(`click`,()=>{let a=parseInt(i.dataset.cfgRm);r.ids=r.ids.filter(e=>e!==a),r.items=r.items.filter(e=>e.id!==a);let o=C(e);o[n]=r,w(e,o),t()})})))}l.querySelectorAll(`.ss-vpreset-edit`).forEach(e=>{e.addEventListener(`click`,n=>{n.stopPropagation(),D.varPresetEditing=parseInt(e.dataset.pi),D.varPresetConfigPanelId=null,t()})}),l.querySelectorAll(`.ss-vpreset-name-save`).forEach(n=>{n.addEventListener(`click`,r=>{r.stopPropagation();let i=parseInt(n.dataset.pi),a=l.querySelector(`.ss-vpreset-name-input[data-pi="${i}"]`),o=C(e);o[i].name=a.value.trim()||o[i].name,w(e,o),D.varPresetEditing=null,t()})}),l.querySelectorAll(`[data-load-pi]`).forEach(t=>{t.addEventListener(`click`,async n=>{n.stopPropagation();let r=parseInt(t.dataset.loadPi),o=C(e)[r];if(o){D.varPresetsOpen=!1,l.classList.remove(`open`),k.getElementById(`ss-var-preset-btn`)?.classList.remove(`active`),D.varPresetConfigPanelId=null,i.disabled=!0,i.textContent=`...`,s.style.display=`flex`,a.innerHTML=``,D.varResults=[],D.varEditingId=null,D.varShowHistoryId=null,D.varViewingPresetId=r;try{let e=await Bt(o.ids);D.varResults=o.ids.map(t=>e.find(e=>e.id===t)).filter(Boolean),K(a,p)}catch(e){p(e.message)}finally{i.disabled=!1,i.innerHTML=nt.replace(`width="24" height="24"`,`width="16" height="16"`),s.style.display=`none`}}})}),l.querySelectorAll(`.ss-vpreset-delete`).forEach(n=>{n.addEventListener(`click`,r=>{r.stopPropagation();let i=C(e);i.splice(parseInt(n.dataset.pi),1),w(e,i),D.varPresetEditing=null,t()})})}t()}function g(){if(D.varShowFavorites=!D.varShowFavorites,!D.varShowFavorites){u.classList.remove(`open`),k.getElementById(`ss-var-fav-tab-btn`).classList.remove(`active`);return}D.varPresetsOpen=!1,l.classList.remove(`open`),k.getElementById(`ss-var-preset-btn`).classList.remove(`active`),D.varShowSearchHist=!1,c.classList.remove(`open`),k.getElementById(`ss-var-hist-btn`).classList.remove(`active`),k.getElementById(`ss-var-fav-tab-btn`).classList.add(`active`);let e=Me(),t=(n=``)=>{let i=e.filter(e=>e.name.toLowerCase().includes(n.toLowerCase())||e.id.toString().includes(n)),o=i.length?i.map((t,n)=>`<div class="ss-hist-term" data-index="${e.indexOf(t)}">${j(t.name)} <span style="font-size:11px;color:var(--text4);margin-left:auto;">${t.id}</span></div>`).join(``):`<div class="ss-hist-term" style="opacity:0.5;cursor:default;">${n?`No matches`:`No favorites yet`}</div>`;u.innerHTML=`
          <div class="ss-info-header">
            <div class="ss-info-title">Favorites</div>
            <button class="ss-close ss-close-extra-panel">${R}</button>
          </div>
          <div class="ss-panel-search-wrapper">
            <input type="text" class="ss-panel-search-input" id="ss-var-fav-filter" placeholder="Filter variables..." value="${j(n)}">
          </div>
          <div class="ss-panel-list-content">
            ${o}
          </div>
        `;let c=u.querySelector(`#ss-var-fav-filter`);c.focus(),c.oninput=e=>t(e.target.value),u.querySelectorAll(`.ss-hist-term[data-index]`).forEach(t=>{t.addEventListener(`click`,async()=>{let n=e[parseInt(t.dataset.index)];g(),r.value=``,s.style.display=`flex`,a.innerHTML=``,D.varResults=[],D.varEditingId=null,D.varShowHistoryId=null,D.varViewingPresetId=null;try{let e=await Bt([n.id]);e.length?(D.varResults=e,K(a,p)):a.innerHTML=`<div class="ss-empty">Variable not found</div>`}catch(e){p(e.message)}finally{s.style.display=`none`}})})};t(),$(`ss-var-fav-panel`)}async function _(){let e=r.value.trim();if(!e||!D.projectId)return;O(`Search Variables`,`Query: "${e}"`);let t=e.split(`,`).map(e=>e.trim()).filter(Boolean);i.disabled=!0,i.innerHTML=`...`,s.style.display=`flex`,a.innerHTML=``,D.varResults=[],D.varEditingId=null,D.varShowHistoryId=null,D.varViewingPresetId=null,c.classList.remove(`open`),D.varShowSearchHist=!1,t.forEach(e=>ge(D.projectId,e));try{let e=new Set,n=[];for(let r of t)(await zt(r)).forEach(t=>{e.has(t.id)||(e.add(t.id),n.push(t))});D.varResults=n,K(a,p)}catch(e){p(e.message)}finally{i.disabled=!1,i.innerHTML=nt.replace(`width="24" height="24"`,`width="16" height="16"`),s.style.display=`none`}}i.onclick=_,r&&(r.onkeydown=e=>{e.key===`Enter`&&_()},r.addEventListener(`input`,A(e=>{let t=e.target.value.trim();t.length>=2?D.globalSettings.autoFetch&&_():t||(D.varResults=[],K(a,p))},400))),k.getElementById(`ss-var-hist-btn`).onclick=e=>{e.stopPropagation(),m()},k.getElementById(`ss-var-preset-btn`).onclick=e=>{e.stopPropagation(),h()},k.getElementById(`ss-var-fav-tab-btn`).onclick=e=>{e.stopPropagation(),g()},k.getElementById(`ss-var-reset-btn`).onclick=()=>{D.varResults=[],D.varEditingId=null,D.varShowHistoryId=null,D.varPresetPanelId=null,D.varViewingPresetId=null,D.varShowSearchHist=!1,D.varPresetsOpen=!1,D.varShowFavorites=!1,Wt()},document.addEventListener(`click`,e=>{},{capture:!1}),D.varResults.length&&K(a,p)}function K(e,t){if(e.innerHTML=``,!D.varResults.length){e.innerHTML=`<div class="ss-empty">No variables found</div>`;return}if(D.varViewingPresetId!==null){let t=C(D.projectId)[D.varViewingPresetId];t&&(e.innerHTML+=`<div style="padding:6px 10px;font-size:13px;color:var(--text4);background:var(--bg3);border-radius:4px;margin-bottom:6px;">Viewing Preset: <b>${j(t.name)}</b></div>`)}D.varResults.forEach(n=>{let r=D.varEditingId===n.id,i=D.varShowHistoryId===n.id,a=D.varPresetPanelId===n.id,o=n._status||``,s=pe(D.projectId,n.id),c=D.projectId,l=document.createElement(`div`);l.className=`ss-var-card${r?` editing`:``}`,l.dataset.id=n.id;function u(){let e=C(c),t=e.map((e,t)=>({...e,i:t,has:e.ids.includes(n.id)}));return`
          <div class="ss-card-preset-panel">
            <div class="ss-var-panel-label" style="padding:8px 10px 4px;">Preset Name / Search</div>
            <div style="padding:0 10px 6px; display:flex; gap:4px;">
              <input class="ss-input ss-preset-combined-input" placeholder="Name to create or search..." style="flex:1;padding:5px 8px;font-size:13px;" />
              <button class="ss-var-btn ss-preset-combined-save" title="Save / Create">${at}</button>
            </div>
            <div class="ss-preset-list-inner">
              ${e.length===0?`<div class="ss-empty" style="border:none;padding:6px 10px;font-size:13px;">No presets yet</div>`:t.map(e=>`
                  <div class="ss-preset-toggle-row" data-pi="${e.i}" style="display:${e.has?`flex`:`none`};">
                    <span class="ss-preset-toggle-name">${j(e.name)}</span>
                    <span class="ss-preset-toggle-count">${e.ids.length}</span>
                    <button class="ss-var-btn ss-preset-toggle-btn${e.has?` active`:``}" data-pi="${e.i}" data-has="${e.has}" title="${e.has?`Remove from preset`:`Add to preset`}">
                      ${e.has?F:ft}
                    </button>
                  </div>`).join(``)}
            </div>
          </div>
        `}l.innerHTML=`
        <div class="ss-var-card-main">
          <div class="ss-var-info">
            <div class="ss-var-name" style="display:flex;align-items:center;gap:4px;">
              <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${j(n.name)}</span>
            </div>
            <div style="display:flex;align-items:center;gap:4px;margin-top:2px;">
              <button class="ss-var-btn ss-var-btn-copy" data-action="copy" data-id="${n.id}" title="Copy Value">${P}</button>
              <div class="ss-var-value-preview">${j(n.value||`—`)}</div>
            </div>
          </div>
          <div class="ss-var-actions">
            ${r?`
              <button class="ss-var-btn ss-var-btn-history${i?` active`:``}" data-action="history" data-id="${n.id}" title="Edit history">${tt}</button>
              <button class="ss-var-btn ss-var-btn-copy" data-action="copy-edit" data-id="${n.id}" title="Copy">${P}</button>
              <button class="ss-var-btn ss-var-btn-reset" data-action="reset" data-id="${n.id}" title="Reset">${I.replace(`width="24" height="24"`,`width="12" height="12"`)}</button>
              <button class="ss-var-btn ss-var-btn-done" data-action="save" data-id="${n.id}" title="Save">${F}</button>
            `:`
              <button class="ss-var-btn ss-fav-var-btn" data-action="fav" data-id="${n.id}" title="${D.varFavorites.some(e=>e.id==n.id)?`Remove from favorites`:`Add to favorites`}" style="color:${D.varFavorites.some(e=>e.id==n.id)?`var(--accent)`:`var(--border2)`};">
                 ${D.varFavorites.some(e=>e.id==n.id)?it:rt}
              </button>
              <button class="ss-var-btn ss-var-btn-addpreset${a?` active`:``}" data-action="addpreset" data-id="${n.id}" title="Add to preset">${ft}</button>
              ${D.varViewingPresetId===null?``:`<button class="ss-var-btn" data-action="rm-from-preset" data-id="${n.id}" title="Remove from this preset">${ot}</button>`}
              <button class="ss-var-btn ss-var-btn-edit" data-action="edit" data-id="${n.id}" title="Edit">${et}</button>
            `}
            ${o===`success`?`<span class="ss-var-status success">✓</span>`:o===`error`?`<span class="ss-var-status error">✗</span>`:o===`verifying`?`<span class="ss-var-status verifying">⟳</span>`:`<span class="ss-var-status empty"></span>`}
          </div>
        </div>
        ${r?`<div class="ss-var-edit-panel"><textarea class="ss-var-textarea" id="ss-var-edit-${n.id}">${j(n.value||``)}</textarea></div>`:``}
        ${i&&r?`
          <div class="ss-var-history-panel">
            <div class="ss-var-panel-label">History (up to 5)</div>
            ${s.length===0?`<div class="ss-empty" style="border:none;padding:6px 0;">No history yet</div>`:s.map((e,t)=>`<div class="ss-history-item" data-hi="${t}" data-id="${n.id}"><div class="ss-history-value">${j(e.value)}</div><div class="ss-history-ts">${e.ts.split(`T`)[0]}</div></div>`).join(``)}
          </div>`:``}
        ${a&&!r?u():``}
      `,l.querySelectorAll(`.ss-history-item`).forEach(e=>{e.addEventListener(`click`,()=>{let t=pe(D.projectId,n.id)[parseInt(e.dataset.hi)];if(!t)return;let r=k.getElementById(`ss-var-edit-${n.id}`);r&&(r.value=t.value)})});function d(){let r=l.querySelector(`.ss-card-preset-panel`);r&&(r.querySelector(`.ss-preset-combined-input`)?.addEventListener(`input`,e=>{let t=e.target.value.toLowerCase();r.querySelectorAll(`.ss-preset-toggle-row`).forEach(e=>{let n=e.querySelector(`.ss-preset-toggle-name`)?.textContent.toLowerCase()||``,r=e.querySelector(`.ss-preset-toggle-btn`)?.dataset.has===`true`;t?e.style.display=n.includes(t)?`flex`:`none`:e.style.display=r?`flex`:`none`})}),r.querySelectorAll(`.ss-preset-toggle-btn`).forEach(r=>{r.addEventListener(`click`,i=>{i.stopPropagation();let a=parseInt(r.dataset.pi),o=r.dataset.has===`true`,s=C(c);s[a]&&(o?(s[a].ids=s[a].ids.filter(e=>e!==n.id),s[a].items&&(s[a].items=s[a].items.filter(e=>e.id!==n.id))):s[a].ids.includes(n.id)||(s[a].ids.push(n.id),s[a].items||(s[a].items=[]),s[a].items.push({id:n.id,name:n.name})),w(c,s),D.varPresetPanelId=n.id,K(e,t))})}),r.querySelector(`.ss-preset-combined-save`)?.addEventListener(`click`,i=>{i.stopPropagation();let a=r.querySelector(`.ss-preset-combined-input`)?.value.trim();if(!a)return;let o=C(c),s=o.findIndex(e=>e.name.toLowerCase()===a.toLowerCase());s>-1?o[s].ids.includes(n.id)||(o[s].ids.push(n.id),o[s].items||(o[s].items=[]),o[s].items.push({id:n.id,name:n.name})):o.push({name:a,ids:[n.id],items:[{id:n.id,name:n.name}],ts:new Date().toISOString()}),w(c,o),D.varPresetPanelId=n.id,K(e,t)}))}e.appendChild(l),d()}),e.querySelectorAll(`[data-action]`).forEach(n=>{n.addEventListener(`click`,async r=>{r.stopPropagation();let i=n.dataset.action,a=parseInt(n.dataset.id),o=D.varResults.find(e=>e.id===a);if(o){if(i===`fav`){let n=D.varFavorites.findIndex(e=>e.id==a);if(n>-1)D.varFavorites.splice(n,1);else{if(D.varFavorites.length>=100){M(`Limit of 100 favorites reached`);return}D.varFavorites.unshift({id:o.id,name:o.name})}Ne(D.varFavorites),K(e,t);let r=k.getElementById(`ss-var-fav-tab-btn`);r&&(r.style.display=D.varFavorites.length>0?``:`none`),D.varShowFavorites&&(k.getElementById(`ss-var-fav-tab-btn`)?.click(),k.getElementById(`ss-var-fav-tab-btn`)?.click());return}if(i===`copy-name`){N(o.name,`Copy Variable Name`,`Copied variable name: ${o.name}`);let e=n.innerHTML;n.innerHTML=F,setTimeout(()=>n.innerHTML=e,1500)}if(i===`copy`&&(N(o.value||``,`Copy Variable Value`,`Copied value for: ${o.name}`),n.style.color=`var(--success)`,setTimeout(()=>n.style.color=``,1500)),i===`copy-edit`&&(N(k.getElementById(`ss-var-edit-${a}`)?.value||o.value||``,`Copy Variable Editor Value`,`Copied edited value for: ${o.name}`),n.style.color=`var(--success)`,setTimeout(()=>n.style.color=``,1500)),i===`addpreset`&&(D.varPresetPanelId=D.varPresetPanelId===a?null:a,D.varEditingId=null,K(e,t)),i===`rm-from-preset`){let n=D.varViewingPresetId,r=C(D.projectId);r[n]&&(r[n].ids=r[n].ids.filter(e=>e!==a),w(D.projectId,r),D.varResults=D.varResults.filter(e=>e.id!==a),K(e,t))}if(i===`edit`&&(D.varEditingId=a,D.varShowHistoryId=null,D.varPresetPanelId=null,K(e,t),setTimeout(()=>{let e=k.getElementById(`ss-var-edit-${a}`);e&&(e.focus(),e.setSelectionRange(e.value.length,e.value.length))},30)),i===`reset`&&(D.varEditingId=null,D.varShowHistoryId=null,K(e,t)),i===`history`&&(D.varShowHistoryId=D.varShowHistoryId===a?null:a,K(e,t)),i===`save`){let n=k.getElementById(`ss-var-edit-${a}`);if(!n)return;let r=n.value,i=o.value;o._status=`verifying`,D.varEditingId=null,D.varShowHistoryId=null,K(e,t);try{await Vt(a,o.name,r);let e=await Ht(a,r);o._status=e?`success`:`error`,e&&(me(D.projectId,a,i),o.value=r)}catch(e){o._status=`error`,t(e.message)}K(e,t),setTimeout(()=>{o._status=``,K(e,t)},2500)}}})})}function Gt(){k.querySelectorAll(`.ss-extra-panel`).forEach(e=>e.classList.remove(`open`)),k.querySelectorAll(`.ss-action-btn, .ss-var-btn`).forEach(e=>e.classList.remove(`active`)),D.contactShowSearchHist=!1,D.contactShowFavorites=!1,D.contactSettingsOpen=!1,D.varShowSearchHist=!1,D.varPresetsOpen=!1}function q(){let e=k.getElementById(`ss-body`),t=D.projectId,n=t?_e(t).length>0:!1,r=D.tagFavorites.length>0;e.innerHTML=`
      <div style="margin-bottom:14px;">
        <div style="display:flex;gap:12px;align-items:center;margin-bottom:8px;">
          <span class="ss-text-link ${D.tagShowSearchHist?`active`:``}" id="ss-tag-hist-btn" style="${n?``:`display:none;`}">HISTORY</span>
          <span class="ss-text-link ${D.tagShowFavorites?`active`:``}" id="ss-tag-fav-btn" style="${r?``:`display:none;`}">FAVORITES</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:8px;">
          <input class="ss-input" id="ss-tag-input" type="text" placeholder="tag name" autocomplete="off" style="width:100%;box-sizing:border-box;" />
          <div style="display:flex;gap:8px;align-items:center;">
            <button class="ss-btn-search" id="ss-btn-search" title="Search" style="flex:1;justify-content:center;background:var(--accent);color:var(--accent-text);">Search</button>
            <button class="ss-btn-search" id="ss-btn-tag-reset" title="Reset Search" style="width:auto;padding:8px 12px;justify-content:center;background:var(--bg3);color:var(--text2);">${I.replace(`width="24" height="24"`,`width="16" height="16"`)}</button>
          </div>
        </div>
      </div>
      <div id="ss-tag-list" style="display:flex;flex-direction:column;gap:8px;"></div>
      <div class="ss-error" id="ss-tag-error"></div>
      <div class="ss-loading" id="ss-tag-loading" style="display:none;"><div class="ss-spinner"></div><span class="ss-loading-text">Searching...</span></div>
    `,J(),Jt()}function J(){let e=k.getElementById(`ss-tag-list`);if(!e)return;e.innerHTML=``;let t=D.tagResults||[];if(!t.length){D.tagSearchPerformed&&(e.innerHTML=`<div class="ss-empty">No tags found</div>`);return}t.forEach(t=>{let n=D.tagFavorites.some(e=>e.id==t.id),r=document.createElement(`div`);r.className=`ss-var-card`,r.innerHTML=`
        <div class="ss-var-card-main">
          <div class="ss-var-info">
            <div class="ss-var-name" style="display:flex;align-items:center;">
              ${j(t.name)}
            </div>
            <div class="ss-var-value-preview" style="font-size:11px;color:var(--text5);">ID: <span style="color:var(--accent);font-weight:600;">${t.id}</span></div>
          </div>
          <div class="ss-var-actions">
            <button class="ss-var-btn ss-fav-tag-btn" data-id="${t.id}" title="${n?`Remove from favorites`:`Add to favorites`}" style="color:${n?`var(--accent)`:`var(--border2)`};">
               ${n?it:rt}
            </button>
            <button class="ss-var-btn ss-tag-copy-id-btn" data-id="${t.id}" title="Copy ID">${P}</button>
          </div>
        </div>
      `;let i=r.querySelector(`.ss-fav-tag-btn`);i.onclick=e=>{e.stopPropagation();let n=D.tagFavorites.findIndex(e=>e.id==t.id);n>-1?D.tagFavorites.splice(n,1):D.tagFavorites.unshift({id:t.id,name:t.name}),Ae(D.tagFavorites),J(),q()};let a=r.querySelector(`.ss-tag-copy-id-btn`);a.onclick=e=>{e.stopPropagation(),N(t.id,`Copy Tag ID`,`Copied ID: ${t.id} for tag: ${t.name}`);let n=a.innerHTML;a.innerHTML=F,a.style.color=`var(--success)`,setTimeout(()=>{a.innerHTML=n,a.style.color=``},1500)},e.appendChild(r)})}function Kt(){let e=k.getElementById(`ss-tag-search-hist`);if(!e)return;let t=_e(D.projectId),n=k.getElementById(`ss-tag-input`),r=(i=``)=>{let a=t.filter(e=>e.toLowerCase().includes(i.toLowerCase())),o=a.length?a.map(e=>`<div class="ss-hist-term" data-term="${j(e)}">${j(e)}</div>`).join(``):`<div class="ss-hist-term" style="opacity:0.5;cursor:default;">${i?`No matches`:`No history`}</div>`;e.innerHTML=`
        <div class="ss-info-header">
          <div class="ss-info-title">Search History</div>
          <button class="ss-close ss-close-extra-panel">${R}</button>
        </div>
        <div class="ss-panel-search-wrapper">
          <input type="text" class="ss-panel-search-input" id="ss-tag-hist-filter" placeholder="Quick search..." value="${j(i)}">
        </div>
        <div class="ss-panel-list-content">
          ${o}
        </div>
      `;let s=e.querySelector(`#ss-tag-hist-close`);s&&(s.onclick=()=>{D.tagShowSearchHist=!1,e.classList.remove(`open`),k.getElementById(`ss-tag-hist-btn`)?.classList.remove(`active`)});let c=e.querySelector(`#ss-tag-hist-filter`);c&&(c.oninput=e=>r(e.target.value),i&&(c.focus(),c.setSelectionRange(i.length,i.length))),e.querySelectorAll(`.ss-hist-term[data-term]`).forEach(t=>{t.onclick=()=>{if(n){n.value=t.dataset.term;let e=k.getElementById(`ss-btn-search`);e&&e.click()}D.tagShowSearchHist=!1,e.classList.remove(`open`),k.getElementById(`ss-tag-hist-btn`)?.classList.remove(`active`)}})};r()}function qt(){let e=k.getElementById(`ss-tag-fav-panel`);if(!e)return;e.innerHTML=`
      <div class="ss-info-header">
        <div class="ss-info-title">Favorite Tags</div>
        <button class="ss-close ss-close-extra-panel">${R}</button>
      </div>
      <div class="ss-panel-list-content">
        ${D.tagFavorites.length?D.tagFavorites.map(e=>`
          <div class="ss-hist-term" style="display:flex;justify-content:space-between;align-items:center;gap:12px;padding:8px 14px;border-bottom:1px solid var(--border);">
            <div style="min-width:0;flex:1;">
              <div style="font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text);">${j(e.name)}</div>
              <div style="font-size:11px;color:var(--text5);">ID: <span style="color:var(--accent);font-weight:600;">${e.id}</span></div>
            </div>
            <div style="display:flex;gap:4px;">
               <button class="ss-var-btn ss-fav-tag-copy" data-id="${e.id}" title="Copy ID">${P}</button>
               <button class="ss-var-btn ss-fav-tag-rm" data-id="${e.id}" title="Remove" style="color:var(--text5);">${R}</button>
            </div>
          </div>
        `).join(``):`<div class="ss-empty">No favorites yet</div>`}
      </div>
    `;let t=e.querySelector(`#ss-tag-fav-close`);t&&(t.onclick=()=>$(`ss-tag-fav-panel`)),e.querySelectorAll(`.ss-fav-tag-copy`).forEach(e=>{e.onclick=()=>{N(e.dataset.id,`Copy Tag ID`,`Copied ID: ${e.dataset.id}`);let t=e.innerHTML;e.innerHTML=F,e.style.color=`var(--success)`,setTimeout(()=>{e.innerHTML=t,e.style.color=``},1500)}}),e.querySelectorAll(`.ss-fav-tag-rm`).forEach(e=>{e.onclick=()=>{D.tagFavorites=D.tagFavorites.filter(t=>t.id!=e.dataset.id),Ae(D.tagFavorites),qt(),J(),q()}})}function Jt(){let e=k.getElementById(`ss-btn-search`),t=k.getElementById(`ss-tag-input`),n=k.getElementById(`ss-btn-tag-reset`),r=k.getElementById(`ss-tag-hist-btn`),i=k.getElementById(`ss-tag-fav-btn`);async function a(){let n=t?.value.trim();if(!n)return;if(!D.projectId){M(`Project not selected`);return}if(D.isSearching)return;O(`Search Tags`,`Query: "${n}"`),D.isSearching=!0,e&&(e.disabled=!0,e.innerHTML=`...`);let r=k.getElementById(`ss-tag-loading`);r&&(r.style.display=`block`),D.tagSearchPerformed=!0;try{D.tagResults=(await Rt(D.projectId,n)).collection||[],ve(D.projectId,n),J()}catch(e){M(e.message)}finally{D.isSearching=!1,r&&(r.style.display=`none`),e&&(e.disabled=!1,e.innerHTML=nt.replace(`width="24" height="24"`,`width="16" height="16"`)),q()}}e?.addEventListener(`click`,a),t?.addEventListener(`keydown`,e=>{e.key===`Enter`&&a()}),t?.addEventListener(`input`,A(e=>{let t=e.target.value.trim();t.length>=2?D.globalSettings.autoFetch&&a():t||(D.tagResults=[],D.tagSearchPerformed=!1,J())},400)),n?.addEventListener(`click`,()=>{t&&(t.value=``),D.tagResults=[],D.tagSearchPerformed=!1,J(),q()}),r?.addEventListener(`click`,()=>{D.tagShowSearchHist=!D.tagShowSearchHist,D.tagShowSearchHist?(D.tagShowFavorites=!1,k.getElementById(`ss-tag-fav-btn`)?.classList.remove(`active`),r.classList.add(`active`),Kt(),$(`ss-tag-search-hist`)):(r.classList.remove(`active`),$(`ss-tag-search-hist`))}),i?.addEventListener(`click`,()=>{D.tagShowFavorites=!D.tagShowFavorites,D.tagShowFavorites?(D.tagShowSearchHist=!1,k.getElementById(`ss-tag-hist-btn`)?.classList.remove(`active`),i.classList.add(`active`),qt(),$(`ss-tag-fav-panel`)):(i.classList.remove(`active`),$(`ss-tag-fav-panel`))})}function Yt({contactId:e,contactName:t=``,onSuccess:n=null,customRoot:r=null}){let i=null;if(r&&(i=r.id===`ss-sidebar`?r:r.closest?.(`#ss-sidebar`)||r.querySelector?.(`#ss-sidebar`)),!i&&k&&(i=k.getElementById(`ss-sidebar`)),i||=document.getElementById(`ss-sidebar`),i||=r||k||document.body,!i)return;let a=(i.getRootNode?.()||document).querySelector?.(`#ss-fire-event-overlay`)||i.querySelector?.(`#ss-fire-event-overlay`);a&&a.remove();let o=D.projectId,s=xe(o),c=[...new Set(s.map(e=>e.name).filter(Boolean))].slice(0,5),l=document.createElement(`div`);l.id=`ss-fire-event-overlay`,l.className=`ss-modal-overlay`,l.innerHTML=`
    <div class="ss-modal-box">
      <div class="ss-modal-header" style="background:var(--bg-solid,#282828);padding:14px 16px;border-bottom:1px solid var(--border,rgba(255,255,255,0.1));display:flex;align-items:center;justify-content:space-between;">
        <div class="ss-modal-title" style="font-size:15px;font-weight:700;color:var(--text,#ffffff);display:flex;align-items:center;gap:8px;">
          <span style="color:var(--accent,#0a84ff);display:inline-flex;">${z}</span>
          <span>Fire Event</span>
        </div>
        <button class="ss-close" id="ss-modal-close" title="Close" style="background:none;border:none;color:var(--text4,rgba(255,255,255,0.6));cursor:pointer;display:flex;align-items:center;justify-content:center;padding:4px;border-radius:6px;">${R}</button>
      </div>
      <div class="ss-modal-body" style="background:var(--bg-solid,#282828);padding:16px;display:flex;flex-direction:column;gap:12px;">
        <div style="background:var(--bg2,rgba(255,255,255,0.06));padding:10px 12px;border-radius:8px;border:1px solid var(--border,rgba(255,255,255,0.1));display:flex;flex-direction:column;gap:4px;">
          <div style="font-size:11px;color:var(--text4,rgba(255,255,255,0.6));text-transform:uppercase;font-weight:700;letter-spacing:0.04em;">Target Contact</div>
          <div style="font-size:14px;font-weight:700;color:var(--text,#ffffff);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
            ${j(t||`Unnamed Contact`)}
          </div>
          <div style="font-size:12px;color:var(--text4,rgba(255,255,255,0.6));">
            ID: <span style="color:var(--accent,#0a84ff);font-weight:600;">${j(e)}</span>
          </div>
        </div>

        <div>
          <label style="display:block;font-size:12px;font-weight:600;color:var(--text3,#ebebf5);margin-bottom:6px;">
            Event Name (name) <span style="color:var(--error,#ff453a);">*</span>
          </label>
          <input type="text" id="ss-modal-event-name" class="ss-input" placeholder="e.g. order_success, webhook_event" autocomplete="off" style="width:100%;box-sizing:border-box;background:var(--bg2,#333333);color:var(--text,#ffffff);border:1px solid var(--border,rgba(255,255,255,0.15));border-radius:8px;padding:8px 12px;font-size:14px;" />
        </div>

        ${c.length>0?`
          <div>
            <div style="font-size:11px;color:var(--text4,rgba(255,255,255,0.6));margin-bottom:6px;">Recent Events:</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px;">
              ${c.map(e=>`
                <button type="button" class="ss-event-chip" data-name="${j(e)}" style="background:var(--bg3,rgba(255,255,255,0.08));border:1px solid var(--border,rgba(255,255,255,0.12));border-radius:12px;padding:3px 10px;font-size:11px;color:var(--text2,#f2f2f7);cursor:pointer;transition:all 0.15s ease;">
                  ${j(e)}
                </button>
              `).join(``)}
            </div>
          </div>
        `:``}

        <div id="ss-modal-event-status" style="display:none;font-size:12px;padding:8px;border-radius:6px;line-height:1.4;"></div>
      </div>
      <div class="ss-modal-footer" style="background:var(--bg-solid,#282828);padding:12px 16px;border-top:1px solid var(--border,rgba(255,255,255,0.1));display:flex;gap:8px;justify-content:flex-end;">
        <button class="ss-btn-search" id="ss-modal-cancel" style="background:var(--bg3,rgba(255,255,255,0.08));color:var(--text2,#f2f2f7);padding:6px 14px;justify-content:center;border-radius:8px;cursor:pointer;">Cancel</button>
        <button class="ss-btn-search" id="ss-modal-fire" style="background:var(--accent,#0a84ff);color:var(--accent-text,#ffffff);padding:6px 16px;justify-content:center;border-radius:8px;display:flex;align-items:center;gap:6px;cursor:pointer;font-weight:600;">
          ${z}
          <span>Fire Event</span>
        </button>
      </div>
    </div>
  `,i.appendChild(l);let u=l.querySelector(`#ss-modal-event-name`),d=l.querySelector(`#ss-modal-fire`),f=l.querySelector(`#ss-modal-cancel`),p=l.querySelector(`#ss-modal-close`),m=l.querySelector(`#ss-modal-event-status`);setTimeout(()=>u?.focus(),60);let h=()=>{l.remove()};l.addEventListener(`click`,e=>{e.target===l&&h()}),p?.addEventListener(`click`,h),f?.addEventListener(`click`,h),l.querySelectorAll(`.ss-event-chip`).forEach(e=>{e.addEventListener(`click`,()=>{u&&(u.value=e.dataset.name,u.focus())})});let g=async()=>{let r=u?.value?.trim();if(!r){m&&(m.style.display=`block`,m.style.background=`rgba(var(--error-rgb, 255, 69, 58), 0.15)`,m.style.color=`var(--error, #ff453a)`,m.textContent=`Please enter an event name.`),u?.focus();return}d.disabled=!0,d.innerHTML=`<span class="ss-spinner" style="width:12px;height:12px;border-width:1.5px;"></span> Firing...`,m&&(m.style.display=`none`);try{await Qt(e,r),O(`Fire Event`,`Fired "${r}" for contact ${e} (${t})`),Se(D.projectId,{contactId:e,contactName:t||``,name:r,success:!0}),M(`Event "${r}" fired successfully!`,`success`),n&&n(r),h()}catch(e){d.disabled=!1,d.innerHTML=`${z} <span>Fire Event</span>`,m&&(m.style.display=`block`,m.style.background=`rgba(var(--error-rgb, 255, 69, 58), 0.15)`,m.style.color=`var(--error, #ff453a)`,m.textContent=`Error: ${e.message}`)}};d?.addEventListener(`click`,g),u?.addEventListener(`keydown`,e=>{e.key===`Enter`&&g(),e.key===`Escape`&&h()})}async function Xt(e){let t=W();if(!t)throw Error(`No API token. Open Settings ⚙`);e.includes(`@`);let n=/^\d+$/.test(e),r=[];if(n)try{let n=await G(`https://api.smartsender.com/v1/contacts/${e}`,`GET`,t);n&&n.id&&r.push(n)}catch(e){console.warn(`[Contacts] ID lookup failed:`,e.message)}if(r.length===0){let n=new URLSearchParams({page:1,limitation:10,term:e.trim()});try{let e=await G(`https://api.smartsender.com/v1/contacts/search?${n}`,`GET`,t);r=e?.collection||(Array.isArray(e)?e:[])}catch(e){throw console.error(`[Contacts] Search failed:`,e.message),e}}return r}async function Y(e){let t=W();if(!t)throw Error(`No API token.`);return G(`https://api.smartsender.com/v1/contacts/${e}/info`,`GET`,t)}async function Zt(e,t,n){let r=W();if(!r)throw Error(`No API token.`);return G(`https://api.smartsender.com/v1/contacts/${e}`,`PUT`,r,{values:{[t]:n}})}async function Qt(e,t){let n=W();if(!n)throw Error(`No API token. Open Settings ⚙`);if(!e)throw Error(`Contact ID is required`);if(!t||!t.trim())throw Error(`Event name is required`);return G(`https://api.smartsender.com/v1/contacts/${encodeURIComponent(e)}/fire`,`POST`,n,{name:t.trim()})}function $t(e){let t=k.getElementById(`ss-info-panel`);t&&(Gt(),D.contactInfoOpen=!0,D.contactInfoId=e,t.classList.add(`open`),t.innerHTML=`
      <div class="ss-info-header">
        <div class="ss-info-title">Contact Info</div>
        <button class="ss-close ss-close-extra-panel">${R}</button>
      </div>
      <div id="ss-info-search-sticky" style="padding:10px 16px;background:var(--bg-solid);border-bottom:1px solid var(--border);display:none;">
        <input class="ss-input" id="ss-info-var-search" type="text" placeholder="Filter variables..." style="font-size:13px;padding:6px 10px;height:28px;" />
      </div>
      <div class="ss-info-body" id="ss-info-body">
        <div class="ss-loading" style="display:flex;"><div class="ss-spinner"></div><span class="ss-loading-text">Loading details...</span></div>
      </div>
    `,Y(e).then(t=>{if(D.contactInfoId!==e)return;D.contactInfo=t;let n=k.getElementById(`ss-info-body`);if(!n)return;let r=[`id`,`name`,`firstName`,`lastName`,`fullName`,`email`,`phone`,`photo`,`createdAt`,`notes`,`tags`,`values`,`thumb`,`updatedAt`,`system_city`,`system_country`,`system_continent`,`system_timezone`,`system_os`,`system_browser`,`is_active`,`userId`,`projectId`],i=(t.values||[]).map(e=>({name:e.name,value:e.value}));Object.keys(t).forEach(e=>{!r.includes(e)&&t[e]!==null&&typeof t[e]!=`object`&&(i.find(t=>t.name===e)||i.push({name:e,value:t[e]}))});let a=e=>{let t=D.contactVarEditingKey===e.name;return`
          <div class="ss-info-var${t?` editing`:``}" title="${j(e.name)}: ${j(String(e.value))}">
            <div class="ss-info-var-name">
              <span>${j(e.name)}</span>
              <button class="ss-info-copy-btn" data-copy="${j(e.name)}" title="Copy key">${P}</button>
            </div>
            <div class="ss-info-var-val">
              ${t?`
                <input class="ss-input ss-cvar-input" value="${j(String(e.value))}" style="flex:1;height:22px;font-size:13px;padding:2px 6px;margin-right:4px;" />
                <button class="ss-var-btn ss-cvar-save" data-key="${j(e.name)}" title="Save">${F}</button>
                <button class="ss-var-btn ss-cvar-cancel" title="Cancel">${R}</button>
              `:`
                <span>${j(String(e.value))}</span>
                <button class="ss-info-copy-btn ss-cvar-edit" data-key="${j(e.name)}" title="Edit value">${et}</button>
                <button class="ss-info-copy-btn" data-copy="${j(String(e.value))}" title="Copy value">${P}</button>
              `}
            </div>
          </div>
        `},o=(e=``)=>{let n=e.split(`,`).map(e=>e.trim().toLowerCase()).filter(Boolean),r=D.projectId,o=E(r).split(`,`).map(e=>e.trim().toLowerCase()).filter(Boolean),s=(t.tags||[]).filter(e=>!n.length||n.some(t=>e.name.toLowerCase().includes(t))),c=i.filter(e=>!n.length||n.some(t=>e.name.toLowerCase().includes(t)||String(e.value).toLowerCase().includes(t))),l=c.filter(e=>o.includes(e.name.toLowerCase())),u=``;return D.contactSettings.showProfile&&(u+=`
            <div class="ss-info-section" style="display:flex;align-items:center;gap:12px;background:var(--bg2);padding:12px;border-radius:12px;margin-bottom:16px;">
              ${t.photo?`<img src="${t.photo}" style="width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid var(--border);">`:`<div style="width:48px;height:48px;border-radius:50%;background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:20px;">👤</div>`}
              <div style="flex:1;overflow:hidden;">
                <div style="font-weight:800;font-size:16px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;">
                  <span style="overflow:hidden;text-overflow:ellipsis;">${j(t.fullName||t.name||`Unnamed`)}</span>
                  ${V()?`<a href="https://messenger.smartsender.com/chats?project=${V()}&selectedContactId=${t.id}" target="_blank" title="Open chat" style="color:var(--text4);text-decoration:none;display:inline-flex;margin-left:8px;flex-shrink:0;">${L}</a>`:``}
                  <button class="ss-info-fire-btn" title="Fire Event" style="color:var(--accent);display:inline-flex;align-items:center;justify-content:center;padding:0;width:24px;height:24px;margin-left:6px;border-radius:6px;background:none;border:none;cursor:pointer;flex-shrink:0;">
                    ${z}
                  </button>
                </div>
                <div style="font-size:13px;color:var(--text4);font-family:Roboto,sans-serif;">ID: ${t.id}</div>
              </div>
            </div>
          `),D.contactSettings.showDetails&&(u+=`
            <div class="ss-info-section">
              <div class="ss-info-label">Basic Data</div>
              ${t.email?`<div class="ss-info-detail-row" title="Email: ${j(t.email)}"><span class="ss-info-detail-label">Email</span><div class="ss-info-detail-value"><span>${j(t.email)}</span><button class="ss-info-copy-btn" data-copy="${j(t.email)}" title="Copy email">${P}</button></div></div>`:``}
              ${t.phone?`<div class="ss-info-detail-row" title="Phone: ${j(t.phone)}"><span class="ss-info-detail-label">Phone</span><div class="ss-info-detail-value"><span>${j(t.phone)}</span><button class="ss-info-copy-btn" data-copy="${j(t.phone)}" title="Copy phone">${P}</button></div></div>`:``}
              <div class="ss-info-detail-row" title="Created: ${new Date(t.createdAt).toLocaleString()}"><span class="ss-info-detail-label">Created</span><div class="ss-info-detail-value"><span>${new Date(t.createdAt).toLocaleDateString()}</span><button class="ss-info-copy-btn" data-copy="${new Date(t.createdAt).toLocaleDateString()}" title="Copy date">${P}</button></div></div>
            </div>
          `),l.length>0&&(u+=`
            <div class="ss-priority-section">
              <div class="ss-priority-label">Priority Variables</div>
              ${l.map(e=>a(e)).join(``)}
            </div>
          `),D.contactSettings.showTags&&(u+=`
            <div class="ss-info-accordion" id="ss-tags-accordion">
              <div class="ss-info-accordion-header">
                <span>Tags (${s.length})</span>
                <span class="ss-info-accordion-icon">▾</span>
              </div>
              <div class="ss-info-accordion-content">
                <div class="ss-info-tags">
                  ${s.map(e=>`<span class="ss-info-tag">${j(e.name)}</span>`).join(``)||`<div class="ss-hint">No tags matched</div>`}
                </div>
              </div>
            </div>
          `),D.contactSettings.showVars&&(u+=`
            <div class="ss-info-accordion" id="ss-vars-accordion">
              <div class="ss-info-accordion-header">
                <span>Variables (${c.length})</span>
                <span class="ss-info-accordion-icon">▾</span>
              </div>
              <div class="ss-info-accordion-content">
                <div class="ss-info-vars">
                  ${c.map(e=>a(e)).join(``)||`<div class="ss-hint">No variables matched</div>`}
                </div>
              </div>
            </div>
          `),u};n.innerHTML=o();let s=k.getElementById(`ss-info-var-search`),c=k.getElementById(`ss-info-search-sticky`);c&&(c.style.display=D.contactSettings.showVars||D.contactSettings.showTags?`block`:`none`),s&&(s.value=``,s.oninput=e=>{n.innerHTML=o(e.target.value),l(),e.target.value.trim()&&n.querySelectorAll(`.ss-info-accordion`).forEach(e=>e.classList.add(`expanded`))});let l=()=>{n.querySelectorAll(`.ss-info-accordion-header`).forEach(e=>{e.onclick=()=>e.closest(`.ss-info-accordion`).classList.toggle(`expanded`)}),n.querySelectorAll(`[data-copy]`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),N(e.dataset.copy,`Copy Contact ID`,`Copied ID: ${e.dataset.copy}`);let n=e.innerHTML;e.innerHTML=F,setTimeout(()=>e.innerHTML=n,1500)}}),n.querySelectorAll(`.ss-info-fire-btn`).forEach(e=>{e.onclick=n=>{n.stopPropagation(),n.preventDefault(),Yt({contactId:t.id,contactName:t.fullName||t.name||``,customRoot:e.closest(`#ss-sidebar`)||k})}}),n.querySelectorAll(`.ss-info-detail-row`).forEach(e=>{e.onclick=t=>{t.target.closest(`button`)||e.classList.toggle(`expanded`)}}),n.querySelectorAll(`.ss-info-var`).forEach(t=>{t.onclick=e=>{e.target.closest(`input`)||e.target.closest(`button`)||t.classList.toggle(`expanded`)},t.querySelector(`.ss-cvar-edit`)?.addEventListener(`click`,e=>{e.stopPropagation(),D.contactVarEditingKey=e.currentTarget.dataset.key,n.innerHTML=o(s?.value||``),l(),n.querySelector(`#ss-vars-accordion`)?.classList.add(`expanded`),setTimeout(()=>n.querySelector(`.ss-cvar-input`)?.focus(),30)}),t.querySelector(`.ss-cvar-cancel`)?.addEventListener(`click`,e=>{e.stopPropagation(),D.contactVarEditingKey=null,n.innerHTML=o(s?.value||``),l(),n.querySelector(`#ss-vars-accordion`)?.classList.add(`expanded`)}),t.querySelector(`.ss-cvar-save`)?.addEventListener(`click`,async n=>{n.stopPropagation();let r=n.currentTarget.dataset.key,i=t.querySelector(`.ss-cvar-input`).value,a=n.currentTarget;a.disabled=!0,a.innerHTML=`<span class="ss-spinner" style="width:10px;height:10px;border-width:1px;"></span>`;try{await Zt(e,r,i),D.contactVarEditingKey=null,$t(e)}catch(e){alert(`Update failed: `+e.message),a.disabled=!1,a.innerHTML=F}}),t.querySelector(`.ss-cvar-input`)?.addEventListener(`keydown`,e=>{e.key===`Enter`&&t.querySelector(`.ss-cvar-save`)?.click(),e.key===`Escape`&&t.querySelector(`.ss-cvar-cancel`)?.click()})})};l()}).catch(e=>{let t=k.getElementById(`ss-info-body`);t&&(t.innerHTML=`<div class="ss-error visible">⚠ ${e.message}</div>`)}))}var en=[`id`,`name`,`firstName`,`lastName`,`fullName`,`email`,`phone`,`photo`,`createdAt`,`notes`,`tags`,`values`,`thumb`,`updatedAt`,`system_city`,`system_country`,`system_continent`,`system_timezone`,`system_os`,`system_browser`,`is_active`,`userId`,`projectId`];function tn(e){let t=(e.values||[]).map(e=>({name:e.name,value:e.value}));return Object.keys(e).forEach(n=>{!en.includes(n)&&e[n]!==null&&typeof e[n]!=`object`&&(t.find(e=>e.name===n)||t.push({name:n,value:e[n]}))}),t}function nn(e,t,n){let r=n&&e.name===t;return`
    <div class="ss-info-var${r?` editing`:``}" title="${j(e.name)}: ${j(String(e.value))}">
      <div class="ss-info-var-name">
        <span>${j(e.name)}</span>
        <button class="ss-info-copy-btn" data-copy="${j(e.name)}" title="Copy key">${P}</button>
      </div>
      <div class="ss-info-var-val">
        ${r?`
          <input class="ss-input ss-cvar-input" value="${j(String(e.value))}" style="flex:1;height:22px;font-size:13px;padding:2px 6px;margin-right:4px;" />
          <button class="ss-var-btn ss-cvar-save" data-key="${j(e.name)}" title="Save">${F}</button>
          <button class="ss-var-btn ss-cvar-cancel" title="Cancel">${R}</button>
        `:`
          <span>${j(String(e.value))}</span>
          ${n?`<button class="ss-info-copy-btn ss-cvar-edit" data-key="${j(e.name)}" title="Edit value">${et}</button>`:``}
          <button class="ss-info-copy-btn" data-copy="${j(String(e.value))}" title="Copy value">${P}</button>
        `}
      </div>
    </div>
  `}function rn(e,t,{settings:n,priorityKeys:r,projectSlug:i,filter:a,editingKey:o,editable:s}){let c=a.split(`,`).map(e=>e.trim().toLowerCase()).filter(Boolean),l=(e.tags||[]).filter(e=>!c.length||c.some(t=>e.name.toLowerCase().includes(t))),u=t.filter(e=>!c.length||c.some(t=>e.name.toLowerCase().includes(t)||String(e.value).toLowerCase().includes(t))),d=u.filter(e=>r.includes(e.name.toLowerCase())),f=``;return n.showProfile&&(f+=`
      <div class="ss-info-section" style="display:flex;align-items:center;gap:12px;background:var(--bg2);padding:12px;border-radius:12px;margin-bottom:16px;">
        ${e.photo?`<img src="${e.photo}" style="width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid var(--border);">`:`<div style="width:48px;height:48px;border-radius:50%;background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:20px;">👤</div>`}
        <div style="flex:1;overflow:hidden;">
          <div style="font-weight:800;font-size:16px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;">
            <span style="overflow:hidden;text-overflow:ellipsis;">${j(e.fullName||e.name||`Unnamed`)}</span>
            ${i?`<a href="https://messenger.smartsender.com/chats?project=${i}&selectedContactId=${e.id}" target="_blank" title="Open chat" style="color:var(--text4);text-decoration:none;display:inline-flex;margin-left:8px;flex-shrink:0;">${L}</a>`:``}
            <button class="ss-card-fire-btn" title="Fire Event" style="color:var(--accent);display:inline-flex;align-items:center;justify-content:center;padding:0;width:24px;height:24px;margin-left:6px;border-radius:6px;background:none;border:none;cursor:pointer;flex-shrink:0;">
              ${z}
            </button>
          </div>
          <div style="font-size:13px;color:var(--text4);">ID: <span style="color:var(--accent);font-weight:600;">${e.id}</span></div>
        </div>
      </div>
    `),n.showDetails&&(f+=`
      <div class="ss-info-section">
        <div class="ss-info-label">Basic Data</div>
        ${e.email?`<div class="ss-info-detail-row" title="Email: ${j(e.email)}"><span class="ss-info-detail-label">Email</span><div class="ss-info-detail-value"><span>${j(e.email)}</span><button class="ss-info-copy-btn" data-copy="${j(e.email)}" title="Copy email">${P}</button></div></div>`:``}
        ${e.phone?`<div class="ss-info-detail-row" title="Phone: ${j(e.phone)}"><span class="ss-info-detail-label">Phone</span><div class="ss-info-detail-value"><span>${j(e.phone)}</span><button class="ss-info-copy-btn" data-copy="${j(e.phone)}" title="Copy phone">${P}</button></div></div>`:``}
        <div class="ss-info-detail-row" title="Created: ${e.createdAt?new Date(e.createdAt).toLocaleString():``}"><span class="ss-info-detail-label">Created</span><div class="ss-info-detail-value"><span>${e.createdAt?new Date(e.createdAt).toLocaleDateString():`—`}</span></div></div>
      </div>
    `),d.length>0&&(f+=`
      <div class="ss-priority-section">
        <div class="ss-priority-label">Priority Variables</div>
        ${d.map(e=>nn(e,o,s)).join(``)}
      </div>
    `),n.showTags&&(f+=`
      <div class="ss-info-accordion" id="ss-tags-accordion">
        <div class="ss-info-accordion-header"><span>Tags (${l.length})</span><span class="ss-info-accordion-icon">▾</span></div>
        <div class="ss-info-accordion-content">
          <div class="ss-info-tags">${l.map(e=>`<span class="ss-info-tag">${j(e.name)}</span>`).join(``)||`<div class="ss-hint">No tags matched</div>`}</div>
        </div>
      </div>
    `),n.showVars&&(f+=`
      <div class="ss-info-accordion" id="ss-vars-accordion">
        <div class="ss-info-accordion-header"><span>Variables (${u.length})</span><span class="ss-info-accordion-icon">▾</span></div>
        <div class="ss-info-accordion-content">
          <div class="ss-info-vars">${u.map(e=>nn(e,o,s)).join(``)||`<div class="ss-hint">No variables matched</div>`}</div>
        </div>
      </div>
    `),f}function an(e,t,n){let r=t,i=null,a=``,o=new Set,s=!!(n.editable&&n.onSave);e.innerHTML=`
    ${n.settings.showVars||n.settings.showTags?`<div class="ss-info-search-sticky" style="padding:10px 16px;background:var(--bg-solid);border-bottom:1px solid var(--border);">
      <input class="ss-input ss-card-filter" type="text" placeholder="Filter variables..." style="font-size:13px;padding:6px 10px;height:28px;" />
    </div>`:``}
    <div class="ss-info-body ss-card-body"></div>
  `;let c=e.querySelector(`.ss-card-body`),l=()=>{let e=tn(r);c.innerHTML=rn(r,e,{...n,filter:a,editingKey:i,editable:s}),o.forEach(e=>c.querySelector(`#`+e)?.classList.add(`expanded`)),u()};function u(){c.querySelectorAll(`.ss-info-accordion-header`).forEach(e=>{e.onclick=()=>{let t=e.closest(`.ss-info-accordion`);o.has(t.id)?(o.delete(t.id),t.classList.remove(`expanded`)):(o.add(t.id),t.classList.add(`expanded`))}}),c.querySelectorAll(`[data-copy]`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),N(e.dataset.copy,`Copy`,`Copied: ${e.dataset.copy}`);let n=e.innerHTML;e.innerHTML=F,setTimeout(()=>{e.innerHTML=n},1500)}}),c.querySelectorAll(`.ss-info-detail-row, .ss-info-var`).forEach(e=>{e.onclick=t=>{t.target.closest(`button`)||t.target.closest(`input`)||e.classList.toggle(`expanded`)}}),c.querySelectorAll(`.ss-card-fire-btn`).forEach(t=>{t.onclick=n=>{n.stopPropagation(),n.preventDefault(),Yt({contactId:r.id,contactName:r.fullName||r.name||``,customRoot:t.closest(`#ss-sidebar`)||e.closest?.(`#ss-sidebar`)||e.getRootNode()})}}),s&&(c.querySelectorAll(`.ss-cvar-edit`).forEach(e=>{e.onclick=t=>{t.stopPropagation(),i=e.dataset.key,o.add(`ss-vars-accordion`),l(),setTimeout(()=>c.querySelector(`.ss-cvar-input`)?.focus(),30)}}),c.querySelectorAll(`.ss-cvar-cancel`).forEach(e=>{e.onclick=e=>{e.stopPropagation(),i=null,l()}}),c.querySelectorAll(`.ss-cvar-save`).forEach(e=>{e.onclick=async t=>{t.stopPropagation();let a=e.dataset.key,o=e.closest(`.ss-info-var`).querySelector(`.ss-cvar-input`).value;e.disabled=!0,e.innerHTML=`<span class="ss-spinner" style="width:10px;height:10px;border-width:1px;"></span>`;try{let e=await n.onSave(a,o);e&&(r=e),i=null,l()}catch(t){e.disabled=!1,e.innerHTML=F;let n=e.closest(`.ss-info-var-val`);n&&n.insertAdjacentHTML(`beforeend`,`<span style="color:var(--error);font-size:11px;margin-left:6px;">${j(t.message)}</span>`)}}}),c.querySelectorAll(`.ss-cvar-input`).forEach(e=>{e.onkeydown=t=>{t.key===`Enter`&&e.closest(`.ss-info-var`).querySelector(`.ss-cvar-save`)?.click(),t.key===`Escape`&&e.closest(`.ss-info-var`).querySelector(`.ss-cvar-cancel`)?.click()}}))}l();let d=e.querySelector(`.ss-card-filter`);d&&(d.oninput=e=>{a=e.target.value,a.trim()&&(o.add(`ss-tags-accordion`),o.add(`ss-vars-accordion`)),l()})}function on(e){let t=D.projectId||V()||``;try{chrome.runtime.sendMessage({type:`OPEN_CONTACT_POPUP`,contactId:String(e),projectSlug:t})}catch{}}function sn(){let e=k.getElementById(`ss-body`),t=D.globalSettings,n=chrome.runtime.getManifest().version,r=D.updatePending,i=`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>`,a=y(`ss_last_update_check`,0),o=`Never`;if(a){let e=new Date(a),t=new Date,n=e.toDateString()===t.toDateString(),r=e.toLocaleTimeString(`en-US`,{hour:`numeric`,minute:`2-digit`});o=n?`Today at ${r}`:`${e.toLocaleDateString()} at ${r}`}e.innerHTML=`
      <div style="background:var(--bg2); border:1px solid var(--border); border-radius:8px; padding:16px; margin-bottom:16px; text-align:left;">
        <div style="margin-bottom:14px;">
          <div style="font-size:16px;font-weight:700;color:var(--text);letter-spacing:-0.3px;">mySmart</div>
          <div style="font-size:12px;color:var(--text3);">mySender Tools for SmartSender</div>
        </div>
        <div style="font-size:14px; font-weight:600; color:var(--text); margin-bottom:6px;">
          Local Version: v${n}
        </div>
        ${r?`<div style="display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;color:var(--error);">
               ${i} Update Ready: v${D.newVersion||`latest`}
             </div>`:`<div style="display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;color:#22c55e;">
               <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg> Version is up to date
             </div>`}
        <div style="height:2px;background:var(--border);margin:16px 0;opacity:0.6;"></div>
        
        ${r?`<button class="ss-btn" id="ss-btn-apply-update" style="width:100%;height:40px;border-radius:8px;background:var(--error);color:white;font-weight:600;font-size:14px;display:flex;align-items:center;justify-content:center;gap:8px;border:none;cursor:pointer;">
               ${i} Restart to Update
             </button>`:`<button class="ss-btn" id="ss-btn-check-update" style="width:100%;height:40px;border-radius:8px;background:var(--accent);color:var(--accent-text);font-weight:600;font-size:14px;display:flex;align-items:center;justify-content:center;gap:8px;border:none;cursor:pointer;">
               ${i} Check for Updates
             </button>`}
        
        <div style="font-size:12px;font-weight:600;color:var(--text4);text-align:center;margin-top:12px;">
          Last checked: ${o}
        </div>
      </div>

        <div style="font-size:12px;color:var(--text4);margin-top:12px;line-height:1.4;padding:0 10px;">
          This application does not send any sensitive data (such as project API keys) to the server. Your privacy and security are our priority.
        </div>
      </div>
      <div class="ss-divider" style="margin:16px 0;"></div>
      
      <div style="background:rgba(245,158,11,0.1); border:1px solid rgba(245,158,11,0.3); border-radius:6px; padding:10px; margin-bottom:16px; text-align:center;">
        <div style="font-size:12px; font-weight:600; color:#f59e0b; margin-bottom:4px;">Demo Testing Mode</div>
        <div style="font-size:11px; color:var(--text3); line-height:1.4;">The extension is currently in demo mode. You may encounter bugs or unexpected behavior. Please use the form below to report any issues.</div>
      </div>

      <div class="ss-section-label" style="margin-bottom:12px;">Feedback & Support</div>
      
      <div id="ss-feedback-form-container" style="background:var(--bg2); border:1px solid var(--border); border-radius:6px; padding:12px; display:flex; flex-direction:column; gap:12px; position:relative;">
        <input type="text" id="ss-feedback-hp" name="hp_field" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;opacity:0;height:0;width:0;pointer-events:none;" />
        <div>
          <label style="display:block;font-size:11px;color:var(--text4);margin-bottom:4px;">Name <span style="color:var(--error);">*</span></label>
          <input type="text" id="ss-feedback-name" class="ss-input" placeholder="Your name" value="${j(t.feedbackName||``)}" />
        </div>
        <div>
          <label style="display:block;font-size:11px;color:var(--text4);margin-bottom:4px;">Email <span style="color:var(--error);">*</span></label>
          <input type="email" id="ss-feedback-email" class="ss-input" placeholder="Your email" value="${j(t.feedbackEmail||``)}" />
        </div>
        <div>
          <label style="display:block;font-size:11px;color:var(--text4);margin-bottom:4px;">Topic <span style="color:var(--error);">*</span></label>
          <div style="position:relative;">
            <select id="ss-feedback-type" class="ss-input" style="appearance:none;cursor:pointer;width:100%;">
              <option value="bug">Bug Report</option>
              <option value="idea">Feature Idea</option>
              <option value="support">Support</option>
              <option value="other">Other</option>
            </select>
            <svg style="position:absolute;right:8px;top:50%;transform:translateY(-50%);pointer-events:none;color:var(--text4);" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
          </div>
        </div>
        <div>
          <label style="display:block;font-size:11px;color:var(--text4);margin-bottom:4px;">Description <span style="color:var(--error);">*</span></label>
          <textarea id="ss-feedback-desc" class="ss-input" rows="4" placeholder="Describe your problem or idea in detail..." style="resize:vertical;"></textarea>
        </div>
        <div id="ss-feedback-msg" style="display:none;font-size:13px;padding:8px;border-radius:4px;margin-top:4px;"></div>
        <button id="ss-feedback-submit" class="ss-btn-search" style="justify-content:center;margin-top:4px;padding:10px;color:var(--accent-text);">Send Feedback</button>
      </div>

      <div id="ss-feedback-success-container" style="display:none; background:var(--bg2); border:1px solid var(--border); border-radius:6px; padding:32px 16px; flex-direction:column; align-items:center; gap:12px; text-align:center;">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--success)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
        <div style="font-size:16px;font-weight:600;color:var(--text2);margin-top:8px;">Feedback Sent!</div>
        <div style="font-size:13px;color:var(--text4);">Thank you for helping us improve SmartSender Assistant.</div>
      </div>
    `;let s=k.getElementById(`ss-feedback-name`),c=k.getElementById(`ss-feedback-email`),l=k.getElementById(`ss-feedback-type`),u=k.getElementById(`ss-feedback-desc`),d=k.getElementById(`ss-feedback-hp`),f=k.getElementById(`ss-feedback-submit`),p=k.getElementById(`ss-feedback-msg`);f.onclick=async()=>{let e=s.value.trim(),n=c.value.trim(),r=l.value,i=u.value.trim(),a=d?d.value.trim():``;[s,c,l,u].forEach(e=>e.style.borderColor=``);let o=[];if(e||o.push(s),n||o.push(c),r||o.push(l),i||o.push(u),o.length>0){o.forEach(e=>e.style.borderColor=`var(--error)`),p.textContent=`Please fill out all required fields.`,p.style.cssText=`display:block;font-size:13px;padding:8px;border-radius:4px;margin-top:4px;background:rgba(239,68,68,0.1);color:var(--error);`;return}p.style.display=`none`,f.disabled=!0,f.innerHTML=`Sending...`,t.feedbackName=s.value.trim(),t.feedbackEmail=c.value.trim(),T(t);let m=Ct(),h={type:l.value,message:i,name:t.feedbackName,email:t.feedbackEmail,hp_field:a,pageUrl:m||location.href,pageTitle:D.projectName?`SmartSender [${D.projectName}]`:document.title||`SmartSender`,extensionName:chrome.runtime.getManifest().name,extensionVersion:chrome.runtime.getManifest().version,browser:`Chrome`,locale:navigator.language,userAgent:navigator.userAgent,userId:``,installId:t.installId,meta:{section:`about-tab`,projectId:D.projectId||null,severity:l.value===`bug`?`high`:`medium`}};try{let e=await fetch(`https://extension-feedback-api.batalshikov-d.workers.dev/api/feedback`,{method:`POST`,headers:{"Content-Type":`application/json`,"X-Feedback-Origin":`mysender-tools-ext`},body:JSON.stringify(h)});if(!e.ok){let t=await e.json().catch(()=>({}));throw Error(t.error||`Server returned ${e.status}`)}let t=k.getElementById(`ss-feedback-form-container`),n=k.getElementById(`ss-feedback-success-container`);t.style.display=`none`,n.style.display=`flex`,O(`Feedback Sent`,`Type: ${l.value}`)}catch(e){p.textContent=`Error: `+e.message,p.style.cssText=`display:block;font-size:13px;padding:8px;border-radius:4px;margin-top:4px;background:rgba(239,68,68,0.1);color:var(--error);`}finally{f.disabled=!1,f.innerHTML=`Send Feedback`}};let m=k.getElementById(`ss-btn-check-update`);m&&m.addEventListener(`click`,()=>{m.disabled=!0,m.innerHTML=`Checking...`,Lt(!0),setTimeout(()=>{m&&(m.disabled=!1,m.innerHTML=`Check for Updates`)},3e3)});let h=k.getElementById(`ss-btn-apply-update`);h&&h.addEventListener(`click`,()=>{chrome.runtime.reload()})}function cn(){if(D.selectedContactId){ln(D.selectedContactId);return}let e=k.getElementById(`ss-body`);e.innerHTML=`
      <div style="margin-bottom:12px;">
        <div style="display:flex;gap:12px;align-items:center;margin-bottom:8px;">
          <span class="ss-text-link" id="ss-contact-hist-btn">HISTORY</span>
          <span class="ss-text-link" id="ss-contact-settings-btn">OPTIONS</span>
          <span class="ss-text-link" id="ss-contact-fav-btn" style="${D.contactFavorites.length>0?``:`display:none;`}">FAVORITE</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:8px;">
          <input class="ss-input" id="ss-contact-input" type="text" placeholder="Email or User ID" autocomplete="off" value="${j(D.contactSearchTerm||``)}" style="width:100%;box-sizing:border-box;" />
          <div style="display:flex;gap:8px;align-items:center;">
            <button class="ss-btn-search" id="ss-contact-btn" title="Search" style="flex:1;justify-content:center;background:var(--accent);color:var(--accent-text);">Search</button>
            <button class="ss-btn-search" id="ss-contact-reset-btn" title="Reset Search" style="width:auto;padding:8px 12px;justify-content:center;background:var(--bg3);color:var(--text2);">${I.replace(`width="24" height="24"`,`width="16" height="16"`)}</button>
          </div>
        </div>
      </div>
      <div id="ss-contact-list" style="display:flex;flex-direction:column;gap:6px;"></div>
      <div class="ss-error" id="ss-contact-error"></div>
      <div class="ss-loading" id="ss-contact-loading" style="display:none;"><div class="ss-spinner"></div><span class="ss-loading-text">Searching...</span></div>
    `,Z(),dn(),un()}function ln(e){let t=k.getElementById(`ss-body`);if(!t)return;D.selectedContactId=e,t.innerHTML=`
      <div class="ss-contact-detail-view" style="display:flex;flex-direction:column;min-height:100%;">
        <div class="ss-contact-toolbar" style="display:flex;align-items:center;justify-content:space-between;padding:0 0 10px 0;margin-bottom:8px;border-bottom:1px solid var(--border);">
          <div style="display:flex;align-items:center;gap:8px;min-width:0;flex:1;">
            <button class="ss-var-btn" id="ss-contact-back-btn" title="Back to contacts list" style="display:inline-flex;align-items:center;justify-content:center;padding:0;width:30px;height:30px;border-radius:8px;background:var(--bg3);color:var(--text);border:none;cursor:pointer;flex-shrink:0;">
              ${ct}
            </button>
            <div id="ss-contact-detail-title" style="font-weight:700;font-size:15px;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
              Contact #${e}
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
            <button class="ss-var-btn" id="ss-contact-refresh-btn" title="Refresh contact data" style="display:inline-flex;align-items:center;justify-content:center;padding:0;width:30px;height:30px;border-radius:8px;background:var(--bg3);color:var(--text2);border:none;cursor:pointer;">
              ${I.replace(`width="24" height="24"`,`width="15" height="15"`)}
            </button>
            <button class="ss-var-btn" id="ss-contact-popout-btn" title="Open in separate popup window" style="display:inline-flex;align-items:center;justify-content:center;padding:0;width:30px;height:30px;border-radius:8px;background:var(--bg3);color:var(--text2);border:none;cursor:pointer;">
              ${L.replace(`width="16" height="16"`,`width="15" height="15"`)}
            </button>
          </div>
        </div>
        <div id="ss-contact-detail-container" style="flex:1;"></div>
      </div>
    `;let n=k.getElementById(`ss-contact-back-btn`);n&&(n.onclick=()=>{D.selectedContactId=null,cn()});let r=k.getElementById(`ss-contact-refresh-btn`);r&&(r.onclick=()=>X(e,!0));let i=k.getElementById(`ss-contact-popout-btn`);i&&(i.onclick=()=>on(e)),X(e)}async function X(e,t=!1){let n=k.getElementById(`ss-contact-detail-container`),r=k.getElementById(`ss-contact-detail-title`),i=k.getElementById(`ss-contact-refresh-btn`);if(n){t&&i?i.classList.add(`ss-spinning`):n.innerHTML=`<div class="ss-loading" style="display:flex;padding:32px 0;"><div class="ss-spinner"></div><span class="ss-loading-text">Loading details...</span></div>`;try{let t=await Y(e);if(D.selectedContactId!=e)return;r&&(r.textContent=t.fullName||t.name||`Contact #${e}`),n.innerHTML=``,an(n,t,{settings:D.contactSettings||we(),priorityKeys:(E(D.projectId)||``).split(`,`).map(e=>e.trim().toLowerCase()).filter(Boolean),projectSlug:D.projectId||V()||``,editable:!0,onSave:async(t,n)=>(await Zt(e,t,n),await Y(e))})}catch(t){D.selectedContactId==e&&(n.innerHTML=`<div class="ss-error visible" style="margin:16px 0;">⚠ ${j(t.message||`Failed to load contact`)}</div>`)}finally{i&&i.classList.remove(`ss-spinning`)}}}async function un(){let e=Tt();if(e){if(!D.activeUrlContact||D.activeUrlContact.id!=e)try{let t=W();if(t){let n=await G(`https://api.smartsender.com/v1/contacts/${e}`,`GET`,t);n&&n.id&&(D.activeUrlContact=n,D.activeTab===`contacts`&&Z())}}catch(e){console.warn(`[Contacts] URL Contact lookup failed:`,e.message)}}else D.activeUrlContact&&(D.activeUrlContact=null,D.activeTab===`contacts`&&Z())}function dn(){let e=k.getElementById(`ss-contact-input`),t=k.getElementById(`ss-contact-btn`),n=k.getElementById(`ss-contact-loading`),r=k.getElementById(`ss-contact-error`),i=k.getElementById(`ss-contact-hist-btn`),a=k.getElementById(`ss-contact-search-hist`),o=k.getElementById(`ss-contact-fav-btn`),s=k.getElementById(`ss-contact-fav-panel`),c=k.getElementById(`ss-contact-settings-btn`),l=k.getElementById(`ss-contact-settings-panel`),u=()=>{if(D.contactShowSearchHist=!D.contactShowSearchHist,!D.contactShowSearchHist){k.getElementById(`ss-contact-search-hist`).classList.remove(`open`),i.classList.remove(`active`);return}D.contactShowFavorites=!1,D.contactSettingsOpen=!1,o.classList.remove(`active`),c.classList.remove(`active`),i.classList.add(`active`);let t=ye(D.projectId),n=(r=``)=>{let i=t.filter(e=>e.toLowerCase().includes(r.toLowerCase())),o=i.length?i.map((e,t)=>`<div class="ss-hist-term" data-term="${j(e)}">${j(e)}</div>`).join(``):`<div class="ss-hist-term" style="opacity:0.5;cursor:default;">${r?`No matches`:`No history`}</div>`;a.innerHTML=`
          <div class="ss-info-header">
            <div class="ss-info-title">Search History</div>
            <button class="ss-close ss-close-extra-panel">${R}</button>
          </div>
          <div class="ss-panel-search-wrapper">
            <input type="text" class="ss-panel-search-input" id="ss-hist-filter" placeholder="Quick search..." value="${j(r)}">
          </div>
          <div class="ss-panel-list-content">
            ${o}
          </div>
        `;let s=a.querySelector(`#ss-hist-filter`);s.focus(),s.oninput=e=>n(e.target.value),a.querySelectorAll(`.ss-hist-term[data-term]`).forEach(t=>{t.onclick=()=>{e.value=t.dataset.term,u(),m()}})};n(),$(`ss-contact-search-hist`)},d=()=>{if(D.contactShowFavorites=!D.contactShowFavorites,!D.contactShowFavorites){s.classList.remove(`open`),o.classList.remove(`active`);return}D.contactShowSearchHist=!1,D.contactSettingsOpen=!1,i.classList.remove(`active`),c.classList.remove(`active`),o.classList.add(`active`),fn(),$(`ss-contact-fav-panel`)},f=()=>{if(D.contactSettingsOpen=!D.contactSettingsOpen,!D.contactSettingsOpen){l.classList.remove(`open`),c.classList.remove(`active`);return}D.contactShowSearchHist=!1,D.contactShowFavorites=!1,i.classList.remove(`active`),o.classList.remove(`active`),c.classList.add(`active`),pn(),$(`ss-contact-settings-panel`)},p=()=>{e.value=``,D.contactSearchTerm=``,D.contactResults=[],D.contactSearchPerformed=!1,Z(),r.classList.remove(`visible`)},m=async(c=null)=>{let l=c||e.value.trim();if(l){D.contactSearchTerm=l,c||be(D.projectId,l),O(`Search Contacts`,`Query: "${l}"`),D.contactShowSearchHist=!1,a&&a.classList.remove(`open`),D.contactShowFavorites=!1,s&&s.classList.remove(`open`),i.classList.remove(`active`),o.classList.remove(`active`),D.isSearchingContact=!0,D.contactSearchPerformed=!0,t.disabled=!0,n.style.display=`flex`,r.classList.remove(`visible`);try{D.contactResults=await Xt(l),Z()}catch(e){r.textContent=`⚠ ${e.message}`,r.classList.add(`visible`)}finally{D.isSearchingContact=!1,t.disabled=!1,n.style.display=`none`}}};i&&(i.onclick=e=>{e.stopPropagation(),u()}),o&&(o.onclick=e=>{e.stopPropagation(),d()}),c&&(c.onclick=e=>{e.stopPropagation(),f()}),t&&(t.onclick=()=>m());let h=k.getElementById(`ss-contact-reset-btn`);h&&(h.onclick=p),e&&(e.onkeydown=e=>{e.key===`Enter`&&m()},e.addEventListener(`input`,A(e=>{let t=e.target.value.trim();t.length>=2?D.globalSettings.autoFetch&&m():t||p()},400))),document.addEventListener(`click`,e=>{let t=e.composedPath()[0]||e.target;D.contactShowSearchHist&&!a.contains(t)&&t!==i&&(D.contactShowSearchHist=!1,a.classList.remove(`open`),i.classList.remove(`active`)),D.contactShowFavorites&&!s.contains(t)&&t!==o&&(D.contactShowFavorites=!1,s.classList.remove(`open`),o.classList.remove(`active`)),D.contactSettingsOpen&&!l.contains(t)&&t!==c&&(D.contactSettingsOpen=!1,l.classList.remove(`open`),c.classList.remove(`active`))})}function fn(){let e=k.getElementById(`ss-contact-fav-panel`);if(!e)return;let t=D.contactFavorites,n=(r=``)=>{let i=t.filter(e=>e.name.toLowerCase().includes(r.toLowerCase())||e.id.toString().includes(r)),a=i.length?i.map(e=>`
          <div class="ss-hist-term" data-id="${e.id}" style="display:flex;align-items:center;gap:8px;">
            ${e.photo?`<img src="${e.photo}" style="width:20px;height:20px;border-radius:50%;">`:`👤`}
            <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${j(e.name)}</span>
            <span style="font-size:12px;color:var(--text4);">${e.id}</span>
          </div>
        `).join(``):`<div class="ss-hist-term" style="opacity:0.5;cursor:default;">${r?`No matches`:`No favorites yet`}</div>`;e.innerHTML=`
        <div class="ss-info-header">
          <div class="ss-info-title">Favorites</div>
          <button class="ss-close ss-close-extra-panel">${R}</button>
        </div>
        <div class="ss-panel-search-wrapper">
          <input type="text" class="ss-panel-search-input" id="ss-fav-filter" placeholder="Filter favorites..." value="${j(r)}">
        </div>
        <div class="ss-panel-list-content">
          ${a}
        </div>
      `;let o=e.querySelector(`#ss-fav-filter`);o.focus(),o.oninput=e=>n(e.target.value),e.querySelectorAll(`.ss-hist-term[data-id]`).forEach(t=>{t.onclick=()=>{D.contactShowFavorites=!1,e.classList.remove(`open`),k.getElementById(`ss-contact-fav-btn`)?.classList.remove(`active`),ln(t.dataset.id)}})};n()}function pn(){let e=k.getElementById(`ss-contact-settings-panel`);if(!e)return;let t=D.projectId,n=E(t);e.innerHTML=`
      <div class="ss-info-header">
        <div class="ss-info-title">Options</div>
        <button class="ss-close ss-close-extra-panel">${R}</button>
      </div>
      <div style="padding:16px;">
        <div class="ss-settings-item" id="ss-toggle-profile">
          <span>Profile Header</span>
          <div class="ss-settings-check ${D.contactSettings.showProfile?`active`:``}">${D.contactSettings.showProfile?`✓`:``}</div>
        </div>
        <div class="ss-settings-item" id="ss-toggle-details">
          <span>Basic Data</span>
          <div class="ss-settings-check ${D.contactSettings.showDetails?`active`:``}">${D.contactSettings.showDetails?`✓`:``}</div>
        </div>
        <div class="ss-settings-item" id="ss-toggle-tags">
          <span>Tags</span>
          <div class="ss-settings-check ${D.contactSettings.showTags?`active`:``}">${D.contactSettings.showTags?`✓`:``}</div>
        </div>
        <div class="ss-settings-item" id="ss-toggle-vars">
          <span>Variables</span>
          <div class="ss-settings-check ${D.contactSettings.showVars?`active`:``}">${D.contactSettings.showVars?`✓`:``}</div>
        </div>
        <div style="height:1px;background:var(--border);margin:12px 0;"></div>
        <div class="ss-settings-item" id="ss-toggle-compact">
          <span>Compact Search Cards</span>
          <div class="ss-settings-check ${D.contactSettings.compactCards?`active`:``}">${D.contactSettings.compactCards?`✓`:``}</div>
        </div>
        
        <div style="height:1px;background:var(--border);margin:12px 0;"></div>
        <div class="ss-section-label" style="margin-bottom:8px;padding:0;color:var(--text2);">Priority Variables</div>
        <div style="display:flex;gap:6px;align-items:center;margin-bottom:4px;">
          <input type="text" class="ss-input" id="ss-priority-vars-input" placeholder="key1, key2, key3..." value="${j(n)}" style="flex:1;font-size:13px;padding:8px 12px;height:32px;">
          <button class="ss-btn-primary" id="ss-priority-vars-save" style="width:44px;height:32px;padding:0;justify-content:center;" title="Apply Filter">${F}</button>
        </div>
        <div class="ss-hint" style="margin-top:4px;color:var(--text5);">Show these at the top (per project)</div>
      </div>
    `,e.querySelector(`#ss-priority-vars-save`)?.addEventListener(`click`,()=>{je(t,e.querySelector(`#ss-priority-vars-input`)?.value||``),D.selectedContactId&&X(D.selectedContactId),D.contactInfoId&&$t(D.contactInfoId);let n=e.querySelector(`#ss-priority-vars-save`),r=n.innerHTML;n.innerHTML=`✓`,setTimeout(()=>n.innerHTML=r,1e3)}),e.querySelector(`#ss-priority-vars-input`)?.addEventListener(`keydown`,t=>{t.key===`Enter`&&e.querySelector(`#ss-priority-vars-save`)?.click()}),e.querySelectorAll(`.ss-settings-item`).forEach(e=>{e.onclick=t=>{t.stopPropagation();let n;e.id===`ss-toggle-profile`?n=`showProfile`:e.id===`ss-toggle-details`?n=`showDetails`:e.id===`ss-toggle-tags`?n=`showTags`:e.id===`ss-toggle-vars`?n=`showVars`:e.id===`ss-toggle-compact`&&(n=`compactCards`),D.contactSettings[n]=!D.contactSettings[n],Te(D.contactSettings),pn(),D.selectedContactId&&X(D.selectedContactId),D.contactInfoId&&$t(D.contactInfoId),D.selectedContactId||Z()}})}function Z(){let e=k.getElementById(`ss-contact-list`);if(!e)return;if(e.innerHTML=``,!D.contactResults.length&&!D.activeUrlContact){D.contactSearchPerformed&&(e.innerHTML=`<div class="ss-empty">No contacts found</div>`);return}let t=(e,t)=>{let n=document.createElement(`div`);n.className=`ss-var-card`,n.style.padding=`12px`,t&&(n.style.border=`1px solid var(--accent)`),n.onclick=()=>ln(e.id);let r=e.photo?`<img src="${e.photo}" style="width:32px;height:32px;border-radius:50%;object-fit:cover;">`:`<div style="width:32px;height:32px;border-radius:50%;background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:16px;">👤</div>`;n.innerHTML=`
        <div style="display:flex;gap:12px;align-items:center;${D.contactSettings.compactCards?``:`margin-bottom:8px;`}">
          ${r}
          <div style="min-width:0;flex:1;">
            <div style="font-weight:700;color:var(--text);font-size:16px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${j(e.fullName||`Unnamed`)}</div>
            <div style="font-size:13px;color:var(--text4);">ID: <span style="color:var(--accent);font-weight:600;">${e.id}</span></div>
          </div>
          <div style="display:flex;gap:4px;align-items:center;">
            <button class="ss-var-btn ss-popout-btn" data-id="${e.id}" title="Open in separate popup window" style="color:var(--text4);display:inline-flex;align-items:center;justify-content:center;padding:0;width:28px;height:28px;">
              ${L.replace(`width="16" height="16"`,`width="13" height="13"`)}
            </button>
            <button class="ss-var-btn ss-fav-btn" data-id="${e.id}" title="${D.contactFavorites.some(t=>t.id==e.id)?`Remove from favorites`:`Add to favorites`}" style="color:${D.contactFavorites.some(t=>t.id==e.id)?`var(--accent)`:`var(--text4)`};">
              ${D.contactFavorites.some(t=>t.id==e.id)?it:rt}
            </button>
            <button class="ss-var-btn ss-fire-btn" data-id="${e.id}" title="Fire Event" style="color:var(--accent);display:inline-flex;align-items:center;justify-content:center;padding:0;width:28px;height:28px;">
              ${z}
            </button>
            ${V()?`
              <a href="https://messenger.smartsender.com/chats?project=${V()}&selectedContactId=${e.id}" 
                 target="_blank" title="Open chat" class="ss-var-btn" 
                 onclick="event.stopPropagation();"
                 style="color:var(--text4);text-decoration:none;display:inline-flex;align-items:center;justify-content:center;padding:0;width:28px;height:28px;">
                 ${L.replace(`width="16" height="16"`,`width="12" height="12"`)}
              </a>
            `:``}
            <button class="ss-var-btn ss-copy-btn" data-copy="${e.id}" title="Copy ID">${P}</button>
          </div>
        </div>
        ${!D.contactSettings.compactCards&&e.email?`<div style="font-size:14px;color:var(--text3);display:flex;align-items:center;gap:6px;"><span style="font-size:12px;">✉</span> ${j(e.email)}</div>`:``}
        ${!D.contactSettings.compactCards&&e.phone?`<div style="font-size:14px;color:var(--text3);display:flex;align-items:center;gap:6px;margin-top:2px;"><span style="font-size:12px;">📞</span> ${j(e.phone)}</div>`:``}
      `;let i=n.querySelector(`.ss-popout-btn`);i&&(i.onclick=t=>{t.stopPropagation(),on(e.id)});let a=n.querySelector(`.ss-fire-btn`);return a&&(a.onclick=t=>{t.stopPropagation(),t.preventDefault(),Yt({contactId:e.id,contactName:e.fullName||e.name||``,customRoot:n.closest(`#ss-sidebar`)||k})}),n.querySelector(`.ss-copy-btn`).onclick=e=>{let t=e.currentTarget;e.stopPropagation(),N(t.dataset.copy,`Copy Contact ID`,`Copied ID: ${t.dataset.copy}`),t.innerHTML=F,setTimeout(()=>t.innerHTML=P,1500)},n.querySelector(`.ss-fav-btn`).onclick=t=>{let n=t.currentTarget;t.stopPropagation();let r=n.dataset.id,i=D.contactFavorites.findIndex(e=>e.id==r);if(i>-1)D.contactFavorites.splice(i,1);else{if(D.contactFavorites.length>=100){M(`Limit of 100 favorites reached`);return}D.contactFavorites.unshift({id:e.id,name:e.fullName||`Unnamed`,photo:e.photo})}Oe(D.contactFavorites),Z();let a=k.getElementById(`ss-contact-fav-btn`);a&&(a.style.display=D.contactFavorites.length>0?``:`none`);let o=k.getElementById(`ss-contact-fav-panel`);o&&o.classList.contains(`open`)&&fn()},n};D.activeUrlContact&&e.appendChild(t(D.activeUrlContact,!0)),D.contactResults.forEach(n=>{D.activeUrlContact&&n.id==D.activeUrlContact.id||e.appendChild(t(n,!1))})}function mn(){let e=k.getElementById(`ss-body`);e.innerHTML=`
      <div style="margin-bottom:12px;">
        <div class="ss-section-label">Action Logs</div>
        <div style="display:flex;gap:6px;align-items:center;margin-bottom:8px;">
          <input class="ss-input" id="ss-log-filter" type="text" placeholder="Filter by action or details..." autocomplete="off" style="flex:1;" />
        </div>
        <div style="display:flex;gap:6px;align-items:center;">
          <div style="font-size:11px;color:var(--text4);">Showing latest 1000 actions across all projects.</div>
        </div>
      </div>
      <div id="ss-log-list" style="display:flex;flex-direction:column;gap:6px;"></div>
    `;let t=k.getElementById(`ss-log-filter`),n=k.getElementById(`ss-log-list`),r=(e=``)=>{let t=Pe(),r=t.filter(t=>t.action.toLowerCase().includes(e.toLowerCase())||t.detail.toLowerCase().includes(e.toLowerCase())||t.project&&t.project.toLowerCase().includes(e.toLowerCase()));if(!r.length){n.innerHTML=`<div class="ss-empty">${t.length===0?`No logs recorded yet.`:`No logs match filter.`}</div>`;return}n.innerHTML=r.map(e=>{let t=new Date(e.time),n=t.toLocaleTimeString([],{hour12:!1}),r=t.toLocaleDateString(),i=!!e.payload;return`
          <div class="ss-var-card ${i?`ss-log-expandable`:``}" style="padding:10px;display:flex;flex-direction:column;gap:4px;${i?`cursor:pointer;`:``}">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <div style="font-size:12px;font-weight:600;color:${e.action.includes(`Error`)?`var(--error)`:e.action.includes(`API Request`)?`var(--accent)`:`var(--text)`};">${j(e.action)}</div>
              <div style="font-size:11px;color:var(--text5);">${r} ${n}</div>
            </div>
            <div style="font-size:13px;color:var(--text2);word-break:break-word;line-height:1.4;">
              ${j(e.detail)}
              ${i?`<span style="font-size:10px;color:var(--text4);margin-left:8px;opacity:0.7;">(Click to expand)</span>`:``}
            </div>
            ${e.project?`<div style="font-size:11px;color:var(--text4);margin-top:4px;">Project ID: ${j(e.project)}</div>`:``}
            ${i?`<div class="ss-log-payload" style="display:none;margin-top:8px;padding:8px;background:var(--bg3);border:1px solid var(--border);border-radius:6px;font-family:monospace;font-size:11px;color:var(--text3);white-space:pre-wrap;word-break:break-all;">${j(e.payload)}</div>`:``}
          </div>
        `}).join(``),n.querySelectorAll(`.ss-log-expandable`).forEach(e=>{e.onclick=()=>{let t=e.querySelector(`.ss-log-payload`);t.style.display===`none`?t.style.display=`block`:t.style.display=`none`}})};t.oninput=A(e=>r(e.target.value.trim()),300),r()}function hn(){let e=k.getElementById(`ss-body`);if(!e)return;let t=D.projectId,n=xe(t),r=Tt()||D.activeUrlContact?.id||``,i=D.activeUrlContact?.fullName||D.activeUrlContact?.name||``,a=[...new Set(n.map(e=>e.name).filter(Boolean))].slice(0,6);e.innerHTML=`
    <div style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <span class="ss-section-label" style="padding:0;margin:0;">Fire Trigger Event</span>
        ${n.length>0?`<span class="ss-text-link" id="ss-event-clear-hist">CLEAR HISTORY</span>`:``}
      </div>

      ${r?`
        <div id="ss-event-active-contact-banner" style="background:var(--accent-bg);border:1px solid rgba(var(--accent-rgb),0.3);border-radius:8px;padding:8px 12px;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;" title="Click to use this contact">
          <div style="display:flex;align-items:center;gap:8px;overflow:hidden;">
            <span style="color:var(--accent);display:inline-flex;">${z}</span>
            <span style="font-size:12px;color:var(--text);font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              Active contact: ${j(i||r)} (${j(r)})
            </span>
          </div>
          <span style="font-size:11px;color:var(--accent);font-weight:700;flex-shrink:0;">USE</span>
        </div>
      `:``}

      <div style="background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:12px;">
        <div>
          <label style="display:block;font-size:11px;font-weight:700;color:var(--text3);text-transform:uppercase;margin-bottom:4px;">
            Contact ID <span style="color:var(--error);">*</span>
          </label>
          <input class="ss-input" id="ss-event-contact-id" type="text" placeholder="Contact ID (e.g. 1234567)" autocomplete="off" value="${j(D.eventContactId||r||``)}" style="width:100%;box-sizing:border-box;" />
        </div>

        <div>
          <label style="display:block;font-size:11px;font-weight:700;color:var(--text3);text-transform:uppercase;margin-bottom:4px;">
            Event Name (name) <span style="color:var(--error);">*</span>
          </label>
          <input class="ss-input" id="ss-event-name" type="text" placeholder="Event trigger name (e.g. start_funnel)" autocomplete="off" value="${j(D.eventName||``)}" style="width:100%;box-sizing:border-box;" />
        </div>

        ${a.length>0?`
          <div>
            <div style="font-size:11px;color:var(--text4);margin-bottom:6px;">Recent Event Names:</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px;">
              ${a.map(e=>`
                <button type="button" class="ss-tab-event-chip" data-name="${j(e)}" style="background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:3px 10px;font-size:11px;color:var(--text2);cursor:pointer;">
                  ${j(e)}
                </button>
              `).join(``)}
            </div>
          </div>
        `:``}

        <div style="display:flex;gap:8px;align-items:center;margin-top:4px;">
          <button class="ss-btn-search" id="ss-event-fire-btn" title="Fire Trigger Event" style="flex:1;justify-content:center;background:var(--accent);color:var(--accent-text);display:flex;align-items:center;gap:6px;height:36px;border-radius:8px;">
            ${z}
            <span>Fire Event</span>
          </button>
          <button class="ss-btn-search" id="ss-event-reset-btn" title="Clear Inputs" style="width:auto;padding:8px 12px;justify-content:center;background:var(--bg3);color:var(--text2);height:36px;border-radius:8px;">
            ${I.replace(`width="24" height="24"`,`width="16" height="16"`)}
          </button>
        </div>

        <div id="ss-event-feedback" style="display:none;font-size:12px;padding:10px 12px;border-radius:8px;line-height:1.4;"></div>
      </div>
    </div>

    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <span class="ss-section-label" style="padding:0;margin:0;">Recent Events (${n.length})</span>
    </div>

    <div id="ss-event-history-list" style="display:flex;flex-direction:column;gap:8px;">
      ${gn(n)}
    </div>
  `,_n()}function gn(e){if(!e||e.length===0)return`<div class="ss-empty">No events fired yet.</div>`;let t=V();return e.map(e=>{let n=e.timestamp?new Date(e.timestamp).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}):``,r=e.timestamp?new Date(e.timestamp).toLocaleDateString():``;return`
      <div class="ss-var-card" style="padding:12px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
          <div style="min-width:0;flex:1;">
            <div style="display:flex;align-items:center;gap:6px;">
              <span style="color:var(--accent);display:inline-flex;">${z}</span>
              <span style="font-weight:700;color:var(--text);font-size:15px;word-break:break-all;">${j(e.name)}</span>
            </div>
            <div style="font-size:13px;color:var(--text3);margin-top:4px;">
              Contact ID: <span style="color:var(--accent);font-weight:600;">${j(e.contactId)}</span>
              ${e.contactName?`<span style="color:var(--text4);"> • ${j(e.contactName)}</span>`:``}
            </div>
            <div style="font-size:11px;color:var(--text5);margin-top:4px;">
              ${r} ${n}
            </div>
          </div>
          <div style="display:flex;gap:4px;align-items:center;">
            <button class="ss-var-btn ss-event-refire-btn" data-cid="${j(e.contactId)}" data-name="${j(e.name)}" title="Re-fire event" style="color:var(--accent);display:inline-flex;align-items:center;justify-content:center;padding:0;width:28px;height:28px;">
              ${z}
            </button>
            ${t?`
              <a href="https://messenger.smartsender.com/chats?project=${t}&selectedContactId=${j(e.contactId)}" 
                 target="_blank" title="Open chat" class="ss-var-btn" 
                 style="color:var(--text4);text-decoration:none;display:inline-flex;align-items:center;justify-content:center;padding:0;width:28px;height:28px;">
                 ${L.replace(`width="16" height="16"`,`width="12" height="12"`)}
              </a>
            `:``}
            <button class="ss-var-btn ss-event-copy-btn" data-copy="${j(e.contactId)}" title="Copy Contact ID" style="padding:0;width:28px;height:28px;">
              ${P}
            </button>
          </div>
        </div>
      </div>
    `}).join(``)}function _n(){let e=k.getElementById(`ss-event-contact-id`),t=k.getElementById(`ss-event-name`),n=k.getElementById(`ss-event-fire-btn`),r=k.getElementById(`ss-event-reset-btn`),i=k.getElementById(`ss-event-feedback`),a=k.getElementById(`ss-event-clear-hist`),o=k.getElementById(`ss-event-active-contact-banner`);o&&(o.onclick=()=>{let n=Tt()||D.activeUrlContact?.id||``;e&&n&&(e.value=n,t?.focus())}),k.querySelectorAll(`.ss-tab-event-chip`).forEach(e=>{e.onclick=()=>{t&&(t.value=e.dataset.name,t.focus())}}),a&&(a.onclick=()=>{Ce(D.projectId),hn()}),r&&(r.onclick=()=>{e&&(e.value=``),t&&(t.value=``),D.eventContactId=``,D.eventName=``,i&&(i.style.display=`none`),e?.focus()});let s=(e,t)=>{i&&(i.style.display=`block`,i.style.background=t?`rgba(var(--success-rgb), 0.15)`:`rgba(var(--error-rgb), 0.15)`,i.style.color=t?`var(--success)`:`var(--error)`,i.textContent=e)},c=async(r,i)=>{if(!r){s(`Please provide a Contact ID.`,!1),e?.focus();return}if(!i){s(`Please provide an Event Name.`,!1),t?.focus();return}n&&(n.disabled=!0,n.innerHTML=`<span class="ss-spinner" style="width:12px;height:12px;border-width:1.5px;"></span> Firing...`);try{await Qt(r,i),O(`Fire Event`,`Fired "${i}" for contact ${r}`),Se(D.projectId,{contactId:r,name:i,success:!0}),M(`Event "${i}" fired successfully!`,`success`),s(`✓ Event "${i}" successfully fired for contact ${r}!`,!0),hn()}catch(e){M(`Failed to fire event: ${e.message}`,`error`),s(`⚠ ${e.message}`,!1),n&&(n.disabled=!1,n.innerHTML=`${z} <span>Fire Event</span>`)}};n&&(n.onclick=()=>{let n=e?.value?.trim(),r=t?.value?.trim();D.eventContactId=n,D.eventName=r,c(n,r)});let l=n=>{if(n.key===`Enter`){let n=e?.value?.trim(),r=t?.value?.trim();c(n,r)}};e?.addEventListener(`keydown`,l),t?.addEventListener(`keydown`,l),k.querySelectorAll(`.ss-event-refire-btn`).forEach(n=>{n.onclick=()=>{let r=n.dataset.cid,i=n.dataset.name;e&&(e.value=r),t&&(t.value=i),c(r,i)}}),k.querySelectorAll(`.ss-event-copy-btn`).forEach(e=>{e.onclick=t=>{t.stopPropagation();let n=e.dataset.copy;N(n,`Copy Contact ID`,`Copied ID: ${n}`);let r=e.innerHTML;e.innerHTML=F,setTimeout(()=>e.innerHTML=r,1500)}})}var vn=1440*60*1e3;async function yn(e=!1,t=!1){let n=k.getElementById(`ss-body`);n&&(D.projectId||V(),n.innerHTML=`
    <div style="margin-bottom:12px;">
      <!-- Search & Refresh Toolbar -->
      <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;">
        <input class="ss-input" id="ss-funnel-search-input" type="text" placeholder="Search funnels..." autocomplete="off" value="${j(D.funnelSearchTerm||``)}" style="flex:1;box-sizing:border-box;" />
        <button class="ss-btn-search" id="ss-funnel-reset-search-btn" title="Reset Search" style="width:auto;padding:8px 12px;justify-content:center;background:var(--bg3);color:var(--text2);display:${D.funnelSearchTerm?`inline-flex`:`none`};">
          ✕
        </button>
        <button class="ss-btn-search" id="ss-funnel-refresh-btn" title="Refresh data from server" style="width:auto;padding:8px 12px;justify-content:center;background:var(--bg3);color:var(--text2);">
          ${I.replace(`width="24" height="24"`,`width="16" height="16"`)}
        </button>
      </div>

      <!-- Snapshot Info Banner -->
      <div id="ss-funnel-snapshot-bar" style="background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:8px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12px;">
        <div id="ss-funnel-snapshot-text" style="color:var(--text3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
          Loading baseline...
        </div>
        <button id="ss-funnel-reset-baseline-btn" class="ss-text-link" style="font-size:11px;flex-shrink:0;cursor:pointer;border:none;background:none;color:var(--accent);font-weight:600;" title="Reset baseline snapshot to current counts now">
          Update Baseline
        </button>
      </div>
    </div>

    <!-- Funnels List Container -->
    <div id="ss-funnel-list" style="display:flex;flex-direction:column;gap:8px;">
      <div class="ss-loading" style="display:flex;padding:24px 0;"><div class="ss-spinner"></div><span class="ss-loading-text">Loading funnels...</span></div>
    </div>
    <div class="ss-error" id="ss-funnel-error" style="display:none;margin-top:8px;"></div>
  `,bn(),await xn(e,t))}function bn(){let e=k.getElementById(`ss-funnel-search-input`),t=k.getElementById(`ss-funnel-reset-search-btn`),n=k.getElementById(`ss-funnel-refresh-btn`),r=k.getElementById(`ss-funnel-reset-baseline-btn`);e&&e.addEventListener(`input`,A(e=>{D.funnelSearchTerm=e.target.value.trim(),t&&(t.style.display=D.funnelSearchTerm?`inline-flex`:`none`),Cn()},200)),t&&(t.onclick=()=>{e&&(e.value=``),D.funnelSearchTerm=``,t.style.display=`none`,Cn()}),n&&(n.onclick=()=>{n.classList.add(`ss-spinning`),xn(!0,!1).finally(()=>n.classList.remove(`ss-spinning`))}),r&&(r.onclick=()=>{xn(!1,!0)})}async function xn(e=!1,t=!1){let n=k.getElementById(`ss-funnel-list`),r=k.getElementById(`ss-funnel-error`),i=D.projectId;if(!D.funnelResults.length||e||t){D.isSearchingFunnels=!0,r&&(r.style.display=`none`);try{O(`Fetch Funnels`,`Project: ${i}`),D.funnelResults=await Ut()}catch(e){r&&(r.textContent=`⚠ ${e.message||`Failed to load funnels`}`,r.style.display=`block`),n&&(n.innerHTML=``),D.isSearchingFunnels=!1;return}finally{D.isSearchingFunnels=!1}}let a=re(i),o=Date.now(),s=a&&a.timestamp&&o-a.timestamp>=vn;if(!a||!a.counts||t){let e={};D.funnelResults.forEach(t=>{e[t.id]=t.runs}),a={timestamp:o,counts:e,prevTimestamp:null,prevCounts:null},ie(i,a)}else if(s&&!e){let e={};D.funnelResults.forEach(t=>{e[t.id]=t.runs}),a={timestamp:o,counts:e,prevTimestamp:a.timestamp,prevCounts:a.counts},ie(i,a)}Sn(a),Cn(a)}function Sn(e){let t=k.getElementById(`ss-funnel-snapshot-text`);if(!t||!e||!e.timestamp)return;let n=new Date(e.timestamp);t.innerHTML=`
    <span>📌 Baseline: <strong style="color:var(--text);">${n.toLocaleDateString()}, ${n.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}</strong> (next reset in ~${Math.max(0,Math.ceil((vn-(Date.now()-e.timestamp))/(3600*1e3)))}h)</span>
  `}function Cn(e=null){let t=k.getElementById(`ss-funnel-list`);if(!t)return;let n=D.projectId,r=n||V()||``,i=(e||re(n)||{counts:{}}).counts||{},a=(D.funnelSearchTerm||``).toLowerCase(),o=D.funnelResults.filter(e=>a?e.name.toLowerCase().includes(a)||String(e.id).includes(a):!0);if(!o.length){t.innerHTML=`<div class="ss-empty" style="padding:32px 16px;text-align:center;color:var(--text4);font-size:13px;">${a?`No funnels matching search`:`No funnels found in project`}</div>`;return}t.innerHTML=``,o.forEach(e=>{let n=document.createElement(`div`);n.className=`ss-var-card`,n.style.padding=`12px 14px`,n.style.display=`flex`,n.style.flexDirection=`column`,n.style.gap=`8px`;let a=e.runs||0,o=i[e.id]!==void 0,s=o?i[e.id]:a,c=a-s,l=``;l=o?c>0?`<span style="background:rgba(34,197,94,0.15);color:#22c55e;font-size:12px;font-weight:800;padding:2px 8px;border-radius:6px;border:1px solid rgba(34,197,94,0.3);">+${c.toLocaleString()}</span>`:c===0?`<span style="background:var(--bg3);color:var(--text4);font-size:12px;font-weight:600;padding:2px 8px;border-radius:6px;border:1px solid var(--border);">0</span>`:`<span style="background:rgba(239,68,68,0.15);color:var(--error);font-size:12px;font-weight:800;padding:2px 8px;border-radius:6px;border:1px solid rgba(239,68,68,0.3);">${c.toLocaleString()}</span>`:`<span style="background:var(--accent-bg);color:var(--accent);font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;border:1px solid rgba(var(--accent-rgb),0.3);">NEW</span>`;let u=r?`https://messenger.smartsender.com/funnels/${e.id}?project=${r}`:`https://messenger.smartsender.com/funnels/${e.id}`,d=e.updatedAt?new Date(e.updatedAt).toLocaleDateString():`—`;n.innerHTML=`
      <!-- Row 1: Name, Status, Link -->
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
        <div style="min-width:0;flex:1;display:flex;align-items:center;gap:8px;">
          <a href="${u}" target="_blank" class="ss-funnel-title-link" title="Open funnel in SmartSender" style="font-weight:700;font-size:15px;color:var(--text);text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
            ${j(e.name)}
          </a>
          <a href="${u}" target="_blank" title="Open funnel builder" class="ss-var-btn" style="color:var(--text4);display:inline-flex;padding:0;width:20px;height:20px;flex-shrink:0;">
            ${L.replace(`width="16" height="16"`,`width="12" height="12"`)}
          </a>
        </div>
        <div>
          ${e.active?`<span style="background:rgba(34,197,94,0.15);color:#22c55e;font-size:11px;font-weight:700;padding:2px 6px;border-radius:4px;border:1px solid rgba(34,197,94,0.3);">ACTIVE</span>`:`<span style="background:var(--bg3);color:var(--text4);font-size:11px;font-weight:600;padding:2px 6px;border-radius:4px;border:1px solid var(--border);">DRAFT</span>`}
        </div>
      </div>

      <!-- Row 2: Counters & Delta -->
      <div style="background:var(--bg3);border-radius:8px;padding:8px 12px;display:flex;align-items:center;justify-content:space-between;margin:2px 0;">
        <div style="display:flex;gap:16px;align-items:center;">
          <div>
            <div style="font-size:11px;color:var(--text4);text-transform:uppercase;font-weight:600;letter-spacing:0.3px;">Total Runs</div>
            <div style="font-size:16px;font-weight:800;color:var(--text);">${a.toLocaleString()}</div>
          </div>
          <div style="width:1px;height:24px;background:var(--border);"></div>
          <div>
            <div style="font-size:11px;color:var(--text4);text-transform:uppercase;font-weight:600;letter-spacing:0.3px;">Baseline</div>
            <div style="font-size:14px;font-weight:600;color:var(--text3);">${s.toLocaleString()}</div>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px;">
          <div style="font-size:10px;color:var(--text4);text-transform:uppercase;font-weight:600;">Change</div>
          <div>${l}</div>
        </div>
      </div>

      <!-- Row 3: Meta & ID -->
      <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px;color:var(--text4);padding-top:2px;">
        <div style="display:flex;align-items:center;gap:6px;">
          <span>ID: <strong style="color:var(--accent);font-weight:600;">${e.id}</strong></span>
          <button class="ss-info-copy-btn ss-funnel-copy-btn" data-copy="${e.id}" title="Copy Funnel ID" style="width:16px;height:16px;padding:0;background:none;border:none;cursor:pointer;color:var(--text4);">
            ${P}
          </button>
        </div>
        <div>Modified: ${d}</div>
      </div>
    `;let f=n.querySelector(`.ss-funnel-copy-btn`);f&&(f.onclick=t=>{t.stopPropagation(),N(e.id,`Copy Funnel ID`,`Copied ID: ${e.id}`),f.innerHTML=F,setTimeout(()=>f.innerHTML=P,1500)}),t.appendChild(n)})}function wn(){let e=k.getElementById(`ss-project-display`),t=k.getElementById(`ss-api-status`);if(D.projectId){let n=D.projectName||`—`;if(e&&(e.innerHTML=`<span style="color:var(--text4);font-size:13px;">Project:</span> <span style="color:var(--accent);font-weight:700;font-size:13px;">${n}</span>`),t){let e=S(D.projectId)?.apiToken;t.style.display=e?`none`:`block`}}else e&&(e.innerHTML=`<span style="color:var(--text5);">waiting...</span>`),t&&(t.style.display=`none`)}function Tn(){let e=k.getElementById(`ss-nav`);if(!e)return;e.innerHTML=`
    <div class="ss-info-header" style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;">
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:28px;height:28px;border-radius:7px;background:#09090b;color:#ffffff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;letter-spacing:-0.5px;box-shadow:0 2px 6px rgba(0,0,0,0.18);user-select:none;">mS</div>
        <div class="ss-info-title" style="font-size:17px;font-weight:700;letter-spacing:-0.3px;">mySmart</div>
      </div>
      <button class="ss-close" id="ss-nav-close">${R}</button>
    </div>
    <div class="ss-section-label" style="padding: 0 16px; margin: 8px 0;">Menu</div>
    <button class="ss-nav-item ${D.view!==`settings`&&D.activeTab===`vars`?`active`:``}" data-tab="vars">
      <span class="ss-nav-icon">${pt}</span>
      <span>Variables</span>
    </button>
    <button class="ss-nav-item ${D.view!==`settings`&&D.activeTab===`tags`?`active`:``}" data-tab="tags">
      <span class="ss-nav-icon">${mt}</span>
      <span>Tags</span>
    </button>
    <button class="ss-nav-item ${D.view!==`settings`&&D.activeTab===`contacts`?`active`:``}" data-tab="contacts">
      <span class="ss-nav-icon">${ht}</span>
      <span>Contacts</span>
    </button>
    <button class="ss-nav-item ${D.view!==`settings`&&D.activeTab===`funnels`?`active`:``}" data-tab="funnels">
      <span class="ss-nav-icon">${gt}</span>
      <span>Funnels</span>
    </button>
    <button class="ss-nav-item ${D.view!==`settings`&&D.activeTab===`events`?`active`:``}" data-tab="events">
      <span class="ss-nav-icon">${z}</span>
      <span>Event</span>
    </button>
    <button class="ss-nav-item ${D.view!==`settings`&&D.activeTab===`log`?`active`:``}" data-tab="log">
      <span class="ss-nav-icon">${yt}</span>
      <span>Action Logs</span>
    </button>
    <button class="ss-nav-item ${D.view!==`settings`&&D.activeTab===`info`?`active`:``}" data-tab="info">
      <span class="ss-nav-icon">${bt}</span>
      <span>About</span>
    </button>
    <button class="ss-nav-item ${D.view===`settings`?`active`:``}" data-view="settings">
      <span class="ss-nav-icon">${$e}</span>
      <span>Preference</span>
    </button>

    <div class="ss-divider" style="margin: 8px 0;"></div>
    <div class="ss-section-label" style="padding: 0 16px; margin: 8px 0;">Coming Soon</div>

    <div class="ss-nav-item disabled">
      <span class="ss-nav-icon">${_t}</span>
      <span>Chat</span>
      <span class="ss-nav-soon">Soon</span>
    </div>
    <div class="ss-nav-item disabled">
      <span class="ss-nav-icon">${vt}</span>
      <span>Monitoring</span>
      <span class="ss-nav-soon">Soon</span>
    </div>
  `,e.querySelectorAll(`.ss-nav-item:not(.disabled)`).forEach(t=>{t.addEventListener(`click`,()=>{D.navOpen=!1,e.classList.remove(`open`),t.dataset.view===`settings`?Q(`settings`):En(t.dataset.tab)})});let t=k.getElementById(`ss-nav-close`);t&&(t.onclick=()=>$(`ss-nav`))}function Q(e){Gt(),D.view=e;let t=k.getElementById(`ss-settings-btn`),n=k.getElementById(`ss-back-btn`),r=k.getElementById(`ss-nav`),i=k.getElementById(`ss-current-tab-label`);if(e===`settings`){t&&(t.style.display=`none`),n&&(n.style.display=`flex`),r&&r.classList.remove(`open`),i&&(i.textContent=`Preference`);let e=k.getElementById(`ss-tab-external-link`);e&&(e.style.display=`none`),U(),H()}else{let e=k.getElementById(`ss-project-switcher-panel`);if(e&&e.classList.remove(`open`),t&&(t.style.display=`flex`),n&&(n.style.display=`none`),i){let e=`Variables`;D.activeTab===`tags`&&(e=`Tags`),D.activeTab===`contacts`&&(e=`Contacts`),D.activeTab===`events`&&(e=`Event`),D.activeTab===`log`&&(e=`Action Logs`),D.activeTab===`info`&&(e=`About`),i.textContent=e}D.activeTab===`tags`?q():D.activeTab===`contacts`?cn():D.activeTab===`events`?hn():D.activeTab===`info`?sn():D.activeTab===`log`?mn():Wt(),Dn(D.activeTab)}}function En(e){D.view===`settings`&&Q(`main`),D.activeTab=e,fe(D.projectId,e);let t=`Variables`;e===`tags`&&(t=`Tags`),e===`contacts`&&(t=`Contacts`),e===`funnels`&&(t=`Funnels`),e===`events`&&(t=`Event`),e===`log`&&(t=`Action Logs`),e===`info`&&(t=`About`);let n=k.getElementById(`ss-current-tab-label`);n&&(n.textContent=t),Tn(),Dn(e),e===`tags`?q():e===`contacts`?cn():e===`funnels`?yn():e===`events`?hn():e===`log`?mn():e===`info`?sn():Wt()}function Dn(e){let t=k.getElementById(`ss-tab-external-link`);if(!t)return;if(e===`log`||e===`info`||e===`events`){t.style.display=`none`;return}let n=D.projectId,r=Et()&&n;if(t.style.display=`inline-flex`,r){if(e===`funnels`){t.href=`https://messenger.smartsender.com/funnels?project=${n}`,t.style.opacity=`1`,t.style.pointerEvents=`auto`,t.style.cursor=`pointer`,t.title=`Open Funnels in SmartSender`;return}let r=`definitions`;e===`tags`&&(r=`tags`),e===`contacts`&&(r=`contacts`),t.href=`https://console.smartsender.com/${r}?project=${n}`,t.style.opacity=`1`,t.style.pointerEvents=`auto`,t.style.cursor=`pointer`,t.title=`Open in SmartSender`}else t.removeAttribute(`href`),t.style.opacity=`0.3`,t.style.pointerEvents=`none`,t.style.cursor=`default`,t.title=`Available only on smartsender.com with active project`}var $=e=>{let t=[`ss-nav`,`ss-info-panel`,`ss-contact-search-hist`,`ss-contact-fav-panel`,`ss-contact-settings-panel`,`ss-var-search-hist`,`ss-var-presets-panel`,`ss-var-fav-panel`,`ss-tag-search-hist`,`ss-tag-fav-panel`,`ss-project-switcher-panel`,`ss-extra-panel`],n=k.getElementById(e);if(!n)return;let r=[`ss-contact-search-hist`,`ss-var-search-hist`,`ss-tag-search-hist`,`ss-info-panel`,`ss-contact-fav-panel`,`ss-var-fav-panel`,`ss-tag-fav-panel`,`ss-var-presets-panel`,`ss-contact-settings-panel`].includes(e),i=t.find(e=>{let t=k.getElementById(e);return t&&t!==n&&t.classList.contains(`open`)});i!==e&&(i&&(r&&[`ss-contact-search-hist`,`ss-var-search-hist`,`ss-tag-search-hist`,`ss-info-panel`,`ss-contact-fav-panel`,`ss-var-fav-panel`,`ss-tag-fav-panel`,`ss-var-presets-panel`,`ss-contact-settings-panel`].includes(i)?k.getElementById(i).classList.remove(`open`):t.forEach(e=>k.getElementById(e)?.classList.remove(`open`))),n.classList.toggle(`open`))};function On(){let e=document.createElement(`div`);return e.id=`ss-sidebar`,e.innerHTML=`
      <div class="ss-header">
        <div class="ss-header-top" style="align-items:center;margin-bottom:6px;">
          <div style="display:flex;align-items:center;gap:12px;">
            <button class="ss-icon-btn" id="ss-burger" title="Navigation Menu" style="width:44px;height:44px;background:none;border-radius:12px;display:flex;align-items:center;justify-content:center;color:var(--text2);padding:0;">
              ${lt}
            </button>
            <div style="display:flex;align-items:center;gap:10px;">
              <div class="ss-brand-badge" style="width:28px;height:28px;border-radius:7px;background:#09090b;color:#ffffff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;letter-spacing:-0.5px;box-shadow:0 2px 6px rgba(0,0,0,0.18);user-select:none;flex-shrink:0;">mS</div>
              <span id="ss-current-tab-label" style="font-size:22px;font-weight:700;color:var(--text2);letter-spacing:-0.02em;">Variables</span>
              <a id="ss-tab-external-link" target="_blank" title="Open in SmartSender" style="display:none;color:var(--text4);margin-left:6px;text-decoration:none;transition:color 0.2s;">
                ${L.replace(`width="16" height="16"`,`width="20" height="20"`)}
              </a>
            </div>
          </div>
        </div>
      </div>
      <div id="ss-nav" class="ss-nav"></div>
      <div id="ss-info-panel" class="ss-info-panel"></div>
      <div id="ss-contact-search-hist" class="ss-extra-panel"></div>
      <div id="ss-contact-fav-panel" class="ss-extra-panel"></div>
      <div id="ss-contact-settings-panel" class="ss-extra-panel"></div>
      <div id="ss-var-search-hist" class="ss-extra-panel"></div>
      <div id="ss-var-presets-panel" class="ss-extra-panel"></div>
      <div id="ss-var-fav-panel" class="ss-extra-panel"></div>
      <div id="ss-tag-search-hist" class="ss-extra-panel"></div>
      <div id="ss-tag-fav-panel" class="ss-extra-panel"></div>
      <div id="ss-project-switcher-panel" class="ss-extra-panel"></div>
      <div class="ss-body" id="ss-body"></div>
      <div class="ss-footer" style="padding:10px 16px;">
        <div style="display:flex;align-items:center;justify-content:flex-end;gap:12px;">
           <div style="display:flex;align-items:center;gap:10px;margin-left:auto;">
             <div id="ss-mode-toggle-container" style="display:flex;align-items:center;gap:6px;">
                <span id="ss-mode-text" style="font-size:11px;font-weight:700;text-transform:uppercase;">AUTO</span>
                <label class="ss-mode-switch" id="ss-mode-switch-label" title="Toggle Auto/Manual Project Selection">
                  <input type="checkbox" id="ss-mode-checkbox">
                  <span class="ss-mode-slider"></span>
                </label>
             </div>
             <div class="ss-project-badge" id="ss-project-container" style="margin:0;flex-shrink:0;cursor:pointer;"><span id="ss-project-display">—</span></div>
             <div id="ss-api-status" style="display:none;font-size:11px;background:var(--error);color:white;padding:2px 6px;border-radius:4px;font-weight:700;text-transform:uppercase;cursor:pointer;" title="No API Key — Click to add">api key</div>
           </div>
        </div>
      </div>
    `,e}export{f as A,R as C,Ve as D,Ue as E,oe as F,e as I,E as M,we as N,D as O,y as P,I as S,j as T,Ot as _,Q as a,Et as b,an as c,Lt as d,It as f,Dt as g,At as h,En as i,ae as j,p as k,Y as l,U as m,wn as n,$ as o,Ft as p,Tn as r,un as s,On as t,Zt as u,V as v,Qe as w,St as x,wt as y};